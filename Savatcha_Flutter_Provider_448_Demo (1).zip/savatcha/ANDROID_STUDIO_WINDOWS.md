# Android Studio’da APK yig‘ish — ketma-ket

1. ZIP faylni, masalan, `D:\FlutterProjects\` ichiga oching. Ichida `savatcha` papkasi bo‘lsin.
2. Android Studio → **Open** → `savatcha` papkasini tanlang.
3. **Settings → Plugins** orqali `Flutter` va `Dart` plaginlari yoqilganini tekshiring.
4. **Terminal** (`Alt + F12`)ni oching.
5. Quyidagi buyruqlarni **bittadan** kiriting:

   ```powershell
   flutter doctor
   flutter create --platforms=android --org uz.diydor .
   flutter pub get
   flutter analyze
   flutter test
   ```

6. Emulyator yoki telefonni tanlab, ishga tushiring:

   ```powershell
   flutter run
   ```

7. Ilovada bosh sahifa, 8 ta toifa, jami 448 demo mahsulot va avvaldan to‘ldirilgan savatcha ochilganini tekshiring. Narxlarni va miqdorni o‘zgartiring.
8. APK yaratish:

   ```powershell
   flutter build apk --release
   ```

9. APK shu yerda tayyor bo‘ladi: `build\app\outputs\flutter-apk\app-release.apk`.

**Eslatma:** `flutter create` loyihaga Android platforma fayllarini qo‘shadi. Agar mavjud `lib/` fayllarini yozib yuborishni so‘rasa, to‘xtab, avval loyiha nusxasini saqlang. `flutter` topilmasa, Flutter SDK PATH sozlamasini tekshiring.

Haqiqiy telefon uchun release APK sinov tariqasida o‘rnatiladi. Play Store’ga chiqarishdan oldin shaxsiy release signing kalitini va noyob application ID’ni sozlash kerak.
