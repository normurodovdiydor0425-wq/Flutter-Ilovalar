# Savatcha 🛒 — Flutter + Provider

O‘zbek tilidagi offline savatcha boshqaruvi ilovasi. Ikki taqdim etilgan dizayn referensidagi oq-yashil palitra, yumaloq kartalar, mahsulot ekrani, savatcha va miqdor boshqaruvi asosida tayyorlandi.

## Demo mahsulotlar

Ilova birinchi marta ochilganda **448 ta shartli narxli demo mahsulot** yuklanadi: **8 ta toifada 56 tadan** (har bir toifada 8 turdagi mahsulot va har tur uchun 6 xil to‘plam). Bu real bozor narxlari emas. Boshlang‘ich savatchada olma (2 dona), banan (1 dona) va qulupnay (1 dona) mavjud.

| Toifa | Mahsulot soni |
| --- | ---: |
| Mevalar | 56 |
| Sabzavotlar | 56 |
| Sut mahsulotlari | 56 |
| Non va don | 56 |
| Ichimliklar | 56 |
| Go‘sht va baliq | 56 |
| Shirinliklar | 56 |
| Uy-ro‘zg‘or | 56 |
| **Jami** | **448** |

## Funksiyalar

- Katalogda qidirish, toifa tanlash, saralash.
- Mahsulot qo‘shish, tahrirlash, tasdiqlab o‘chirish.
- Savatchada `+`, `−`, o‘chirish va Undo.
- `CartProvider` bilan jami narx, noyob mahsulotlar va dona soni.
- Demo buyurtma (haqiqiy to‘lovsiz) va mahalliy tarix.
- `shared_preferences` orqali offline saqlash.
- Yorug‘ va qorong‘i rejim.
- Provider yordamida holatni barcha ekranlarda sinxron yangilash.

## Android Studio'da ishga tushirish (Windows)

**Muhim:** bu arxiv Flutter'ning barcha `lib/`, `test/` va konfiguratsiya fayllarini saqlaydi. Kod yaratish muhitida Flutter SDK bo‘lmagani uchun Android platformasining avtomatik generatsiya qilinadigan `android/` katalogi arxivga kiritilmagan. Uni bir marta o‘zingizdagi Flutter SDK orqali generatsiya qiling:

1. Flutter SDK va Android Studio Flutter/Dart plaginlarini o‘rnating.
2. ZIP arxivni ochib, `savatcha` papkasini Android Studio'da oching.
3. **Terminal** (`Alt + F12`)da shu papkaning ichida:

   ```powershell
   flutter doctor
   flutter create --platforms=android --org uz.diydor .
   flutter pub get
   flutter analyze
   flutter test
   flutter run
   ```

   `flutter create .` mavjud `lib/` kodini o‘zgartirmasdan Android platforma fayllarini generatsiya qilishi kerak. Agar dastur mavjud fayllarni qayta yozishga urinsa, tasdiqlamasdan to‘xtating va shu papkaning zaxira nusxasini saqlang.

4. Android telefoningizda Developer Options → USB debugging yoqilgan bo‘lsin yoki emulyatorni ishga tushiring.
5. APK fayl yaratish:

   ```powershell
   flutter build apk --release
   ```

6. Tayyor APK manzili: `build/app/outputs/flutter-apk/app-release.apk`.

## Tuzilma

```text
lib/
  main.dart                 # yuklash, 448 demo ma'lumoti, Providerlar
  app.dart                  # MaterialApp, 4 ta bottom navigation
  core/                    # tema, so'm formatlash
  data/demo_products.dart  # 8 toifa, 448 demo mahsulot
  models/                  # Product, CartItem, OrderRecord
  providers/               # Catalog, Cart, Orders, Theme
  services/                # JSON va shared_preferences
  screens/                 # katalog, detail, forma, cart, history, settings
  widgets/                 # mahsulot rasmini o‘rnini bosuvchi offline emoji, empty state
test/
  cart_provider_test.dart
  product_form_test.dart
  widget_test.dart
  in_memory_storage.dart
```

## Muhim eslatmalar

- Narxlar `int` turidagi **butun so‘m**da saqlanadi. `totalPrice = sum(product.price * quantity)`.
- `CartProvider` `CatalogProvider`ni tinglaydi: narx yangilansa jami ham yangilanadi; katalogdan mahsulot o‘chirilsa savatchadan ham o‘chadi.
- 1 donaga tushganda `−` tugmasi o‘chirishni bajarmaydi; alohida `O‘chirish` ishlatiladi.
- Birinchi ishga tushirishda demo mahsulotlar bir marta yoziladi. Keyinchalik o‘zgartirish va o‘chirishlar saqlanadi.
- “Barcha maʼlumotlarni tozalash” demo katalogni ham o‘chiradi. Demo ma'lumotlarini qaytarish uchun ilovani Android sozlamalaridan **Clear storage** qilish yoki qayta o‘rnatish mumkin.
- Rasmlar o‘rniga internetga bog‘lanmaydigan emoji va gradientli illustratsiyalar ishlatilgan. Keyin haqiqiy mahsulot rasmlarini `assets/images/`ga qo‘shish mumkin.
- Yetkazish va buyurtma sahifasi — **faqat namoyish**. Haqiqiy to‘lov, tracking, savdo serveri yo‘q.
- Ushbu muhitda Flutter/Dart SDK mavjud bo‘lmagani sababli `flutter analyze`, `flutter test` va APK build bu yerda ishga tushirilmadi. Yuqoridagi buyruqlarni Android Studio'da bajarish va natijalarni tekshirish kerak.
- Agar Gradle Kotlin keshi `C:` va `E:` disklar orasida xato bersa, `XATOLAR_VA_YECHIMLAR.md`dagi `kotlin.incremental=false` va `flutter clean` qadamlarini bajaring.
