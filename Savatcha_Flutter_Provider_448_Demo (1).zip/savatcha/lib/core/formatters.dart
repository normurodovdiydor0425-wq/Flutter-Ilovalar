import 'package:intl/intl.dart';

final NumberFormat _number = NumberFormat.decimalPattern('en_US');

String money(int value) => '${_number.format(value).replaceAll(',', ' ')} so‘m';

String quantityLabel(int count) => '$count dona';

String dateTimeLabel(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}  '
    '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
