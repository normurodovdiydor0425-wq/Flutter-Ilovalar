import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/app_theme.dart';
import 'providers/cart_provider.dart';
import 'providers/theme_provider.dart';
import 'screens/cart_screen.dart';
import 'screens/history_screen.dart';
import 'screens/home_screen.dart';
import 'screens/settings_screen.dart';

class SavatchaApp extends StatelessWidget {
  const SavatchaApp({super.key, this.startupWarning});
  final String? startupWarning;

  @override
  Widget build(BuildContext context) {
    final themeMode = context.watch<ThemeProvider>().themeMode;
    return MaterialApp(
      title: 'Savatcha',
      debugShowCheckedModeBanner: false,
      theme: appTheme(Brightness.light),
      darkTheme: appTheme(Brightness.dark),
      themeMode: themeMode,
      home: AppShell(startupWarning: startupWarning),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, this.startupWarning});
  final String? startupWarning;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  void initState() {
    super.initState();
    if (widget.startupWarning != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(widget.startupWarning!)));
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final count = context.select<CartProvider, int>((cart) => cart.totalUnits);
    final pages = [
      HomeScreen(onOpenCart: () => setState(() => index = 2)),
      const HistoryScreen(),
      CartScreen(onBrowse: () => setState(() => index = 0),
          onOrdered: () => setState(() => index = 1)),
      const SettingsScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          boxShadow: [BoxShadow(
            color: Colors.black.withValues(alpha: 0.045),
            blurRadius: 20, offset: const Offset(0, -5),
          )],
        ),
        child: SafeArea(
          top: false,
          child: NavigationBar(
            backgroundColor: Theme.of(context).cardColor,
            height: 68,
            selectedIndex: index,
            indicatorColor: brandGreen.withValues(alpha: .12),
            onDestinationSelected: (selected) => setState(() => index = selected),
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            destinations: [
              const NavigationDestination(icon: Icon(Icons.home_outlined),
                  selectedIcon: Icon(Icons.home_rounded, color: brandGreen), label: 'Bosh sahifa'),
              const NavigationDestination(icon: Icon(Icons.receipt_long_outlined),
                  selectedIcon: Icon(Icons.receipt_long, color: brandGreen), label: 'Tarix'),
              NavigationDestination(
                icon: _cartIcon(count, false),
                selectedIcon: _cartIcon(count, true),
                label: 'Savatcha',
              ),
              const NavigationDestination(icon: Icon(Icons.person_outline_rounded),
                  selectedIcon: Icon(Icons.person, color: brandGreen), label: 'Profil'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cartIcon(int count, bool selected) => Badge(
        isLabelVisible: count > 0,
        label: Text(count > 99 ? '99+' : '$count'),
        backgroundColor: coral,
        child: Icon(selected ? Icons.shopping_cart_rounded : Icons.shopping_cart_outlined,
            color: selected ? brandGreen : null),
      );
}
