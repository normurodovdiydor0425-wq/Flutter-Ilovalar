import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/cart_item.dart';
import '../providers/cart_provider.dart';
import '../providers/orders_provider.dart';
import '../widgets/product_visual.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key, required this.onBrowse, required this.onOrdered});
  final VoidCallback onBrowse;
  final VoidCallback onOrdered;

  Future<void> _clearCart(BuildContext context) async {
    final answer = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Savatchani tozalaysizmi?'),
      content: const Text('Savatchadagi mahsulotlar olib tashlanadi, lekin katalogda qoladi.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Yo‘q')),
        TextButton(onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Tozalash', style: TextStyle(color: coral))),
      ],
    ));
    if (answer == true && context.mounted) context.read<CartProvider>().clearCart();
  }

  Future<void> _checkout(BuildContext context) async {
    final cart = context.read<CartProvider>();
    final amount = cart.totalPrice;
    if (cart.items.isEmpty) return;
    final answer = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Demo buyurtma'),
      content: Text('Jami: ${money(amount)}\n\nBu amalda haqiqiy to‘lov va yetkazib berish yo‘q. Buyurtma faqat ilova tarixida saqlanadi.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Bekor qilish')),
        ElevatedButton(onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Tasdiqlash')),
      ],
    ));
    if (answer == true && context.mounted) {
      final order = context.read<OrdersProvider>().checkout(cart);
      if (order != null) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Demo buyurtma tarixga saqlandi!')));
        onOrdered();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final items = cart.items;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Savatcham', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          if (items.isNotEmpty)
            TextButton.icon(onPressed: () => _clearCart(context),
              icon: const Icon(Icons.delete_sweep_outlined, color: coral),
              label: const Text('Tozalash', style: TextStyle(color: coral))),
        ],
      ),
      body: SafeArea(child: items.isEmpty
          ? PrimaryEmptyState(icon: Icons.remove_shopping_cart_outlined,
              title: 'Savatchangiz bo‘sh',
              subtitle: 'Xaridni boshlash uchun katalogdan mahsulot tanlang.',
              buttonText: 'Mahsulotlarni ko‘rish', onPressed: onBrowse)
          : Column(children: [
              Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(15, 12, 15, 20),
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [deepGreen, brandGreen]),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(children: [
                      const Icon(Icons.shopping_bag_rounded, size: 36, color: Colors.white),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Sizning savatchangiz', style: TextStyle(
                            color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 3),
                        Text('${cart.distinctItemsCount} xil mahsulot · ${cart.totalUnits} dona',
                            style: const TextStyle(color: Colors.white70)),
                      ])),
                    ]),
                  ),
                  const SizedBox(height: 15),
                  ...items.map((item) => Padding(
                    padding: const EdgeInsets.only(bottom: 9),
                    child: _CartTile(item: item),
                  )),
                  const SizedBox(height: 18),
                  const Text('Hisob tafsilotlari', style: TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 20)),
                  const SizedBox(height: 12),
                  Card(margin: EdgeInsets.zero, child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(children: [
                      _BillRow('Mahsulotlar summasi', money(cart.totalPrice), strong: true),
                      const SizedBox(height: 15),
                      const _BillRow('Yetkazib berish', 'Mavjud emas', muted: true),
                      const SizedBox(height: 12),
                      const _BillRow('Qadoqlash', '0 so‘m', muted: true),
                      const SizedBox(height: 12),
                      const _BillRow('Soliq va xizmat haqi', '0 so‘m', muted: true),
                      const Divider(height: 32),
                      _BillRow('JAMI', money(cart.totalPrice), big: true),
                    ]),
                  )),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(color: brandGreen.withValues(alpha: .10),
                        borderRadius: BorderRadius.circular(14)),
                    child: const Row(children: [
                      Icon(Icons.info_outline, color: brandGreen), SizedBox(width: 9),
                      Expanded(child: Text('Narxlar namuna uchun. Bu ilova haqiqiy savdo yoki to‘lovni bajarmaydi.',
                          style: TextStyle(fontSize: 12))),
                    ]),
                  ),
                ],
              )),
              Container(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .06),
                      blurRadius: 18, offset: const Offset(0, -5))],
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
                ),
                child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min, children: [
                      Text('${cart.totalUnits} dona', style: TextStyle(
                          color: Theme.of(context).hintColor, fontSize: 12)),
                      Text(money(cart.totalPrice), maxLines: 1,
                          overflow: TextOverflow.ellipsis, style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w900)),
                    ],
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: ElevatedButton.icon(
                    onPressed: () => _checkout(context),
                    icon: const Icon(Icons.arrow_forward_rounded),
                    label: const Text('Buyurtma berish'),
                    style: ElevatedButton.styleFrom(backgroundColor: coral),
                  )),
                ]),
              ),
            ])),
    );
  }
}

class _CartTile extends StatelessWidget {
  const _CartTile({required this.item});
  final CartItem item;

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartProvider>();
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(padding: const EdgeInsets.all(11), child: Row(children: [
        ProductVisual(emoji: item.product.emoji, size: 65, radius: 15),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.product.name, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
          const SizedBox(height: 5),
          Text(money(item.product.price), maxLines: 1,
              style: const TextStyle(color: brandGreen, fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          InkWell(
            onTap: () {
              final before = cart.removeFromCart(item.product.id);
              ScaffoldMessenger.of(context).hideCurrentSnackBar();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('${item.product.name} olib tashlandi'),
                action: SnackBarAction(label: 'Bekor qilish',
                    onPressed: () => cart.restoreQuantity(item.product.id, before)),
              ));
            },
            child: const Padding(padding: EdgeInsets.symmetric(vertical: 3),
                child: Text('O‘chirish', style: TextStyle(color: coral, fontSize: 12))),
          ),
        ])),
        const SizedBox(width: 6),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Row(mainAxisSize: MainAxisSize.min, children: [
            _StepButton(icon: Icons.remove, color: coral,
                enabled: item.quantity > 1,
                onPressed: () => cart.decrementQuantity(item.product.id)),
            SizedBox(width: 30, child: Text('${item.quantity}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w800))),
            _StepButton(icon: Icons.add, color: coral,
                onPressed: () => cart.incrementQuantity(item.product.id)),
          ]),
          const SizedBox(height: 11),
          Text(money(item.subtotal), style: const TextStyle(
              fontWeight: FontWeight.w800, fontSize: 12)),
        ]),
      ])),
    );
  }
}

class _StepButton extends StatelessWidget {
  const _StepButton({required this.icon, required this.color,
      required this.onPressed, this.enabled = true});
  final IconData icon;
  final Color color;
  final VoidCallback onPressed;
  final bool enabled;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: enabled ? onPressed : null,
        borderRadius: BorderRadius.circular(9),
        child: Container(
          height: 34, width: 34, alignment: Alignment.center,
          decoration: BoxDecoration(
            color: icon == Icons.add && enabled ? color : Colors.transparent,
            border: Border.all(color: enabled ? color : Colors.grey.shade400),
            borderRadius: BorderRadius.circular(9),
          ),
          child: Icon(icon, size: 19,
              color: !enabled ? Colors.grey : icon == Icons.add ? Colors.white : color),
        ),
      );
}

class _BillRow extends StatelessWidget {
  const _BillRow(this.label, this.value, {this.strong = false,
      this.muted = false, this.big = false});
  final String label;
  final String value;
  final bool strong;
  final bool muted;
  final bool big;

  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Text(label, style: TextStyle(
        fontSize: big ? 17 : 13,
        fontWeight: strong || big ? FontWeight.w900 : FontWeight.w500,
        color: muted ? Theme.of(context).hintColor : null))),
    const SizedBox(width: 10),
    Text(value, style: TextStyle(
        fontWeight: strong || big ? FontWeight.w900 : FontWeight.w600,
        fontSize: big ? 20 : 13,
        color: big ? brandGreen : null)),
  ]);
}
