import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../data/demo_products.dart';
import '../models/product.dart';
import '../providers/catalog_provider.dart';

class ProductFormScreen extends StatefulWidget {
  const ProductFormScreen({super.key, this.product});
  final Product? product;

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final formKey = GlobalKey<FormState>();
  late final TextEditingController name;
  late final TextEditingController price;
  late final TextEditingController description;
  late String category;
  late String emoji;

  static const emojis = [
    '🛍️', '🍎', '🍌', '🥭', '🍓', '🍅', '🥬', '🥛',
    '🍞', '🍚', '🍗', '🥩', '🐟', '🍫', '🧃', '🧼',
  ];

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    name = TextEditingController(text: p?.name ?? '');
    price = TextEditingController(text: p?.price.toString() ?? '');
    description = TextEditingController(text: p?.description ?? '');
    category = p?.category ?? DemoProducts.categories.first;
    emoji = p?.emoji ?? '🛍️';
  }

  @override
  void dispose() {
    name.dispose();
    price.dispose();
    description.dispose();
    super.dispose();
  }

  void save() {
    if (!formKey.currentState!.validate()) return;
    final parsedPrice = int.tryParse(price.text.trim());
    if (parsedPrice == null || parsedPrice <= 0) return;
    final catalog = context.read<CatalogProvider>();
    final id = widget.product?.id ??
        'custom_${DateTime.now().microsecondsSinceEpoch}_${Random().nextInt(100000)}';
    final product = Product(
      id: id,
      name: name.text.trim(),
      price: parsedPrice,
      category: category,
      emoji: emoji,
      description: description.text.trim(),
    );
    try {
      if (widget.product == null) {
        catalog.addProduct(product);
      } else {
        catalog.updateProduct(product);
      }
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(widget.product == null ? 'Mahsulot qo‘shildi!' : 'O‘zgarishlar saqlandi!'),
      ));
      Navigator.pop(context);
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final edit = widget.product != null;
    final categories = {...DemoProducts.categories, if (!DemoProducts.categories.contains(category)) category}.toList();
    return Scaffold(
      appBar: AppBar(title: Text(edit ? 'Mahsulotni tahrirlash' : 'Yangi mahsulot')),
      body: SafeArea(child: Form(
        key: formKey,
        // SingleChildScrollView + Column barcha FormField'larni daraxtda
        // saqlaydi. Lazy ListView offscreen maydonlarni validatsiyadan
        // chiqarib yuborishi mumkin.
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            height: 128,
            decoration: BoxDecoration(color: brandGreen.withValues(alpha: .10),
                borderRadius: BorderRadius.circular(22)),
            alignment: Alignment.center,
            child: Text(emoji, style: const TextStyle(fontSize: 72)),
          ),
          const SizedBox(height: 22),
          const Text('Mahsulot nomi', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          TextFormField(
            controller: name,
            textCapitalization: TextCapitalization.sentences,
            maxLength: 60,
            decoration: const InputDecoration(hintText: 'Masalan: Yangi olma'),
            validator: (value) => (value == null || value.trim().isEmpty) ?
                'Mahsulot nomini kiriting' : null,
          ),
          const SizedBox(height: 12),
          const Text('Narxi (so‘m)', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          TextFormField(
            controller: price,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(hintText: 'Masalan: 25000', prefixIcon: Icon(Icons.payments_outlined)),
            validator: (value) {
              final number = int.tryParse(value?.trim() ?? '');
              return number == null || number <= 0 ? 'Musbat butun narx kiriting' : null;
            },
          ),
          const SizedBox(height: 20),
          const Text('Toifa', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: category,
            isExpanded: true,
            decoration: const InputDecoration(),
            items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (value) => setState(() => category = value ?? category),
          ),
          const SizedBox(height: 20),
          const Text('Mahsulot belgisi', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: emojis.map((item) => InkWell(
            onTap: () => setState(() => emoji = item),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              width: 53, height: 53,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: emoji == item ? brandGreen.withValues(alpha: .15) : Theme.of(context).cardColor,
                border: Border.all(color: emoji == item ? brandGreen : Colors.transparent, width: 2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(item, style: const TextStyle(fontSize: 27)),
            ),
          )).toList()),
          const SizedBox(height: 22),
          const Text('Tavsif (ixtiyoriy)', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          TextFormField(controller: description, maxLines: 3, maxLength: 200,
              decoration: const InputDecoration(hintText: 'Mahsulot haqida qisqacha...')),
          const SizedBox(height: 12),
          ElevatedButton.icon(onPressed: save, icon: const Icon(Icons.check),
              label: Text(edit ? 'O‘zgarishlarni saqlash' : 'Mahsulotni qo‘shish')),
          const SizedBox(height: 24),
          ]),
        ),
      )),
    );
  }
}
