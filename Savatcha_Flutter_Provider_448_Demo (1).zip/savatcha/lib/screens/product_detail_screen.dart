import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../providers/cart_provider.dart';
import '../providers/catalog_provider.dart';
import '../widgets/product_visual.dart';
import 'home_screen.dart';
import 'product_form_screen.dart';

class ProductDetailScreen extends StatelessWidget {
  const ProductDetailScreen({super.key, required this.productId});
  final String productId;

  @override
  Widget build(BuildContext context) {
    final catalog = context.watch<CatalogProvider>();
    final product = catalog.findById(productId);
    if (product == null) {
      return Scaffold(appBar: AppBar(),
          body: const Center(child: Text('Mahsulot o‘chirilgan.')));
    }
    final related = catalog.products
        .where((p) => p.category == product.category && p.id != product.id)
        .take(8).toList();
    final count = context.select<CartProvider, int>((cart) => cart.quantityOf(productId));
    return Scaffold(
      appBar: AppBar(
        title: Text(product.category),
        actions: [
          IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'Tahrirlash',
              onPressed: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ProductFormScreen(product: product)))),
          IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'O‘chirish',
              onPressed: () async {
                await confirmDeleteProduct(context, product);
                if (context.mounted && catalog.findById(productId) == null) Navigator.pop(context);
              }),
        ],
      ),
      body: SafeArea(child: Column(children: [
        Expanded(child: ListView(padding: const EdgeInsets.all(18), children: [
          Container(
            height: 248,
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(25),
            ),
            alignment: Alignment.center,
            child: ProductVisual(emoji: product.emoji, size: 198, radius: 32),
          ),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(24)),
            padding: const EdgeInsets.all(22),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.name, style: const TextStyle(fontSize: 25,
                  fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(product.category, style: const TextStyle(color: brandGreen, fontSize: 14)),
              const SizedBox(height: 12),
              Text(money(product.price), style: const TextStyle(color: deepGreen,
                  fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 16),
              const Divider(height: 16),
              const Text('Mahsulot haqida', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 9),
              Text(product.description.isEmpty ?
                  'Mahsulot tavsifi kiritilmagan.' : product.description,
                  style: TextStyle(color: Theme.of(context).hintColor, height: 1.6)),
            ]),
          ),
          if (related.isNotEmpty) ...[
            const SizedBox(height: 25),
            const SectionHeading('O‘xshash mahsulotlar'),
            const SizedBox(height: 12),
            SizedBox(height: 168, child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: related.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (ctx, i) {
                final item = related[i];
                return SizedBox(width: 138, child: Card(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(
                        builder: (_) => ProductDetailScreen(productId: item.id))),
                    child: Padding(padding: const EdgeInsets.all(10), child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(child: ProductVisual(emoji: item.emoji, size: 72)),
                        const SizedBox(height: 8),
                        Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 3),
                        Text(money(item.price), maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: brandGreen, fontSize: 12)),
                      ],
                    )),
                  ),
                ));
              },
            )),
          ],
          const SizedBox(height: 20),
        ])),
        Container(
          decoration: BoxDecoration(color: Theme.of(context).cardColor,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 15)]),
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
          child: Row(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('1 dona narxi', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
              Text(money(product.price), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            ]),
            const SizedBox(width: 18),
            Expanded(child: ElevatedButton.icon(
              onPressed: () {
                context.read<CartProvider>().addToCart(productId);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Savatchaga qo‘shildi')));
              },
              icon: const Icon(Icons.shopping_cart_checkout),
              label: Text(count == 0 ? 'Savatchaga qo‘shish' : 'Yana qo‘shish ($count)'),
            )),
          ]),
        ),
      ])),
    );
  }
}
