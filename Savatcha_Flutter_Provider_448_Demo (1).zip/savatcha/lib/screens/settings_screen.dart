import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../providers/cart_provider.dart';
import '../providers/catalog_provider.dart';
import '../providers/orders_provider.dart';
import '../providers/theme_provider.dart';
import '../services/local_storage_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _reset(BuildContext context) async {
    final agreed = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Barcha maʼlumotlar o‘chirilsinmi?'),
        content: const Text('64 ta demo mahsulot ham, siz qo‘shgan mahsulotlar, savatcha, tarix va sozlamalar ham tozalanadi. Bu amalni ortga qaytarib bo‘lmaydi.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Bekor qilish')),
          TextButton(onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Hammasini o‘chirish', style: TextStyle(color: coral))),
        ],
      ),
    );
    if (agreed != true || !context.mounted) return;
    final storage = context.read<LocalStorageService>();
    await storage.clearAll();
    if (!context.mounted) return;
    context.read<CartProvider>().clearCart();
    context.read<CatalogProvider>().clear();
    context.read<OrdersProvider>().clear();
    context.read<ThemeProvider>().setDark(false);
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mahalliy maʼlumotlar tozalandi')));
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDark;
    final count = context.select<CatalogProvider, int>((c) => c.count);
    return Scaffold(
      appBar: AppBar(title: const Text('Profil va sozlamalar',
          style: TextStyle(fontWeight: FontWeight.w900))),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [deepGreen, brandGreen]),
            borderRadius: BorderRadius.circular(24)),
          padding: const EdgeInsets.all(22),
          child: const Row(children: [
            CircleAvatar(radius: 32, backgroundColor: Colors.white,
                child: Icon(Icons.shopping_basket, color: brandGreen, size: 35)),
            SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Savatcha', style: TextStyle(color: Colors.white,
                  fontSize: 23, fontWeight: FontWeight.w900)),
              SizedBox(height: 4),
              Text('Xaridlaringizni oson boshqaring',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
          ]),
        ),
        const SizedBox(height: 22),
        const Text('SOZLAMALAR', style: TextStyle(color: brandGreen,
            fontWeight: FontWeight.w800, fontSize: 12)),
        const SizedBox(height: 8),
        Card(child: SwitchListTile.adaptive(
          title: const Text('Qorong‘i rejim', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('Ko‘zga qulay ko‘rinishni tanlang'),
          secondary: Icon(isDark ? Icons.dark_mode_rounded : Icons.light_mode_outlined,
              color: brandGreen),
          value: isDark,
          activeTrackColor: brandGreen,
          onChanged: context.read<ThemeProvider>().setDark,
        )),
        const SizedBox(height: 12),
        Card(child: ListTile(
          leading: const Icon(Icons.inventory_2_outlined, color: brandGreen),
          title: const Text('Katalogdagi mahsulotlar'),
          trailing: Text('$count ta', style: const TextStyle(
              fontWeight: FontWeight.w800, color: brandGreen)),
        )),
        const SizedBox(height: 24),
        const Text('ILOVA HAQIDA', style: TextStyle(color: brandGreen,
            fontWeight: FontWeight.w800, fontSize: 12)),
        const SizedBox(height: 8),
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Savatcha · 1.0.0', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text('Flutter + Dart + Provider asosida yaratilgan offline o‘quv ilovasi. Mahsulot qo‘shish, tahrirlash, miqdor va jami narxni hisoblash uchun mo‘ljallangan.',
                style: TextStyle(color: Theme.of(context).hintColor, height: 1.5)),
            const SizedBox(height: 12),
            const Text('Demo mahsulotlar narxlari shartli; buyurtma haqiqiy savdo emas.',
                style: TextStyle(fontSize: 12, color: brandGreen)),
          ],
        ))),
        const SizedBox(height: 24),
        OutlinedButton.icon(
          onPressed: () => _reset(context),
          icon: const Icon(Icons.delete_forever_outlined),
          label: const Text('Barcha maʼlumotlarni tozalash'),
          style: OutlinedButton.styleFrom(foregroundColor: coral,
              side: const BorderSide(color: coral),
              padding: const EdgeInsets.symmetric(vertical: 15)),
        ),
        const SizedBox(height: 24),
      ])),
    );
  }
}
