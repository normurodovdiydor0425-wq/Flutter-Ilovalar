import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../data/demo_products.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../providers/catalog_provider.dart';
import '../widgets/product_visual.dart';
import 'product_form_screen.dart';
import 'product_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onOpenCart});
  final VoidCallback onOpenCart;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final searchController = TextEditingController();
  String selectedCategory = 'Barchasi';
  String sortBy = 'default';

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final all = context.watch<CatalogProvider>().products;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final categories = ['Barchasi', ...DemoProducts.categories,
      ...all.map((p) => p.category).where((c) => !DemoProducts.categories.contains(c)).toSet()];
    final query = searchController.text.trim().toLowerCase();
    final products = all.where((p) =>
        (selectedCategory == 'Barchasi' || p.category == selectedCategory) &&
        (p.name.toLowerCase().contains(query) || p.category.toLowerCase().contains(query)))
        .toList();
    if (sortBy == 'low') products.sort((a, b) => a.price.compareTo(b.price));
    if (sortBy == 'high') products.sort((a, b) => b.price.compareTo(a.price));
    if (sortBy == 'name') products.sort((a, b) => a.name.compareTo(b.name));

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: coral, foregroundColor: Colors.white,
        icon: const Icon(Icons.add), label: const Text('Mahsulot qo‘shish'),
        onPressed: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => const ProductFormScreen())),
      ),
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Container(
          padding: const EdgeInsets.fromLTRB(20, 50, 20, 28),
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [deepGreen, brandGreen],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
          ),
          child: SafeArea(top: false, child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18),
                        borderRadius: BorderRadius.circular(14)),
                    child: const Icon(Icons.shopping_basket_rounded, color: Colors.white, size: 27)),
                const SizedBox(width: 12),
                const Expanded(child: Text('Savatcha', style: TextStyle(
                    fontWeight: FontWeight.w900, fontSize: 25, color: Colors.white))),
                IconButton(
                  onPressed: widget.onOpenCart,
                  icon: const Icon(Icons.shopping_cart_outlined, color: Colors.white),
                  tooltip: 'Savatchani ochish',
                ),
              ]),
              const SizedBox(height: 24),
              const Text('Mazali xaridlar shu yerdan!', style: TextStyle(
                  color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text('${all.length} xil mahsulot · Narxlar demo uchun',
                  style: TextStyle(color: Colors.white.withValues(alpha: .85))),
              const SizedBox(height: 22),
              TextField(
                controller: searchController,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(color: Colors.black87),
                decoration: InputDecoration(
                  hintText: 'Qaysi mahsulotni izlayapsiz?',
                  hintStyle: const TextStyle(color: Colors.black54),
                  prefixIcon: const Icon(Icons.search_rounded, color: brandGreen),
                  suffixIcon: query.isNotEmpty ? IconButton(
                      onPressed: () { searchController.clear(); setState(() {}); },
                      icon: const Icon(Icons.close, color: Colors.black54)) : null,
                  fillColor: Colors.white,
                ),
              ),
            ],
          )),
        )),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 24, 18, 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeading('Toifalar'),
            const SizedBox(height: 14),
            SizedBox(height: 43, child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final category = categories[i];
                final selected = category == selectedCategory;
                return ChoiceChip(
                  label: Text(category), selected: selected,
                  showCheckmark: false,
                  selectedColor: brandGreen,
                  labelStyle: TextStyle(color: selected ? Colors.white :
                      (dark ? Colors.white : const Color(0xFF394A40)),
                      fontWeight: FontWeight.w600),
                  onSelected: (_) => setState(() => selectedCategory = category),
                  side: BorderSide.none,
                  backgroundColor: Theme.of(context).cardColor,
                );
              },
            )),
            const SizedBox(height: 24),
            SectionHeading('Mahsulotlar', action: PopupMenuButton<String>(
              tooltip: 'Saralash',
              onSelected: (value) => setState(() => sortBy = value),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'default', child: Text('Asl tartib')),
                PopupMenuItem(value: 'low', child: Text('Arzonidan boshlab')),
                PopupMenuItem(value: 'high', child: Text('Qimmatidan boshlab')),
                PopupMenuItem(value: 'name', child: Text('Nom bo‘yicha')),
              ],
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.tune, color: brandGreen), SizedBox(width: 4),
                Text('Saralash', style: TextStyle(color: brandGreen, fontWeight: FontWeight.w700)),
              ]),
            )),
            const SizedBox(height: 4),
            Text('${products.length} ta mahsulot', style: TextStyle(
                color: Theme.of(context).hintColor, fontSize: 12)),
          ]),
        )),
        if (products.isEmpty)
          const SliverFillRemaining(hasScrollBody: false,
              child: PrimaryEmptyState(icon: Icons.search_off_rounded,
                  title: 'Mahsulot topilmadi',
                  subtitle: 'Qidiruvni o‘zgartiring yoki yangi mahsulot qo‘shing.'))
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 15, 16, 108),
            sliver: SliverLayoutBuilder(builder: (context, constraints) {
              final width = constraints.crossAxisExtent;
              final count = width >= 900 ? 4 : width >= 600 ? 3 : 2;
              return SliverGrid(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: count, mainAxisSpacing: 12, crossAxisSpacing: 12,
                  mainAxisExtent: 262,
                ),
                delegate: SliverChildBuilderDelegate(
                    (context, i) => _ProductCard(product: products[i]),
                    childCount: products.length),
              );
            }),
          ),
      ]),
    );
  }
}

class _ProductCard extends StatelessWidget {
  const _ProductCard({required this.product});
  final Product product;

  @override
  Widget build(BuildContext context) => Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ProductDetailScreen(productId: product.id))),
          child: Padding(padding: const EdgeInsets.all(11), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Stack(children: [
                SizedBox(width: double.infinity, height: 112,
                    child: FittedBox(fit: BoxFit.contain,
                        child: ProductVisual(emoji: product.emoji, size: 112))),
                Positioned(top: 2, right: 2, child: Material(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(18),
                  child: PopupMenuButton<String>(
                    tooltip: 'Mahsulot amallari',
                    icon: const Icon(Icons.more_vert, size: 20),
                    onSelected: (value) async {
                      if (value == 'edit') {
                        Navigator.push(context, MaterialPageRoute(builder: (_) =>
                            ProductFormScreen(product: product)));
                      } else {
                        await confirmDeleteProduct(context, product);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('Tahrirlash')),
                      PopupMenuItem(value: 'delete', child: Text('O‘chirish')),
                    ],
                  ),
                )),
              ]),
              const SizedBox(height: 8),
              Text(product.category, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: brandGreen, fontSize: 10,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              const SizedBox(height: 3),
              Text(money(product.price), maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: brandGreen,
                      fontWeight: FontWeight.w800, fontSize: 13)),
              const Spacer(),
              SizedBox(width: double.infinity, height: 36,
                child: ElevatedButton.icon(
                  onPressed: () {
                    context.read<CartProvider>().addToCart(product.id);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text('${product.name} savatchaga qo‘shildi'),
                      duration: const Duration(milliseconds: 900),
                    ));
                  },
                  icon: const Icon(Icons.add_shopping_cart, size: 17),
                  label: const Text('Qo‘shish', style: TextStyle(fontSize: 12)),
                  style: ElevatedButton.styleFrom(padding: EdgeInsets.zero),
                ),
              ),
            ],
          )),
        ),
      );
}

Future<void> confirmDeleteProduct(BuildContext context, Product product) async {
  final accepted = await showDialog<bool>(context: context, builder: (ctx) =>
      AlertDialog(
        title: const Text('Mahsulot o‘chirilsinmi?'),
        content: Text('${product.name} katalog va savatchadan olib tashlanadi.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Bekor qilish')),
          TextButton(onPressed: () => Navigator.pop(ctx, true),
              child: const Text('O‘chirish', style: TextStyle(color: coral))),
        ],
      ));
  if (accepted == true && context.mounted) {
    context.read<CatalogProvider>().deleteProduct(product.id);
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${product.name} o‘chirildi')));
  }
}
