import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../providers/orders_provider.dart';
import '../widgets/product_visual.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<OrdersProvider>().orders;
    return Scaffold(
      appBar: AppBar(title: const Text('Buyurtmalar tarixi',
          style: TextStyle(fontWeight: FontWeight.w900))),
      body: SafeArea(child: orders.isEmpty
        ? const PrimaryEmptyState(icon: Icons.receipt_long_outlined,
            title: 'Hozircha buyurtma yo‘q',
            subtitle: 'Savatchada demo buyurtmani tasdiqlasangiz, u shu yerda ko‘rinadi.')
        : ListView(padding: const EdgeInsets.all(16), children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: brandGreen.withValues(alpha: .10),
                  borderRadius: BorderRadius.circular(16)),
              child: const Text('Bu tarix faqat namoyish uchun. Haqiqiy to‘lov yoki yetkazish bajarilmagan.',
                  style: TextStyle(fontSize: 12)),
            ),
            const SizedBox(height: 14),
            ...orders.map((order) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Card(child: ExpansionTile(
                shape: const Border(), collapsedShape: const Border(),
                leading: const CircleAvatar(
                    backgroundColor: Color(0xFFE3F5E9),
                    child: Icon(Icons.check_circle_outline, color: brandGreen)),
                title: Text(money(order.total), style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${dateTimeLabel(order.createdAt)} · ${order.units} dona',
                    style: const TextStyle(fontSize: 12)),
                children: [
                  const Divider(height: 5),
                  ...order.lines.map((line) => ListTile(
                    leading: Text(line.emoji, style: const TextStyle(fontSize: 29)),
                    title: Text(line.name, style: const TextStyle(fontSize: 13)),
                    subtitle: Text('${line.quantity} × ${money(line.price)}',
                        style: const TextStyle(fontSize: 12)),
                    trailing: Text(money(line.subtotal),
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  )),
                ],
              )),
            )),
          ])),
    );
  }
}
