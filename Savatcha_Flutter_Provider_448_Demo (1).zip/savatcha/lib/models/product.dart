class Product {
  const Product({
    required this.id,
    required this.name,
    required this.price,
    required this.category,
    required this.emoji,
    this.description = '',
  });

  final String id;
  final String name;
  final int price; // Butun so'mda, floating-point ishlatilmaydi.
  final String category;
  final String emoji;
  final String description;

  Product copyWith({
    String? name,
    int? price,
    String? category,
    String? emoji,
    String? description,
  }) => Product(
        id: id,
        name: name ?? this.name,
        price: price ?? this.price,
        category: category ?? this.category,
        emoji: emoji ?? this.emoji,
        description: description ?? this.description,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'price': price,
        'category': category,
        'emoji': emoji,
        'description': description,
      };

  factory Product.fromJson(Map<String, dynamic> json) {
    final id = json['id'];
    final name = json['name'];
    final price = json['price'];
    if (id is! String || name is! String || price is! int ||
        id.isEmpty || name.isEmpty || price <= 0) {
      throw const FormatException('Yaroqsiz mahsulot maʼlumoti');
    }
    return Product(
      id: id,
      name: name,
      price: price,
      category: json['category'] is String ? json['category'] as String : 'Boshqa',
      emoji: json['emoji'] is String ? json['emoji'] as String : '🛍️',
      description: json['description'] is String ? json['description'] as String : '',
    );
  }
}
