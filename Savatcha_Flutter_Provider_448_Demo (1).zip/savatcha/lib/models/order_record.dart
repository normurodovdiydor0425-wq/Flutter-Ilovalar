class OrderLine {
  const OrderLine({required this.name, required this.price, required this.quantity, required this.emoji});

  final String name;
  final int price;
  final int quantity;
  final String emoji;

  int get subtotal => price * quantity;

  Map<String, dynamic> toJson() => {
    'name': name, 'price': price, 'quantity': quantity, 'emoji': emoji,
  };

  factory OrderLine.fromJson(Map<String, dynamic> json) => OrderLine(
    name: json['name'] as String,
    price: json['price'] as int,
    quantity: json['quantity'] as int,
    emoji: json['emoji'] as String,
  );
}

class OrderRecord {
  const OrderRecord({required this.id, required this.createdAt, required this.lines});

  final String id;
  final DateTime createdAt;
  final List<OrderLine> lines;

  int get total => lines.fold(0, (sum, item) => sum + item.subtotal);
  int get units => lines.fold(0, (sum, item) => sum + item.quantity);

  Map<String, dynamic> toJson() => {
    'id': id,
    'createdAt': createdAt.toIso8601String(),
    'lines': lines.map((item) => item.toJson()).toList(),
  };

  factory OrderRecord.fromJson(Map<String, dynamic> json) => OrderRecord(
    id: json['id'] as String,
    createdAt: DateTime.parse(json['createdAt'] as String),
    lines: (json['lines'] as List)
        .map((item) => OrderLine.fromJson(Map<String, dynamic>.from(item as Map)))
        .toList(),
  );
}
