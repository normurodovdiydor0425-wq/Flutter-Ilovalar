import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/order_record.dart';
import '../models/product.dart';

/// Testlarda haqiqiy platforma plaginini ishga tushirmaslik uchun
/// xotira interfeysi. Ishlab turgan Android ilovasida esa
/// SharedPreferencesAsyncStringStorage ishlatiladi.
abstract class StringStorage {
  Future<String?> getString(String key);
  Future<void> setString(String key, String value);
  Future<void> remove(String key);
}

class SharedPreferencesStringStorage implements StringStorage {
  SharedPreferencesStringStorage([SharedPreferencesAsync? preferences])
      : _prefs = preferences ?? SharedPreferencesAsync();

  final SharedPreferencesAsync _prefs;

  @override
  Future<String?> getString(String key) => _prefs.getString(key);

  @override
  Future<void> setString(String key, String value) => _prefs.setString(key, value);

  @override
  Future<void> remove(String key) => _prefs.remove(key);
}

/// Kichik offline katalog uchun bir nechta JSON yozuvini saqlaydi.
/// Har bir kalitdagi yozuvlar ketma-ket bajariladi: tez bosilgan +/-
/// amallaridan eski javob keyingi holatni qayta yozib yubormaydi.
class LocalStorageService {
  LocalStorageService([StringStorage? preferences])
      : _prefs = preferences ?? SharedPreferencesStringStorage();

  final StringStorage _prefs;
  final Map<String, Future<void>> _pending = {};
  String? warning;

  static const _catalogKey = 'savatcha_catalog_v1';
  static const _cartKey = 'savatcha_cart_v1';
  static const _ordersKey = 'savatcha_orders_v1';
  static const _themeKey = 'savatcha_theme_v1';

  Future<List<Product>?> loadProducts() async {
    final raw = await _safeRead(_catalogKey);
    if (raw == null) return null;
    try {
      return (jsonDecode(raw) as List)
          .map((value) => Product.fromJson(Map<String, dynamic>.from(value as Map)))
          .toList();
    } catch (error) {
      warning = 'Saqlangan katalog o‘qilmadi. Bo‘sh katalog ochildi.';
      debugPrint('Catalog decode: $error');
      return [];
    }
  }

  Future<Map<String, int>?> loadCart() async {
    final raw = await _safeRead(_cartKey);
    if (raw == null) return null;
    try {
      final decoded = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      return decoded.map((key, value) => MapEntry(key, value as int))
        ..removeWhere((key, value) => value <= 0);
    } catch (error) {
      warning = 'Saqlangan savatcha o‘qilmadi. Bo‘sh savatcha ochildi.';
      debugPrint('Cart decode: $error');
      return {};
    }
  }

  Future<List<OrderRecord>> loadOrders() async {
    final raw = await _safeRead(_ordersKey);
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List)
          .map((value) => OrderRecord.fromJson(Map<String, dynamic>.from(value as Map)))
          .toList();
    } catch (error) {
      warning = 'Buyurtmalar tarixi o‘qilmadi.';
      debugPrint('Orders decode: $error');
      return [];
    }
  }

  Future<bool> loadDarkMode() async => (await _safeRead(_themeKey)) == 'dark';

  Future<String?> _safeRead(String key) async {
    try {
      return await _prefs.getString(key);
    } catch (error) {
      warning = 'Telefon xotirasidan maʼlumotlarni o‘qishda xatolik.';
      debugPrint('SharedPreferences read: $error');
      return null;
    }
  }

  Future<void> saveProducts(List<Product> products) => _write(
        _catalogKey, jsonEncode(products.map((item) => item.toJson()).toList()));

  Future<void> saveCart(Map<String, int> quantities) =>
      _write(_cartKey, jsonEncode(quantities));

  Future<void> saveOrders(List<OrderRecord> orders) => _write(
        _ordersKey, jsonEncode(orders.map((item) => item.toJson()).toList()));

  Future<void> saveDarkMode(bool dark) => _write(_themeKey, dark ? 'dark' : 'light');

  Future<void> _write(String key, String value) {
    final previous = _pending[key] ?? Future<void>.value();
    final next = previous.then((_) => _prefs.setString(key, value)).catchError(
      (Object error, StackTrace stack) {
        debugPrint('SharedPreferences write [$key]: $error');
      },
    );
    _pending[key] = next;
    return next;
  }

  Future<void> clearAll() async {
    await Future.wait(_pending.values);
    for (final key in [_catalogKey, _cartKey, _ordersKey, _themeKey]) {
      await _prefs.remove(key);
    }
  }
}
