import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'data/demo_products.dart';
import 'providers/cart_provider.dart';
import 'providers/catalog_provider.dart';
import 'providers/orders_provider.dart';
import 'providers/theme_provider.dart';
import 'services/local_storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final storage = LocalStorageService();
  final savedCatalog = await storage.loadProducts();
  final products = savedCatalog ?? DemoProducts.all;
  if (savedCatalog == null) await storage.saveProducts(products);

  final catalog = CatalogProvider(storage, products);
  final savedCart = await storage.loadCart();
  final quantities = savedCart ?? {
    'demo_apple': 2,
    'demo_banana': 1,
    'demo_strawberry': 1,
  };
  if (savedCart == null) await storage.saveCart(quantities);

  final cart = CartProvider(storage, catalog, quantities);
  final orders = OrdersProvider(storage, await storage.loadOrders());
  final theme = ThemeProvider(storage, await storage.loadDarkMode());

  runApp(MultiProvider(
    providers: [
      Provider<LocalStorageService>.value(value: storage),
      ChangeNotifierProvider<CatalogProvider>.value(value: catalog),
      ChangeNotifierProvider<CartProvider>.value(value: cart),
      ChangeNotifierProvider<OrdersProvider>.value(value: orders),
      ChangeNotifierProvider<ThemeProvider>.value(value: theme),
    ],
    child: SavatchaApp(startupWarning: storage.warning),
  ));
}
