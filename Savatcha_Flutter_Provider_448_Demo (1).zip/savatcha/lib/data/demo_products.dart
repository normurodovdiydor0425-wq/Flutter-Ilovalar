import '../models/product.dart';

class DemoProducts {
  static const categories = [
    'Mevalar', 'Sabzavotlar', 'Sut mahsulotlari', 'Non va don',
    'Ichimliklar', 'Go‘sht va baliq', 'Shirinliklar', 'Uy-ro‘zg‘or',
  ];

  static final List<Product> all = [
    ..._baseProducts,
    ..._bundleVariants(),
  ];

  static final List<Product> _baseProducts = [
    // 8 toifa × 8 asosiy mahsulot = 64 ta.
    _p('apple', 'Olma', 15000, 'Mevalar', '🍎'),
    _p('banana', 'Banan', 27000, 'Mevalar', '🍌'),
    _p('mango', 'Mango', 49000, 'Mevalar', '🥭'),
    _p('strawberry', 'Qulupnay', 45000, 'Mevalar', '🍓'),
    _p('orange', 'Apelsin', 23000, 'Mevalar', '🍊'),
    _p('pear', 'Nok', 21000, 'Mevalar', '🍐'),
    _p('grapes', 'Uzum', 28000, 'Mevalar', '🍇'),
    _p('watermelon', 'Tarvuz', 35000, 'Mevalar', '🍉'),

    _p('tomato', 'Pomidor', 18000, 'Sabzavotlar', '🍅'),
    _p('cucumber', 'Bodring', 16000, 'Sabzavotlar', '🥒'),
    _p('carrot', 'Sabzi', 8000, 'Sabzavotlar', '🥕'),
    _p('potato', 'Kartoshka', 7000, 'Sabzavotlar', '🥔'),
    _p('onion', 'Piyoz', 6000, 'Sabzavotlar', '🧅'),
    _p('broccoli', 'Brokkoli', 25000, 'Sabzavotlar', '🥦'),
    _p('pepper', 'Bulg‘or qalampiri', 22000, 'Sabzavotlar', '🫑'),
    _p('garlic', 'Sarimsoq', 15000, 'Sabzavotlar', '🧄'),

    _p('milk', 'Sut 1 litr', 12000, 'Sut mahsulotlari', '🥛'),
    _p('cheese', 'Pishloq 200 g', 26000, 'Sut mahsulotlari', '🧀'),
    _p('butter', 'Sariyog‘ 200 g', 28000, 'Sut mahsulotlari', '🧈'),
    _p('yogurt', 'Yogurt 400 g', 16000, 'Sut mahsulotlari', '🥣'),
    _p('kefir', 'Kefir 1 litr', 14000, 'Sut mahsulotlari', '🥛'),
    _p('cream', 'Qaymoq 200 g', 20000, 'Sut mahsulotlari', '🥣'),
    _p('cottage', 'Tvorog 250 g', 22000, 'Sut mahsulotlari', '🧀'),
    _p('icecream', 'Muzqaymoq', 9000, 'Sut mahsulotlari', '🍦'),

    _p('bread', 'Non', 4000, 'Non va don', '🍞'),
    _p('rice', 'Guruch 1 kg', 18000, 'Non va don', '🍚'),
    _p('flour', 'Un 1 kg', 10000, 'Non va don', '🌾'),
    _p('pasta', 'Makaron 500 g', 12000, 'Non va don', '🍝'),
    _p('oats', 'Suli yormasi', 19000, 'Non va don', '🥣'),
    _p('buckwheat', 'Grechka 1 kg', 24000, 'Non va don', '🌾'),
    _p('baguette', 'Baton non', 7000, 'Non va don', '🥖'),
    _p('cereal', 'Makkajo‘xori doni', 17000, 'Non va don', '🌽'),

    _p('water', 'Suv 1,5 litr', 4000, 'Ichimliklar', '💧'),
    _p('cola', 'Gazli ichimlik 1 l', 12000, 'Ichimliklar', '🥤'),
    _p('juice', 'Olma sharbati 1 l', 16000, 'Ichimliklar', '🧃'),
    _p('tea', 'Ko‘k choy 100 g', 13000, 'Ichimliklar', '🍵'),
    _p('coffee', 'Qahva 100 g', 32000, 'Ichimliklar', '☕'),
    _p('lemonade', 'Limonad 1 l', 11000, 'Ichimliklar', '🍋'),
    _p('smoothie', 'Mevali smuzi', 21000, 'Ichimliklar', '🥤'),
    _p('compote', 'Kompot 1 l', 14000, 'Ichimliklar', '🫗'),

    _p('chicken', 'Tovuq go‘shti 1 kg', 44000, 'Go‘sht va baliq', '🍗'),
    _p('beef', 'Mol go‘shti 1 kg', 110000, 'Go‘sht va baliq', '🥩'),
    _p('fish', 'Baliq 1 kg', 58000, 'Go‘sht va baliq', '🐟'),
    _p('egg', 'Tuxum 10 dona', 18000, 'Go‘sht va baliq', '🥚'),
    _p('sausage', 'Kolbasa 500 g', 39000, 'Go‘sht va baliq', '🌭'),
    _p('turkey', 'Kurka go‘shti 1 kg', 72000, 'Go‘sht va baliq', '🍗'),
    _p('shrimp', 'Krevetka 300 g', 85000, 'Go‘sht va baliq', '🦐'),
    _p('meatballs', 'Kotlet 500 g', 38000, 'Go‘sht va baliq', '🍖'),

    _p('chocolate', 'Shokolad', 15000, 'Shirinliklar', '🍫'),
    _p('cookies', 'Pechenye 300 g', 14000, 'Shirinliklar', '🍪'),
    _p('cake', 'Tort', 95000, 'Shirinliklar', '🎂'),
    _p('candy', 'Konfet 500 g', 38000, 'Shirinliklar', '🍬'),
    _p('honey', 'Asal 500 g', 65000, 'Shirinliklar', '🍯'),
    _p('jam', 'Murabbo 500 g', 26000, 'Shirinliklar', '🍓'),
    _p('donut', 'Ponchik', 11000, 'Shirinliklar', '🍩'),
    _p('wafer', 'Vafli', 12000, 'Shirinliklar', '🧇'),

    _p('soap', 'Sovun', 7000, 'Uy-ro‘zg‘or', '🧼'),
    _p('detergent', 'Kir yuvish kukuni', 42000, 'Uy-ro‘zg‘or', '🫧'),
    _p('tissue', 'Salfetka', 9000, 'Uy-ro‘zg‘or', '🧻'),
    _p('shampoo', 'Shampun', 34000, 'Uy-ro‘zg‘or', '🧴'),
    _p('toothbrush', 'Tish cho‘tkasi', 12000, 'Uy-ro‘zg‘or', '🪥'),
    _p('toothpaste', 'Tish pastasi', 18000, 'Uy-ro‘zg‘or', '🦷'),
    _p('sponge', 'Gubka', 6000, 'Uy-ro‘zg‘or', '🧽'),
    _p('broom', 'Supurgi', 29000, 'Uy-ro‘zg‘or', '🧹'),
  ];

  /// Har bir 8 mahsulotga yana 6 xil to‘plam qo‘shiladi.
  /// 8 toifa × (8 oddiy + 48 to‘plam) = 448 ta offline demo mahsulot.
  /// Bular real do‘kon narxlari emas; hisoblashni sinash uchun qo‘shilgan.
  static List<Product> _bundleVariants() {
    const packs = [2, 3, 4, 5, 6, 8];
    const discounts = [0, 2, 4, 6, 8, 10];
    return [
      for (final base in _baseProducts)
        for (var i = 0; i < packs.length; i++)
          Product(
            id: '${base.id}_pack_${packs[i]}',
            name: '${base.name} · ${packs[i]} talik to‘plam',
            price: base.price * packs[i] * (100 - discounts[i]) ~/ 100,
            category: base.category,
            emoji: base.emoji,
            description: '${base.name} mahsulotidan ${packs[i]} dona. '
                'Namoyish uchun shartli ${discounts[i]}% to‘plam chegirmasi qo‘llangan.',
          ),
    ];
  }

  static Product _p(String id, String name, int price, String category, String emoji) =>
      Product(id: 'demo_$id', name: name, price: price, category: category,
          emoji: emoji, description: '$name — namoyish uchun qo‘shilgan mahsulot. Narx taxminiy.');
}
