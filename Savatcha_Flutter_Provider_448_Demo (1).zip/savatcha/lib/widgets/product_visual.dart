import 'package:flutter/material.dart';
import '../core/app_theme.dart';

class ProductVisual extends StatelessWidget {
  const ProductVisual({super.key, required this.emoji, this.size = 84, this.radius = 18});

  final String emoji;
  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      height: size,
      width: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: dark
              ? [const Color(0xFF203E30), const Color(0xFF1A3025)]
              : [const Color(0xFFECF9EE), const Color(0xFFE3F5E9)],
        ),
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Padding(
          padding: EdgeInsets.all(size * .09),
          child: Text(emoji, style: TextStyle(fontSize: size * .57),
              textAlign: TextAlign.center),
        ),
      ),
    );
  }
}

class SectionHeading extends StatelessWidget {
  const SectionHeading(this.text, {super.key, this.action});
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(child: Text(text, style: const TextStyle(
              fontSize: 19, fontWeight: FontWeight.w800))),
          if (action != null) action!,
        ],
      );
}

class PrimaryEmptyState extends StatelessWidget {
  const PrimaryEmptyState({super.key, required this.icon, required this.title,
      required this.subtitle, this.buttonText, this.onPressed});
  final IconData icon;
  final String title;
  final String subtitle;
  final String? buttonText;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(color: brandGreen.withValues(alpha: .10),
                  shape: BoxShape.circle),
              child: Icon(icon, size: 55, color: brandGreen),
            ),
            const SizedBox(height: 20),
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(subtitle, textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Theme.of(context).hintColor)),
            if (buttonText != null && onPressed != null) ...[
              const SizedBox(height: 24),
              ElevatedButton(onPressed: onPressed, child: Text(buttonText!)),
            ],
          ]),
        ),
      );
}
