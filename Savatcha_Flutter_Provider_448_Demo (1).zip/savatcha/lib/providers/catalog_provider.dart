import 'dart:async';
import 'package:flutter/foundation.dart';

import '../models/product.dart';
import '../services/local_storage_service.dart';

class CatalogProvider extends ChangeNotifier {
  CatalogProvider(this._storage, List<Product> initial)
      : _products = List<Product>.from(initial);

  final LocalStorageService _storage;
  final List<Product> _products;

  List<Product> get products => List.unmodifiable(_products);
  int get count => _products.length;

  Product? findById(String id) {
    for (final product in _products) {
      if (product.id == id) return product;
    }
    return null;
  }

  void addProduct(Product product) {
    if (product.name.trim().isEmpty || product.price <= 0 ||
        findById(product.id) != null) {
      throw ArgumentError('Mahsulot maʼlumoti noto‘g‘ri yoki ID takrorlangan');
    }
    _products.insert(0, product);
    _changed();
  }

  void updateProduct(Product product) {
    if (product.name.trim().isEmpty || product.price <= 0) {
      throw ArgumentError('Nom va narx to‘g‘ri kiritilishi shart');
    }
    final index = _products.indexWhere((item) => item.id == product.id);
    if (index < 0) throw StateError('Mahsulot topilmadi');
    _products[index] = product;
    _changed();
  }

  void deleteProduct(String id) {
    final before = _products.length;
    _products.removeWhere((product) => product.id == id);
    if (_products.length != before) _changed();
  }

  void clear() {
    _products.clear();
    _changed();
  }

  void _changed() {
    notifyListeners();
    unawaited(_storage.saveProducts(_products));
  }
}
