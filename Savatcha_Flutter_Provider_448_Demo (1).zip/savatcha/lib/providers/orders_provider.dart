import 'dart:async';
import 'package:flutter/foundation.dart';

import '../models/order_record.dart';
import '../services/local_storage_service.dart';
import 'cart_provider.dart';

class OrdersProvider extends ChangeNotifier {
  OrdersProvider(this._storage, List<OrderRecord> initial)
      : _orders = List<OrderRecord>.from(initial);

  final LocalStorageService _storage;
  final List<OrderRecord> _orders;

  List<OrderRecord> get orders => List.unmodifiable(_orders);

  OrderRecord? checkout(CartProvider cart) {
    final items = cart.items;
    if (items.isEmpty) return null;
    final order = OrderRecord(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      createdAt: DateTime.now(),
      lines: List.unmodifiable([
        for (final item in items)
          OrderLine(
            name: item.product.name,
            price: item.product.price,
            quantity: item.quantity,
            emoji: item.product.emoji,
          ),
      ]),
    );
    _orders.insert(0, order);
    notifyListeners();
    unawaited(_storage.saveOrders(_orders));
    cart.clearCart();
    return order;
  }

  void clear() {
    _orders.clear();
    notifyListeners();
    unawaited(_storage.saveOrders(_orders));
  }
}
