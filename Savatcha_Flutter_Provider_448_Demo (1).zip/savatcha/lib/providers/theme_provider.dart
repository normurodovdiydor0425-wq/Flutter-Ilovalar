import 'dart:async';
import 'package:flutter/material.dart';

import '../services/local_storage_service.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeProvider(this._storage, bool dark) : _dark = dark;

  final LocalStorageService _storage;
  bool _dark;

  bool get isDark => _dark;
  ThemeMode get themeMode => _dark ? ThemeMode.dark : ThemeMode.light;

  void setDark(bool dark) {
    if (_dark == dark) return;
    _dark = dark;
    notifyListeners();
    unawaited(_storage.saveDarkMode(dark));
  }
}
