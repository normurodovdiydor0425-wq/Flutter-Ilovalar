import 'dart:async';
import 'package:flutter/foundation.dart';

import '../models/cart_item.dart';
import '../services/local_storage_service.dart';
import 'catalog_provider.dart';

class CartProvider extends ChangeNotifier {
  CartProvider(this._storage, this._catalog, Map<String, int> initial)
      : _quantities = Map<String, int>.from(initial) {
    _removeOrphans();
    _catalog.addListener(_onCatalogChanged);
  }

  final LocalStorageService _storage;
  final CatalogProvider _catalog;
  final Map<String, int> _quantities;

  List<CartItem> get items {
    final result = <CartItem>[];
    for (final entry in _quantities.entries) {
      final product = _catalog.findById(entry.key);
      if (product != null) {
        result.add(CartItem(product: product, quantity: entry.value));
      }
    }
    return List.unmodifiable(result);
  }

  int quantityOf(String id) => _quantities[id] ?? 0;
  int get distinctItemsCount => items.length;
  int get totalUnits => _quantities.values.fold(0, (sum, qty) => sum + qty);
  int get totalPrice => items.fold(0, (sum, item) => sum + item.subtotal);

  void addToCart(String id) {
    if (_catalog.findById(id) == null) return;
    _quantities[id] = (_quantities[id] ?? 0) + 1;
    _changed();
  }

  void incrementQuantity(String id) => addToCart(id);

  void decrementQuantity(String id) {
    final previous = _quantities[id];
    if (previous == null || previous <= 1) return;
    _quantities[id] = previous - 1;
    _changed();
  }

  int removeFromCart(String id) {
    final previous = _quantities.remove(id) ?? 0;
    if (previous > 0) _changed();
    return previous;
  }

  void restoreQuantity(String id, int quantity) {
    if (quantity < 1 || _catalog.findById(id) == null) return;
    _quantities[id] = quantity;
    _changed();
  }

  void clearCart() {
    if (_quantities.isEmpty) return;
    _quantities.clear();
    _changed();
  }

  bool _removeOrphans() {
    final count = _quantities.length;
    _quantities.removeWhere((id, qty) => qty <= 0 || _catalog.findById(id) == null);
    return count != _quantities.length;
  }

  void _onCatalogChanged() {
    final changed = _removeOrphans();
    notifyListeners(); // Narx yangilanishi totalPrice'ni ham yangilaydi.
    if (changed) unawaited(_storage.saveCart(_quantities));
  }

  void _changed() {
    notifyListeners();
    unawaited(_storage.saveCart(_quantities));
  }

  @override
  void dispose() {
    _catalog.removeListener(_onCatalogChanged);
    super.dispose();
  }
}
