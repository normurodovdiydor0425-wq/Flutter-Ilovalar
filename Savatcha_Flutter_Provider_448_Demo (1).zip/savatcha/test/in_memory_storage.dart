import 'package:savatcha/services/local_storage_service.dart';

/// Flutter testda SharedPreferences plaginiga ehtiyoj qolmaydi.
class InMemoryStringStorage implements StringStorage {
  final Map<String, String> values = {};

  @override
  Future<String?> getString(String key) async => values[key];

  @override
  Future<void> setString(String key, String value) async {
    values[key] = value;
  }

  @override
  Future<void> remove(String key) async {
    values.remove(key);
  }
}
