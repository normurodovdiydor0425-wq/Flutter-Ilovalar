import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:savatcha/providers/catalog_provider.dart';
import 'package:savatcha/screens/product_form_screen.dart';
import 'package:savatcha/services/local_storage_service.dart';
import 'in_memory_storage.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('Bo‘sh forma saqlanmasligi kerak', (tester) async {
    final catalog = CatalogProvider(LocalStorageService(InMemoryStringStorage()), []);
    await tester.pumpWidget(ChangeNotifierProvider.value(
      value: catalog,
      child: const MaterialApp(home: ProductFormScreen()),
    ));

    await tester.ensureVisible(find.text('Mahsulotni qo‘shish'));
    await tester.tap(find.text('Mahsulotni qo‘shish'));
    await tester.pumpAndSettle();
    expect(catalog.count, 0);
    expect(find.text('Mahsulot nomini kiriting'), findsOneWidget);
    expect(find.text('Musbat butun narx kiriting'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
    catalog.dispose();
  });
}
