import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:savatcha/widgets/product_visual.dart';

void main() {
  testWidgets('Bo‘sh savatcha matni va tugmasi ko‘rinadi', (tester) async {
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: PrimaryEmptyState(
          icon: Icons.remove_shopping_cart_outlined,
          title: 'Savatchangiz bo‘sh',
          subtitle: 'Mahsulot qo‘shing',
          buttonText: 'Mahsulotlarni ko‘rish',
          onPressed: () {},
        ),
      ),
    ));

    expect(find.text('Savatchangiz bo‘sh'), findsOneWidget);
    expect(find.text('Mahsulotlarni ko‘rish'), findsOneWidget);
  });
}
