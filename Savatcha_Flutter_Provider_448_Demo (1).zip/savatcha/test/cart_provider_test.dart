import 'package:flutter_test/flutter_test.dart';
import 'package:savatcha/data/demo_products.dart';
import 'package:savatcha/models/product.dart';
import 'package:savatcha/providers/cart_provider.dart';
import 'package:savatcha/providers/catalog_provider.dart';
import 'package:savatcha/providers/orders_provider.dart';
import 'package:savatcha/services/local_storage_service.dart';
import 'in_memory_storage.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late LocalStorageService store;
  late CatalogProvider catalog;
  late CartProvider cart;
  late InMemoryStringStorage memory;

  const non = Product(id: 'non', name: 'Non', price: 4000,
      category: 'Non va don', emoji: '🍞');
  const sut = Product(id: 'sut', name: 'Sut', price: 12000,
      category: 'Sut mahsulotlari', emoji: '🥛');

  setUp(() {
    memory = InMemoryStringStorage();
    store = LocalStorageService(memory);
    catalog = CatalogProvider(store, [non, sut]);
    cart = CartProvider(store, catalog, {});
  });

  tearDown(() {
    cart.dispose();
    catalog.dispose();
  });

  test('Demo katalogda 8 toifada 56 tadan mahsulot bor', () {
    expect(DemoProducts.categories.length, 8);
    expect(DemoProducts.all.length, 448);
    for (final category in DemoProducts.categories) {
      expect(DemoProducts.all.where((p) => p.category == category).length, 56);
    }
    expect(DemoProducts.all.every((p) => p.price > 0), isTrue);
    expect(DemoProducts.all.map((p) => p.id).toSet().length, 448);
  });

  test('Bir mahsulot ikki marta qo‘shilsa bitta qator, 2 dona', () {
    cart.addToCart(non.id);
    cart.addToCart(non.id);
    expect(cart.distinctItemsCount, 1);
    expect(cart.totalUnits, 2);
    expect(cart.totalPrice, 8000);
  });

  test('Jami narx va +/- amallari', () {
    cart.addToCart(non.id);
    cart.addToCart(non.id);
    cart.addToCart(sut.id);
    cart.addToCart(sut.id);
    cart.addToCart(sut.id);
    expect(cart.distinctItemsCount, 2);
    expect(cart.totalUnits, 5);
    expect(cart.totalPrice, 44000);

    cart.decrementQuantity(sut.id);
    expect(cart.totalPrice, 32000);
    cart.decrementQuantity(non.id);
    cart.decrementQuantity(non.id);
    expect(cart.quantityOf(non.id), 1); // nolga tushmasin
  });

  test('Mahsulot narxi tahrir qilinsa jami qayta hisoblanadi', () {
    cart.addToCart(sut.id);
    catalog.updateProduct(sut.copyWith(price: 15000));
    expect(cart.totalPrice, 15000);
    expect(cart.items.first.product.price, 15000);
  });

  test('Savatchadan o‘chirish katalogni saqlaydi va undo ishlaydi', () {
    cart.addToCart(non.id);
    cart.addToCart(non.id);
    final old = cart.removeFromCart(non.id);
    expect(old, 2);
    expect(cart.totalPrice, 0);
    expect(catalog.findById(non.id), isNotNull);
    cart.restoreQuantity(non.id, old);
    expect(cart.totalPrice, 8000);
  });

  test('Katalogdan o‘chirish savatchadagi qatorni ham olib tashlaydi', () {
    cart.addToCart(sut.id);
    catalog.deleteProduct(sut.id);
    expect(cart.items, isEmpty);
    expect(cart.totalUnits, 0);
  });

  test('Savatchani tozalash katalogni o‘chirmaydi', () {
    cart.addToCart(non.id);
    cart.clearCart();
    expect(cart.totalPrice, 0);
    expect(catalog.count, 2);
  });

  test('Demo buyurtma tarixga qo‘shiladi, savatcha bo‘shaydi', () {
    final orders = OrdersProvider(store, []);
    cart.addToCart(non.id);
    final order = orders.checkout(cart);
    expect(order?.total, 4000);
    expect(orders.orders.length, 1);
    expect(cart.items, isEmpty);
    orders.dispose();
  });

  test('JSON saqlanadi va keyin qayta yuklanadi', () async {
    await store.saveProducts([non, sut]);
    await store.saveCart({'non': 2, 'sut': 3});
    final again = LocalStorageService(memory);
    expect((await again.loadProducts())?.length, 2);
    expect(await again.loadCart(), {'non': 2, 'sut': 3});
  });
}
