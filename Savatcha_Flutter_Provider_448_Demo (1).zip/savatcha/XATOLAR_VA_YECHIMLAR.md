# Android Studio ekranida ko‘ringan xatolar va yechimlar

## 1. `Dart support is not enabled for the module 'savatcha'`

- `main.dart` tepasi chiqargan **Enable Dart support** havolasini bosing.
- Agar so‘ralsa: **Settings → Languages & Frameworks → Dart** ichida `Enable Dart support for the project`ni yoqing.
- **Dart SDK path** sifatida `C:\Flutter\flutter\bin\cache\dart-sdk`ni tanlang (Flutter boshqa joyga o‘rnatilgan bo‘lsa, o‘sha yo‘ldan foydalaning).
- **Settings → Languages & Frameworks → Flutter** ichida **Flutter SDK path**ni `C:\Flutter\flutter`ga sozlang.
- **Settings → Plugins** ichida Dart va Flutter plaginlari yoqilganini tekshiring.

## 2. `No supported devices connected` va `flutter run`

Bu xabar Android telefon/emulyator ulanmaganini anglatadi. Windows va Chrome ko‘rsatilgan bo‘lsa ham loyiha faqat Android platformasi uchun yaratilgan.

**Emulyator usuli**:

1. Android Studio → **Tools → Device Manager**.
2. `+` → **Create Virtual Device**.
3. `Phone` → `Pixel 7` yoki mavjud boshqa model → `Next`.
4. Android system image'ni yuklab oling, `Finish`.
5. Emulyator yonidagi `▶` tugmasini bosing, telefon oynasi ochilsin.
6. Terminalda:

   ```powershell
   flutter devices
   flutter run
   ```

**Haqiqiy telefon usuli**: telefonda Developer Options → USB debugging yoqing, USB kabel orqali ulang, telefondagi ruxsat oynasini tasdiqlang va `flutter devices`ni bajaring.

## 3. `flutter test`: `MyApp` va `SharedPreferencesAsyncPlatform` xatolari

Terminal logi muammoni aniq ko‘rsatdi:

- `flutter create` avtomatik yaratgan `test/widget_test.dart` bizda mavjud bo‘lmagan `MyApp`ni chaqirgan. Yangilangan ZIPda bu test Savatcha vidjetini tekshiradigan to‘g‘ri fayl bilan almashtirildi.
- `SharedPreferences.setMockInitialValues` yangi `SharedPreferencesAsync` konstruktorini ushbu versiyada sozlamagan. Yangilangan kodda `StringStorage` interfeysi va `InMemoryStringStorage` test nusxasi bor, shuning uchun testlar Android plaginini chaqirmaydi.
- Mahsulot qo‘shish formasi `SingleChildScrollView + Column`ga o‘tkazildi, barcha maydonlar validatsiyada qatnashadi. `int.tryParse` narxni xavfsiz tekshiradi.

Yangi ZIP faylni ochgach quyidagilarni qayta bajaring:

```powershell
flutter pub get
flutter analyze
flutter test
```

Agar yana xato bo‘lsa, **terminaldagi birinchi `EXCEPTION` qatori va undan keyingi 15–20 qatorni** yuboring.

## 4. Gradle: `Could not close incremental caches` va `different roots`

Xatoda Pub Cache `C:` diskda, loyiha `E:` diskda ekani ko‘rsatilgan. Kotlin incremental compilation keshlari yo‘llarni solishtirishda xato qilgan.

1. Android Studio'da `E:\savatcha\android\gradle.properties` faylini oching.
2. Oxiriga yangi qatorda aynan quyidagini qo‘shing:

   ```properties
   kotlin.incremental=false
   ```

3. Faylni `Ctrl+S` bilan saqlang. Terminalda **`E:\savatcha`** papkasida:

   ```powershell
   flutter clean
   flutter pub get
   flutter test
   flutter run -d emulator-5554
   ```

`flutter clean` build keshini o‘chiradi, **siz yozgan `lib/` kodlarni o‘chirmaydi**. Birinchi toza yig‘ish yana vaqt olishi mumkin. Agar ayni Kotlin xatosi qaytarilsa, loyiha nusxasini `C:\FlutterProjects\savatcha`ga ko‘chirish va o‘sha yerdan ishga tushirish mumkin — original `E:` nusxasini saqlab qo‘ying.

Kotlin rasmiy hujjatida `kotlin.incremental=false` JVM incremental compilationni o‘chirish parametri sifatida keltirilgan.

## 5. APK tayyorlash

Emulyator bo‘lishi APK yig‘ish uchun majburiy emas. Android SDK o‘rnatilgan bo‘lsa:

```powershell
flutter build apk --release
```

Natija: `build\app\outputs\flutter-apk\app-release.apk`.
