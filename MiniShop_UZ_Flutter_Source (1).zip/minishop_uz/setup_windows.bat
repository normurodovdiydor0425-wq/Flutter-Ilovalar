@echo off
setlocal
title MiniShop UZ - Flutter loyihasini sozlash
cd /d "%~dp0"
where flutter >nul 2>nul
if errorlevel 1 (
  echo XATO: flutter topilmadi. Flutter SDK PATH ga qo'shilganini tekshiring.
  pause
  exit /b 1
)
echo Android, Windows va Web platforma fayllari yaratilmoqda...
call flutter create --platforms=android,windows,web --org uz.diydor --project-name minishop_uz .
if errorlevel 1 goto failed
echo.
echo Paketlar yuklanmoqda...
call flutter pub get
if errorlevel 1 goto failed
echo.
echo TAYYOR!
echo Tekshiruv: flutter analyze
echo Test:      flutter test
echo Emulator:  flutter devices va flutter run
echo APK:       flutter build apk --release
pause
exit /b 0
:failed
echo XATO: Sozlashda muammo yuz berdi. Yuqoridagi xabarni tekshiring.
pause
exit /b 1
