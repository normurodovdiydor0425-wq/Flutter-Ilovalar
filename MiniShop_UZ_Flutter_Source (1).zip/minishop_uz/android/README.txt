Android platforma fayllari Flutter SDK tomonidan yaratiladi.
Windowsda loyiha ildizidagi setup_windows.bat faylini ishga tushiring.
Yoki terminalda: flutter create --platforms=android,windows,web --org uz.diydor --project-name minishop_uz .
Keyin: flutter pub get va flutter run.
