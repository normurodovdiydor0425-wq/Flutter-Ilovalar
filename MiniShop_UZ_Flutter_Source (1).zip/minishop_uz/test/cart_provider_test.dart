import 'package:flutter_test/flutter_test.dart';
import 'package:minishop_uz/data/demo_products.dart';
import 'package:minishop_uz/models/cart_item.dart';
import 'package:minishop_uz/providers/cart_provider.dart';

import 'test_storage.dart';

void main() {
  test('Mahsulot soni va umumiy narx to‘g‘ri hisoblanadi', () async {
    final cart = CartProvider(TestStorage(), demoProducts);
    await cart.load();
    final first = demoProducts[0];
    final second = demoProducts[1];
    expect(cart.add(first, quantity: 2), isTrue);
    expect(cart.add(second, quantity: 3), isTrue);
    expect(cart.itemCount, 5);
    expect(cart.distinctCount, 2);
    expect(cart.subtotal, first.price * 2 + second.price * 3);
    cart.decrease(first.id);
    expect(cart.quantityFor(first.id), 1);
    cart.remove(first.id);
    expect(cart.itemCount, 3);
    cart.clear();
    expect(cart.itemCount, 0);
    expect(cart.subtotal, 0);
  });

  test('Ombordagi sondan ko‘p qo‘shishga ruxsat bermaydi', () async {
    final cart = CartProvider(TestStorage(), demoProducts);
    await cart.load();
    final first = demoProducts.first;
    expect(cart.add(first, quantity: first.stock), isTrue);
    expect(cart.add(first), isFalse);
    expect(cart.quantityFor(first.id), first.stock);
  });

  test('Savatcha saqlanadi va qayta ochilganda tiklanadi', () async {
    final storage = TestStorage();
    final first = CartProvider(storage, demoProducts);
    await first.load();
    first.add(demoProducts.first, quantity: 2);
    await Future<void>.delayed(Duration.zero);
    final second = CartProvider(storage, demoProducts);
    await second.load();
    expect(second.quantityFor(demoProducts.first.id), 2);
  });

  test('Saqlangan noto‘g‘ri mahsulot va miqdor tekshiriladi', () async {
    final storage = TestStorage();
    storage.cart = [
      const CartItem(productId: 'unknown-id', quantity: 5),
      CartItem(productId: demoProducts.first.id, quantity: 10000),
    ];
    final cart = CartProvider(storage, demoProducts);
    await cart.load();
    expect(cart.distinctCount, 1);
    expect(cart.quantityFor(demoProducts.first.id), demoProducts.first.stock);
  });
}
