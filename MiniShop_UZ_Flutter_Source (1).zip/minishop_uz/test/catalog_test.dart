import 'package:flutter_test/flutter_test.dart';
import 'package:minishop_uz/data/demo_products.dart';
import 'package:minishop_uz/providers/product_provider.dart';

import 'test_storage.dart';

void main() {
  test('Katalogda 100 ta noyob mahsulot va 7 ta kategoriya bor', () {
    expect(demoProducts.length, 100);
    expect(demoProducts.map((p) => p.id).toSet().length, 100);
    expect(demoProducts.map((p) => p.category).toSet().length, 7);
    expect(demoProducts.every((p) => p.price > 0 && p.stock > 0), isTrue);
  });

  test('Qidiruv va kategoriya filtri ishlaydi', () {
    final provider = ProductProvider(TestStorage(), demoProducts);
    provider.search('samsung');
    expect(provider.filteredProducts, isNotEmpty);
    expect(provider.filteredProducts.every((p) => p.name.toLowerCase().contains('samsung')), isTrue);
    provider.search('');
    provider.setCategory('Kitoblar');
    expect(provider.filteredProducts.length, 10);
    provider.setSort(ProductSort.expensiveFirst);
    expect(provider.filteredProducts.first.price >= provider.filteredProducts.last.price, isTrue);
  });

  test('Sevimlilarni saqlaydi va qayta o‘qiydi', () async {
    final storage = TestStorage();
    final provider = ProductProvider(storage, demoProducts);
    provider.toggleFavorite(demoProducts.first.id);
    await Future<void>.delayed(Duration.zero);
    final next = ProductProvider(storage, demoProducts);
    await next.load();
    expect(next.favoriteCount, 1);
    expect(next.favorites.single.id, demoProducts.first.id);
  });
}
