import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:minishop_uz/data/demo_products.dart';
import 'package:minishop_uz/providers/cart_provider.dart';
import 'package:minishop_uz/providers/product_provider.dart';
import 'package:minishop_uz/widgets/product_card.dart';
import 'package:provider/provider.dart';

import 'test_storage.dart';

void main() {
  testWidgets('Kichik kartochkada asosiy elementlar sig‘adi', (tester) async {
    final storage = TestStorage();
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => ProductProvider(storage, demoProducts)),
          ChangeNotifierProvider(create: (_) => CartProvider(storage, demoProducts)),
        ],
        child: MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 160,
                height: 310,
                child: ProductCard(product: demoProducts.first),
              ),
            ),
          ),
        ),
      ),
    );
    expect(find.text('Qo‘shish'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('Qo‘shish'));
    await tester.pump();
    expect(find.textContaining('savatchaga qo‘shildi'), findsOneWidget);
  });
}
