import 'package:minishop_uz/models/cart_item.dart';
import 'package:minishop_uz/models/order_record.dart';
import 'package:minishop_uz/services/local_storage_service.dart';

class TestStorage extends LocalStorageService {
  List<CartItem> cart = [];
  Set<String> favorites = {};
  List<OrderRecord> orders = [];
  bool dark = false;

  @override
  Future<List<CartItem>> readCart() async => List.of(cart);

  @override
  Future<void> saveCart(List<CartItem> items) async {
    cart = List.of(items);
  }

  @override
  Future<Set<String>> readFavorites() async => Set.of(favorites);

  @override
  Future<void> saveFavorites(Set<String> ids) async {
    favorites = Set.of(ids);
  }

  @override
  Future<bool> readDarkMode() async => dark;

  @override
  Future<void> saveDarkMode(bool value) async {
    dark = value;
  }

  @override
  Future<List<OrderRecord>> readOrders() async => List.of(orders);

  @override
  Future<void> saveOrders(List<OrderRecord> value) async {
    orders = List.of(value);
  }
}
