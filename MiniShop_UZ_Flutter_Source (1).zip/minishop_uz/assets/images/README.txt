Mahsulotlar hozir oflayn emoji-grafika bilan tasvirlanadi.
Haqiqiy rasmlar qo'shish uchun tegishli PNG/JPG fayllarni shu papkaga joylang.
Bu katalogdagi 100 ta nom va narxlar o'quv maqsadidagi demo ma'lumotlaridir.
