# MiniShop UZ — Flutter mini internet do‘kon

O‘zbekcha o‘quv loyihasi: 100 ta namunaviy mahsulot, 7 kategoriya, qidiruv,
saralash, mahsulot tafsilotlari, sevimlilar, savatcha va demo buyurtmalar.

> **Diqqat:** katalogdagi narxlar, reytinglar, zaxira va buyurtmalar DEMO.
> Haqiqiy to‘lov, autentifikatsiya, API yoki yetkazib berish xizmati yo‘q.

## Windows / Android Studio’da ishga tushirish

1. ZIP faylni oching. `minishop_uz` papkasini Android Studio’da **Open** qiling.
2. **`setup_windows.bat`** faylini bir marta ishga tushiring. U Android,
   Windows va Web platforma loyihalarini hosil qiladi va paketlarni yuklaydi.
3. Yoki Android Studio terminalida qo‘lda bajaring:

   ```powershell
   flutter create --platforms=android,windows,web --org uz.diydor --project-name minishop_uz .
   flutter pub get
   flutter analyze
   flutter test
   flutter devices
   flutter run
   ```

4. Qurilmalar orasidan Android emulyatorini tanlab ishga tushiring.

### Windows Developer Mode

`Building with plugins requires symlink support` xabari chiqsa,
PowerShell oynasiga `start ms-settings:developers` yozing va Windows
sozlamalaridan **Developer Mode** ni yoqing. So‘ng terminalni qayta oching.

`Build failed due to use of deleted Android v1 embedding` xabari Android
platforma fayllari yaratilmasidan oldin chiqqan bo‘lsa, yuqoridagi
`flutter create --platforms=android,windows,web ...` buyrug‘idan so‘ng
`flutter pub get` va `flutter run -d emulator-5554` ni takrorlang
(qurilma ID boshqacha bo‘lsa, `flutter devices` natijasidagini ishlating).

### APK yaratish

```powershell
flutter build apk --release
```

Muvaffaqiyatli build natijasi:
`build\app\outputs\flutter-apk\app-release.apk`.

**ZIP ichida tayyor APK yo‘q:** ilova Android SDK mavjud Windows
kompyuteringizda kompilyatsiya qilinishi kerak. Android runner fayllari
shuningdek Flutter SDK orqali avtomatik yaratiladi.

## Funksiyalar

- 100 ta noyob demo mahsulot / 7 kategoriya.
- `GridView.builder` bilan moslashuvchan katalog.
- Matnli qidiruv, kategoriya filtri va narx bo‘yicha saralash.
- Har bir mahsulot uchun batafsil ekran.
- Savatcha qo‘shish, o‘chirish, `+`/`−`, ombor sonini cheklash.
- Pastki menyudagi savatcha soni **jami miqdor**ni ko‘rsatadi.
- `shared_preferences` orqali savatcha, sevimlilar, mavzu va demo buyurtmalarni saqlash.
- Tungi rejim va o‘zbekcha interfeys.
- Lokal **demo** buyurtmalar tarixi (serverga yuborilmaydi).
- `flutter_test` bilan katalog, savatcha va kartochka testlari.

## Fayllar

`lib/models` — ma’lumot modellari; `lib/providers` — Provider state;
`lib/data` — demo katalog; `lib/services` — lokal saqlash;
`lib/widgets` — qayta ishlatiladigan komponentlar;
`lib/screens` — besh ekran.

## Dizayn eslatmasi

Mahsulotlarning tasviri hozircha emoji va gradientlardan iborat.
Shu sabab ilova internetsiz ishlaydi va tashqi tasvir manbalariga bog‘liq emas.
Keyinchalik haqiqiy mahsulot rasmlarini `assets/images` ichiga qo‘shish mumkin.
