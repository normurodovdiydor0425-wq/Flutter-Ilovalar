import 'package:flutter/material.dart';

@immutable
class Product {
  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.icon,
    required this.colorValue,
    required this.description,
    required this.stock,
    this.oldPrice,
    this.rating = 4.6,
  });

  final String id;
  final String name;
  final String category;
  final int price;
  final int? oldPrice;
  final String icon;
  final int colorValue;
  final String description;
  final int stock;
  final double rating;

  Color get color => Color(colorValue);
  bool get discounted => oldPrice != null && oldPrice! > price;
  int get discountPercent => discounted
      ? (((oldPrice! - price) / oldPrice!) * 100).round()
      : 0;
}
