class OrderRecord {
  const OrderRecord({
    required this.id,
    required this.customer,
    required this.phone,
    required this.address,
    required this.total,
    required this.itemCount,
    required this.createdAt,
  });

  final String id;
  final String customer;
  final String phone;
  final String address;
  final int total;
  final int itemCount;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'customer': customer,
        'phone': phone,
        'address': address,
        'total': total,
        'itemCount': itemCount,
        'createdAt': createdAt.toIso8601String(),
      };

  factory OrderRecord.fromJson(Map<String, dynamic> json) => OrderRecord(
        id: json['id'] as String,
        customer: json['customer'] as String,
        phone: json['phone'] as String,
        address: json['address'] as String,
        total: json['total'] as int,
        itemCount: json['itemCount'] as int,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}
