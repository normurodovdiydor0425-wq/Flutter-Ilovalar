import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/formatters.dart';
import '../providers/orders_provider.dart';
import '../providers/theme_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final orders = context.watch<OrdersProvider>().orders;

    return SafeArea(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Mening profilim', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 24)),
        const SizedBox(height: 20),
        Card(
          elevation: 0,
          color: Theme.of(context).cardColor,
          child: const ListTile(
            leading: CircleAvatar(radius: 27, child: Icon(Icons.person, size: 29)),
            title: Text('MiniShop foydalanuvchisi', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('Mehmon rejimi • O‘zbekcha'),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          elevation: 0,
          color: Theme.of(context).cardColor,
          child: SwitchListTile.adaptive(
            title: const Text('Tungi rejim'),
            subtitle: const Text('Ilova rangini almashtirish'),
            secondary: Icon(theme.isDark ? Icons.dark_mode_outlined : Icons.light_mode_outlined),
            value: theme.isDark,
            onChanged: theme.setDark,
          ),
        ),
        const SizedBox(height: 16),
        Text('Demo buyurtmalar tarixi (${orders.length})',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        if (orders.isEmpty)
          Card(
            elevation: 0,
            color: Theme.of(context).cardColor,
            child: const Padding(
              padding: EdgeInsets.all(25),
              child: Column(children: [
                Icon(Icons.receipt_long_outlined, color: Colors.grey, size: 45),
                SizedBox(height: 8),
                Text('Hozircha buyurtma yo‘q'),
              ]),
            ),
          )
        else
          ...orders.map((order) => Card(
                elevation: 0,
                color: Theme.of(context).cardColor,
                child: ListTile(
                  leading: const Icon(Icons.receipt_long),
                  title: Text('${order.itemCount} ta mahsulot • ${sumFormat(order.total)}'),
                  subtitle: Text('${order.createdAt.day.toString().padLeft(2, '0')}.${order.createdAt.month.toString().padLeft(2, '0')}.${order.createdAt.year} • ${order.customer}'),
                  trailing: const Text('DEMO', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.grey)),
                ),
              )),
        const SizedBox(height: 24),
        const Text('MiniShop UZ v1.0.0', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 5),
        const Text('Narxlar, reytinglar va mavjudlik faqat namuna.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.grey)),
      ]),
    );
  }
}
