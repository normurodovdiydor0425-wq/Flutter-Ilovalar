import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/cart_provider.dart';
import '../providers/product_provider.dart';
import '../widgets/cart_badge.dart';
import '../widgets/category_chip.dart';
import '../widgets/product_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProductProvider>();
    final products = provider.filteredProducts;
    final total = context.select<CartProvider, int>((p) => p.itemCount);
    final theme = Theme.of(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 9, bottom: 12),
              child: Row(children: [
                Container(
                  width: 43,
                  height: 43,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.shopping_bag_rounded, color: Colors.white, size: 25),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('MiniShop UZ', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: -.4)),
                    Text('Sizning kichik onlayn do‘koningiz', style: TextStyle(fontSize: 11)),
                  ]),
                ),
                Stack(clipBehavior: Clip.none, children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: theme.cardColor, borderRadius: BorderRadius.circular(14)),
                    child: const Icon(Icons.shopping_cart_outlined),
                  ),
                  Positioned(right: -5, top: -6, child: CartBadge(count: total)),
                ]),
              ]),
            ),
            Container(
              height: 105,
              padding: const EdgeInsets.all(17),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: const LinearGradient(colors: [Color(0xFF2563EB), Color(0xFF4F46E5)]),
              ),
              child: Row(children: [
                const Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('Ajoyib tanlovlar!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white)),
                    SizedBox(height: 3),
                    Text('100 ta demo mahsulot • yangi chegirmalar', maxLines: 2, style: TextStyle(fontSize: 11, color: Color(0xFFE0E7FF))),
                  ]),
                ),
                const SizedBox(width: 8),
                const Text('🛍️', style: TextStyle(fontSize: 63)),
              ]),
            ),
            const SizedBox(height: 12),
            TextField(
              onChanged: provider.search,
              textInputAction: TextInputAction.search,
              decoration: const InputDecoration(
                hintText: 'Mahsulotni qidiring...',
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 46,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: provider.categories.length,
                itemBuilder: (context, index) {
                  final name = provider.categories[index];
                  return CategoryChip(
                    title: name,
                    selected: provider.category == name,
                    onTap: () => provider.setCategory(name),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4, bottom: 7),
              child: Row(children: [
                Expanded(child: Text('${products.length} ta mahsulot', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
                PopupMenuButton<ProductSort>(
                  tooltip: 'Saralash',
                  initialValue: provider.sort,
                  onSelected: provider.setSort,
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: ProductSort.popular, child: Text('Ommabop')),
                    PopupMenuItem(value: ProductSort.cheapFirst, child: Text('Arzonidan boshlab')),
                    PopupMenuItem(value: ProductSort.expensiveFirst, child: Text('Qimmatidan boshlab')),
                    PopupMenuItem(value: ProductSort.name, child: Text('Nom bo‘yicha')),
                  ],
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.tune, size: 19), SizedBox(width: 5), Text('Saralash'), Icon(Icons.arrow_drop_down),
                  ]),
                ),
              ]),
            ),
            Expanded(
              child: products.isEmpty
                  ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.search_off_rounded, size: 65, color: Colors.grey),
                      SizedBox(height: 10),
                      Text('Mahsulot topilmadi'),
                    ]))
                  : GridView.builder(
                      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                      padding: const EdgeInsets.only(bottom: 18),
                      itemCount: products.length,
                      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 220,
                        mainAxisExtent: 310,
                        crossAxisSpacing: 11,
                        mainAxisSpacing: 11,
                      ),
                      itemBuilder: (context, index) => ProductCard(product: products[index]),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
