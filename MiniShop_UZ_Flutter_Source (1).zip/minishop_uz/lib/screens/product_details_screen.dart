import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/formatters.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../providers/product_provider.dart';
import '../widgets/product_visual.dart';

class ProductDetailsScreen extends StatefulWidget {
  const ProductDetailsScreen({super.key, required this.product});

  final Product product;

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  int _quantity = 1;

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final theme = Theme.of(context);
    final isFavorite = context.select<ProductProvider, bool>((p) => p.isFavorite(product.id));
    final inCart = context.select<CartProvider, int>((p) => p.quantityFor(product.id));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mahsulot haqida'),
        actions: [
          IconButton(
            tooltip: 'Sevimlilarga qo‘shish',
            icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border,
                color: isFavorite ? const Color(0xFFE11D48) : null),
            onPressed: () => context.read<ProductProvider>().toggleFavorite(product.id),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SizedBox(height: 265, child: ProductVisual(product: product, large: true)),
            const SizedBox(height: 19),
            Row(children: [
              Chip(label: Text(product.category)),
              const Spacer(),
              const Icon(Icons.star_rounded, color: Color(0xFFF59E0B)),
              Text(' ${product.rating.toStringAsFixed(1)} (demo)'),
            ]),
            const SizedBox(height: 8),
            Text(product.name, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(sumFormat(product.price),
                style: theme.textTheme.headlineMedium?.copyWith(color: theme.colorScheme.primary, fontWeight: FontWeight.w900)),
            if (product.discounted) ...[
              const SizedBox(height: 4),
              Text(sumFormat(product.oldPrice!), style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey)),
            ],
            const SizedBox(height: 15),
            Row(children: [
              const Icon(Icons.inventory_2_outlined, size: 18),
              const SizedBox(width: 7),
              Text('Omborda: ${product.stock} ta'),
              const SizedBox(width: 16),
              Text('Savatchada: $inCart ta'),
            ]),
            const SizedBox(height: 25),
            const Text('Mahsulot tavsifi', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 9),
            Text(product.description, style: TextStyle(height: 1.55, color: theme.colorScheme.onSurfaceVariant)),
            const SizedBox(height: 12),
            const Text('Eslatma: katalog va narxlar o‘quv loyihasi uchun namunaviy.',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
          child: Row(children: [
            IconButton.outlined(
              tooltip: 'Kamaytirish',
              onPressed: _quantity > 1 ? () => setState(() => _quantity--) : null,
              icon: const Icon(Icons.remove),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text('$_quantity', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            ),
            IconButton.outlined(
              tooltip: 'Ko‘paytirish',
              onPressed: _quantity + inCart < product.stock ? () => setState(() => _quantity++) : null,
              icon: const Icon(Icons.add),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.icon(
                onPressed: () {
                  final result = context.read<CartProvider>().add(product, quantity: _quantity);
                  if (result) setState(() => _quantity = 1);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(result ? 'Savatchaga qo‘shildi!' : 'Ombordagi mahsulot soni yetarli emas'),
                  ));
                },
                icon: const Icon(Icons.shopping_cart_checkout),
                label: const FittedBox(fit: BoxFit.scaleDown, child: Text('Savatchaga')),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
