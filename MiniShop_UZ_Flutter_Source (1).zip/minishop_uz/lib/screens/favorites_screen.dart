import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/product_provider.dart';
import '../widgets/product_card.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final products = context.watch<ProductProvider>().favorites;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Sevimlilar ❤️', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 24)),
          const SizedBox(height: 4),
          Text('${products.length} ta saqlangan mahsulot'),
          const SizedBox(height: 15),
          Expanded(
            child: products.isEmpty
                ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.favorite_border_rounded, size: 70, color: Colors.grey),
                    SizedBox(height: 14),
                    Text('Hozircha sevimli mahsulot yo‘q', style: TextStyle(fontWeight: FontWeight.w700)),
                    SizedBox(height: 6),
                    Text('Mahsulot kartochkasidagi yurakni bosing.'),
                  ]))
                : GridView.builder(
                    padding: const EdgeInsets.only(bottom: 15),
                    itemCount: products.length,
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 220,
                      mainAxisExtent: 310,
                      crossAxisSpacing: 11,
                      mainAxisSpacing: 11,
                    ),
                    itemBuilder: (context, index) => ProductCard(product: products[index]),
                  ),
          ),
        ]),
      ),
    );
  }
}
