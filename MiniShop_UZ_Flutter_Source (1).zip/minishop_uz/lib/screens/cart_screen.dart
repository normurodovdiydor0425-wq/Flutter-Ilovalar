import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/formatters.dart';
import '../models/order_record.dart';
import '../providers/cart_provider.dart';
import '../providers/orders_provider.dart';
import '../widgets/product_visual.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key, required this.onBrowse});

  final VoidCallback onBrowse;

  Future<void> _confirmClear(BuildContext context) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Savatchani tozalaysizmi?'),
        content: const Text('Barcha mahsulotlar savatchadan olib tashlanadi.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Bekor qilish')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Tozalash')),
        ],
      ),
    );
    if (yes == true && context.mounted) context.read<CartProvider>().clear();
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final items = cart.items;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.only(top: 13, bottom: 10),
            child: Row(children: [
              const Expanded(child: Text('Savatcham 🛒', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 24))),
              if (items.isNotEmpty)
                TextButton.icon(
                  onPressed: () => _confirmClear(context),
                  icon: const Icon(Icons.delete_outline, size: 18),
                  label: const Text('Tozalash'),
                ),
            ]),
          ),
          Text('${cart.itemCount} ta mahsulot • ${cart.distinctCount} xil tur'),
          const SizedBox(height: 14),
          Expanded(
            child: !cart.loaded
                ? const Center(child: CircularProgressIndicator())
                : items.isEmpty
                    ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.remove_shopping_cart_outlined, size: 76, color: Colors.grey),
                        const SizedBox(height: 13),
                        const Text('Savatchangiz bo‘sh', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20)),
                        const SizedBox(height: 7),
                        const Text('Mahsulotlarni katalogdan tanlang.'),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: onBrowse,
                          icon: const Icon(Icons.storefront),
                          label: const Text('Mahsulotlarni ko‘rish'),
                        ),
                      ]))
                    : ListView.separated(
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final item = items[index];
                          final product = cart.productFor(item.productId)!;
                          return Card(
                            elevation: 0,
                            margin: EdgeInsets.zero,
                            color: Theme.of(context).cardColor,
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Row(children: [
                                SizedBox(width: 78, height: 86, child: ProductVisual(product: product)),
                                const SizedBox(width: 10),
                                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(product.name,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontWeight: FontWeight.bold)),
                                  const SizedBox(height: 6),
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    alignment: Alignment.centerLeft,
                                    child: Text(sumFormat(product.price * item.quantity),
                                        style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800)),
                                  ),
                                  const SizedBox(height: 5),
                                  Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                                    _smallButton(
                                      icon: Icons.remove,
                                      tooltip: 'Miqdorni kamaytirish',
                                      onTap: () => cart.decrease(product.id),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 12),
                                      child: Text('${item.quantity}', style: const TextStyle(fontWeight: FontWeight.w800)),
                                    ),
                                    _smallButton(
                                      icon: Icons.add,
                                      tooltip: 'Miqdorni oshirish',
                                      onTap: item.quantity < product.stock ? () => cart.increase(product) : null,
                                    ),
                                    const Spacer(),
                                    _smallButton(
                                      icon: Icons.delete_outline,
                                      tooltip: 'Olib tashlash',
                                      onTap: () => cart.remove(product.id),
                                    ),
                                  ]),
                                ])),
                              ]),
                            ),
                          );
                        },
                      ),
          ),
          if (items.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 12),
              child: Card(
                elevation: 0,
                color: Theme.of(context).cardColor,
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(children: [
                    Row(children: [
                      const Text('Umumiy summa', style: TextStyle(fontWeight: FontWeight.w600)),
                      const Spacer(),
                      Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(
                        sumFormat(cart.subtotal),
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 21, color: Theme.of(context).colorScheme.primary),
                      ))),
                    ]),
                    const SizedBox(height: 6),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text('Yetkazib berish va to‘lov: demo rejim', style: TextStyle(fontSize: 11, color: Colors.grey)),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () => showModalBottomSheet<void>(
                          context: context,
                          isScrollControlled: true,
                          useSafeArea: true,
                          builder: (_) => const _CheckoutSheet(),
                        ),
                        icon: const Icon(Icons.shopping_bag_outlined),
                        label: const Text('Buyurtma berish (demo)'),
                      ),
                    ),
                  ]),
                ),
              ),
            ),
        ]),
      ),
    );
  }

  Widget _smallButton({required IconData icon, required String tooltip, VoidCallback? onTap}) {
    return IconButton.outlined(
      tooltip: tooltip,
      onPressed: onTap,
      icon: Icon(icon, size: 17),
      visualDensity: VisualDensity.compact,
      constraints: const BoxConstraints(minHeight: 30, minWidth: 30),
      padding: EdgeInsets.zero,
    );
  }
}

class _CheckoutSheet extends StatefulWidget {
  const _CheckoutSheet();

  @override
  State<_CheckoutSheet> createState() => _CheckoutSheetState();
}

class _CheckoutSheetState extends State<_CheckoutSheet> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    super.dispose();
  }

  Future<void> _checkout() async {
    if (!_formKey.currentState!.validate() || _saving) return;
    final cart = context.read<CartProvider>();
    if (cart.items.isEmpty) return;
    setState(() => _saving = true);
    final order = OrderRecord(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      customer: _name.text.trim(),
      phone: _phone.text.trim(),
      address: _address.text.trim(),
      total: cart.subtotal,
      itemCount: cart.itemCount,
      createdAt: DateTime.now(),
    );
    await context.read<OrdersProvider>().placeDemoOrder(order);
    if (!mounted) return;
    cart.clear();
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Demo buyurtma saqlandi! Haqiqiy to‘lov amalga oshirilmadi.'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.viewInsetsOf(context).bottom + 20),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Buyurtmani rasmiylashtirish', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('Bu faqat demo. Buyurtma hech qayerga yuborilmaydi.', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 15),
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Ism va familiya'),
              validator: (v) => (v == null || v.trim().length < 3) ? 'Ismni kiriting' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Telefon raqami'),
              validator: (v) => (v == null || v.trim().length < 7) ? 'Telefon raqamini kiriting' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _address,
              decoration: const InputDecoration(labelText: 'Yetkazib berish manzili'),
              validator: (v) => (v == null || v.trim().length < 5) ? 'Manzilni kiriting' : null,
            ),
            const SizedBox(height: 17),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _saving ? null : _checkout,
                child: Text(_saving ? 'Saqlanmoqda...' : 'Demo buyurtmani tasdiqlash'),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
