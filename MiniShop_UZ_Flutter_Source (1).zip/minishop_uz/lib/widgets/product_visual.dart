import 'package:flutter/material.dart';

import '../models/product.dart';

class ProductVisual extends StatelessWidget {
  const ProductVisual({super.key, required this.product, this.large = false});

  final Product product;
  final bool large;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [product.color.withValues(alpha: .17), product.color.withValues(alpha: .07)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            right: -24,
            top: -38,
            child: Container(
              width: large ? 180 : 100,
              height: large ? 180 : 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: product.color.withValues(alpha: .09),
              ),
            ),
          ),
          Text(product.icon, style: TextStyle(fontSize: large ? 112 : 66)),
        ],
      ),
    );
  }
}
