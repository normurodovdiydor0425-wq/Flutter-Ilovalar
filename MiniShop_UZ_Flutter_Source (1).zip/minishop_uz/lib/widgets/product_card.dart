import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/formatters.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../providers/product_provider.dart';
import '../screens/product_details_screen.dart';
import 'product_visual.dart';

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product});

  final Product product;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isFavorite = context.select<ProductProvider, bool>(
      (provider) => provider.isFavorite(product.id),
    );

    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: theme.cardColor,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(19),
        side: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: .45)),
      ),
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ProductDetailsScreen(product: product),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(9),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 120,
                width: double.infinity,
                child: Stack(
                  children: [
                    Positioned.fill(child: ProductVisual(product: product)),
                    if (product.discounted)
                      Positioned(
                        left: 7,
                        top: 7,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                          decoration: BoxDecoration(color: const Color(0xFFDC2626), borderRadius: BorderRadius.circular(8)),
                          child: Text('-${product.discountPercent}%', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white)),
                        ),
                      ),
                    Positioned(
                      right: 4,
                      top: 4,
                      child: Material(
                        color: theme.cardColor.withValues(alpha: .95),
                        borderRadius: BorderRadius.circular(30),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(30),
                          onTap: () => context.read<ProductProvider>().toggleFavorite(product.id),
                          child: Padding(
                            padding: const EdgeInsets.all(7),
                            child: Icon(
                              isFavorite ? Icons.favorite : Icons.favorite_border,
                              size: 18,
                              color: isFavorite ? const Color(0xFFE11D48) : null,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 9),
              Text(
                product.category,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: theme.colorScheme.primary),
              ),
              const SizedBox(height: 3),
              Text(product.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, height: 1.25)),
              const Spacer(),
              Row(children: [
                const Icon(Icons.star_rounded, color: Color(0xFFF59E0B), size: 15),
                Text(product.rating.toStringAsFixed(1), style: const TextStyle(fontSize: 11)),
                const Spacer(),
                Text('${product.stock} ta', style: TextStyle(fontSize: 10, color: theme.colorScheme.onSurfaceVariant)),
              ]),
              const SizedBox(height: 6),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(sumFormat(product.price), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: theme.colorScheme.primary)),
              ),
              const SizedBox(height: 7),
              SizedBox(
                width: double.infinity,
                height: 35,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () {
                    final added = context.read<CartProvider>().add(product);
                    ScaffoldMessenger.of(context).hideCurrentSnackBar();
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      duration: const Duration(seconds: 2),
                      content: Text(added ? '${product.name} savatchaga qo‘shildi' : 'Omborda bundan ortiq mahsulot yo‘q'),
                    ));
                  },
                  icon: const Icon(Icons.add_shopping_cart, size: 17),
                  label: const FittedBox(fit: BoxFit.scaleDown, child: Text('Qo‘shish', style: TextStyle(fontSize: 12))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
