import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/cart_item.dart';
import '../models/order_record.dart';

class LocalStorageService {
  LocalStorageService({SharedPreferencesAsync? preferences})
      : _preferences = preferences;

  // Platforma obyekti faqat haqiqiy saqlash amali boshlanganda yaratiladi.
  // Bu testlarda platforma plaginini ishga tushirmaydigan soxta storage
  // klasslari uchun muhim.
  SharedPreferencesAsync? _preferences;
  SharedPreferencesAsync get _prefs =>
      _preferences ??= SharedPreferencesAsync();

  Future<List<CartItem>> readCart() async {
    final raw = await _prefs.getString('minishop_cart_v1');
    if (raw == null) return [];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map((item) => CartItem.fromJson(item as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveCart(List<CartItem> items) => _prefs.setString(
        'minishop_cart_v1',
        jsonEncode(items.map((item) => item.toJson()).toList()),
      );

  Future<Set<String>> readFavorites() async {
    final values = await _prefs.getStringList('minishop_favorites_v1');
    return values?.toSet() ?? {};
  }

  Future<void> saveFavorites(Set<String> ids) =>
      _prefs.setStringList('minishop_favorites_v1', ids.toList());

  Future<bool> readDarkMode() async =>
      await _prefs.getBool('minishop_dark_v1') ?? false;

  Future<void> saveDarkMode(bool value) =>
      _prefs.setBool('minishop_dark_v1', value);

  Future<List<OrderRecord>> readOrders() async {
    final raw = await _prefs.getString('minishop_orders_v1');
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List<dynamic>)
          .map((item) => OrderRecord.fromJson(item as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveOrders(List<OrderRecord> orders) => _prefs.setString(
        'minishop_orders_v1',
        jsonEncode(orders.map((item) => item.toJson()).toList()),
      );
}
