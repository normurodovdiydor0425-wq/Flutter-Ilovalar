import 'package:flutter/foundation.dart';

import '../services/local_storage_service.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeProvider(this._storage);

  final LocalStorageService _storage;
  bool _dark = false;
  bool get isDark => _dark;

  Future<void> load() async {
    try {
      _dark = await _storage.readDarkMode();
      notifyListeners();
    } catch (_) {
      // Standart mavzu saqlanadi.
    }
  }

  Future<void> setDark(bool value) async {
    _dark = value;
    notifyListeners();
    try {
      await _storage.saveDarkMode(value);
    } catch (_) {}
  }
}
