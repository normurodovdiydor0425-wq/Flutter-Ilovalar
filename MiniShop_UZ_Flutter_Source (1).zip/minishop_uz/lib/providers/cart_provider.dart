import 'package:flutter/foundation.dart';

import '../models/cart_item.dart';
import '../models/product.dart';
import '../services/local_storage_service.dart';

class CartProvider extends ChangeNotifier {
  CartProvider(this._storage, List<Product> products)
      : _products = {for (final p in products) p.id: p};

  final LocalStorageService _storage;
  final Map<String, Product> _products;
  final Map<String, int> _quantities = {};
  Future<void> _pendingWrite = Future<void>.value();
  bool _loaded = false;

  bool get loaded => _loaded;
  int get itemCount => _quantities.values.fold(0, (a, b) => a + b);
  int get distinctCount => _quantities.length;
  int get subtotal => _quantities.entries.fold(
        0,
        (total, entry) => total + (_products[entry.key]?.price ?? 0) * entry.value,
      );

  List<CartItem> get items => _quantities.entries
      .map((entry) => CartItem(productId: entry.key, quantity: entry.value))
      .toList(growable: false);

  Product? productFor(String id) => _products[id];
  int quantityFor(String productId) => _quantities[productId] ?? 0;

  Future<void> load() async {
    try {
      final saved = await _storage.readCart();
      for (final item in saved) {
        final product = _products[item.productId];
        if (product == null) continue;
        final count = item.quantity.clamp(0, product.stock).toInt();
        if (count > 0) _quantities[item.productId] = count;
      }
    } catch (_) {
      // Saqlangan ma'lumot o'qilmasa, bo'sh savatcha ochiladi.
    }
    _loaded = true;
    notifyListeners();
  }

  bool add(Product product, {int quantity = 1}) {
    final count = quantityFor(product.id);
    if (quantity <= 0 || count + quantity > product.stock) return false;
    _quantities[product.id] = count + quantity;
    _changed();
    return true;
  }

  bool increase(Product product) => add(product);

  void decrease(String productId) {
    final count = quantityFor(productId);
    if (count <= 1) {
      remove(productId);
      return;
    }
    _quantities[productId] = count - 1;
    _changed();
  }

  void remove(String productId) {
    if (_quantities.remove(productId) != null) _changed();
  }

  void clear() {
    _quantities.clear();
    _changed();
  }

  void _changed() {
    notifyListeners();
    final snapshot = items;
    _pendingWrite = _pendingWrite
        .then((_) => _storage.saveCart(snapshot))
        .catchError((Object _) {});
  }
}
