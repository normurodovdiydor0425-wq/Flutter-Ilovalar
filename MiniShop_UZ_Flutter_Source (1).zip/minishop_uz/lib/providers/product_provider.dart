import 'package:flutter/foundation.dart';

import '../models/product.dart';
import '../services/local_storage_service.dart';

enum ProductSort { popular, cheapFirst, expensiveFirst, name }

class ProductProvider extends ChangeNotifier {
  ProductProvider(this._storage, this.products);

  final LocalStorageService _storage;
  final List<Product> products;
  final Set<String> _favorites = {};
  String _query = '';
  String _category = 'Barchasi';
  ProductSort _sort = ProductSort.popular;
  Future<void> _pendingWrite = Future<void>.value();

  String get query => _query;
  String get category => _category;
  ProductSort get sort => _sort;
  int get favoriteCount => _favorites.length;
  List<String> get categories => [
        'Barchasi',
        ...products.map((p) => p.category).toSet(),
      ];

  List<Product> get filteredProducts {
    final lowered = _query.trim().toLowerCase();
    final list = products.where((p) {
      final categoryMatches = _category == 'Barchasi' || p.category == _category;
      return categoryMatches &&
          (lowered.isEmpty ||
              p.name.toLowerCase().contains(lowered) ||
              p.category.toLowerCase().contains(lowered));
    }).toList();
    if (_sort == ProductSort.popular) {
      list.sort((a, b) => b.rating.compareTo(a.rating));
    } else if (_sort == ProductSort.cheapFirst) {
      list.sort((a, b) => a.price.compareTo(b.price));
    } else if (_sort == ProductSort.expensiveFirst) {
      list.sort((a, b) => b.price.compareTo(a.price));
    } else {
      list.sort((a, b) => a.name.compareTo(b.name));
    }
    return list;
  }

  List<Product> get favorites =>
      products.where((p) => _favorites.contains(p.id)).toList();

  bool isFavorite(String productId) => _favorites.contains(productId);

  Future<void> load() async {
    try {
      _favorites.addAll(await _storage.readFavorites());
    } catch (_) {
      // Saqlash tizimi ishlamasa ham katalog mavjud.
    }
    notifyListeners();
  }

  void search(String value) {
    _query = value;
    notifyListeners();
  }

  void setCategory(String value) {
    _category = value;
    notifyListeners();
  }

  void setSort(ProductSort value) {
    _sort = value;
    notifyListeners();
  }

  void toggleFavorite(String productId) {
    if (!_favorites.add(productId)) _favorites.remove(productId);
    notifyListeners();
    final snapshot = Set<String>.from(_favorites);
    _pendingWrite = _pendingWrite
        .then((_) => _storage.saveFavorites(snapshot))
        .catchError((Object _) {});
  }
}
