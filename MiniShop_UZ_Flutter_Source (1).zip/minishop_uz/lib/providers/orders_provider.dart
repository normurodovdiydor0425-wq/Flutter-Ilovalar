import 'package:flutter/foundation.dart';

import '../models/order_record.dart';
import '../services/local_storage_service.dart';

class OrdersProvider extends ChangeNotifier {
  OrdersProvider(this._storage);

  final LocalStorageService _storage;
  final List<OrderRecord> _orders = [];
  List<OrderRecord> get orders => List.unmodifiable(_orders);

  Future<void> load() async {
    try {
      _orders.addAll(await _storage.readOrders());
      notifyListeners();
    } catch (_) {}
  }

  Future<void> placeDemoOrder(OrderRecord order) async {
    _orders.insert(0, order);
    notifyListeners();
    try {
      await _storage.saveOrders(_orders);
    } catch (_) {}
  }
}
