import 'package:flutter_test/flutter_test.dart';
import 'package:ohang/core/formatters.dart';

void main() {
  test('Audio davomiyligi to‘g‘ri formatlanadi', () {
    expect(timeText(const Duration(seconds: 3)), '0:03');
    expect(timeText(const Duration(seconds: 65)), '1:05');
    expect(timeText(Duration.zero), '0:00');
  });
}
