import 'package:flutter_test/flutter_test.dart';
import 'package:ohang/providers/favorites_provider.dart';
import 'package:ohang/services/local_storage_service.dart';
import 'fake_store.dart';

void main() {
  test('Sevimlilar qo‘shish/o‘chirish va ilova qayta ochilishi', () async {
    final storage = AppStorage(FakeStringStore());
    final first = FavoritesProvider(storage);
    await first.load();
    expect(first.ids, isEmpty);
    await first.toggle('demo_3');
    expect(first.contains('demo_3'), isTrue);
    final second = FavoritesProvider(storage);
    await second.load();
    expect(second.contains('demo_3'), isTrue);
    await second.toggle('demo_3');
    expect(second.ids, isEmpty);
  });
}
