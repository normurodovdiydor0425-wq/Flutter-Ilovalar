import 'package:flutter_test/flutter_test.dart';
import 'package:ohang/data/demo_tracks.dart';
import 'package:ohang/providers/library_provider.dart';
import 'package:ohang/services/local_storage_service.dart';
import 'fake_store.dart';

void main() {
  test('15 ta demo audio mavjud va noyob identifikatorlar berilgan', () async {
    final library = LibraryProvider(AppStorage(FakeStringStore()));
    await library.load();
    expect(library.tracks.length, 15);
    expect(library.tracks.every((track) => track.isAsset), isTrue);
    expect(library.tracks.map((track) => track.id).toSet().length, 15);
    expect(DemoTracks.all.first.source, 'assets/audio/ohang_01.wav');
  });
}
