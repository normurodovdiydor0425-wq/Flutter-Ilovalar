import 'package:ohang/services/local_storage_service.dart';

class FakeStringStore implements StringStore {
  final Map<String, String> data = {};
  @override
  Future<String?> read(String key) async => data[key];
  @override
  Future<void> write(String key, String value) async { data[key] = value; }
}
