import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ohang/widgets/album_cover.dart';

void main() {
  testWidgets('Asl ko‘k albom muqovasi ko‘rinadi', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(
      body: Center(child: AlbumCover(color: 0xFF2589FF, size: 140)))));
    expect(find.byType(AlbumCover), findsOneWidget);
    expect(find.byIcon(Icons.graphic_eq_rounded), findsOneWidget);
  });
}
