import 'package:flutter_test/flutter_test.dart';
import 'package:ohang/providers/playlist_provider.dart';
import 'package:ohang/services/local_storage_service.dart';
import 'fake_store.dart';

void main() {
  test('Playlist yaratish, trek qo‘shish, nomini almashtirish, o‘chirish', () async {
    final storage = AppStorage(FakeStringStore());
    final provider = PlaylistProvider(storage);
    await provider.load();
    await provider.create('Sokin kuylar');
    expect(provider.items, hasLength(1));
    final id = provider.items.first.id;
    await provider.toggleTrack(id, 'demo_1');
    expect(provider.items.first.trackIds, contains('demo_1'));
    await provider.rename(id, 'Mening playlistim');
    expect(provider.items.first.name, 'Mening playlistim');
    final reloaded = PlaylistProvider(storage);
    await reloaded.load();
    expect(reloaded.items.first.trackIds, contains('demo_1'));
    await reloaded.toggleTrack(id, 'demo_1');
    expect(reloaded.items.first.trackIds, isEmpty);
    await reloaded.delete(id);
    expect(reloaded.items, isEmpty);
  });
}
