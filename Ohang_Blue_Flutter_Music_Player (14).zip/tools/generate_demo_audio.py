#!/usr/bin/env python3
"""Create 15 original instrumental WAV demos using Python's standard library.

These recordings are generated algorithmically; they do not sample any song.
Run from the project root: python tools/generate_demo_audio.py
"""

from array import array
import math
from pathlib import Path
import random
import struct
import sys
import wave

SAMPLE_RATE = 22050
OUTPUT = Path(__file__).resolve().parents[1] / 'assets' / 'audio'
NAMES = [
    'Tong nafasi', 'Yulduzlar', 'Xotiralar', 'Orzular', 'Sokin tun',
    'Bahor shamoli', 'Sayohat', 'Dengiz', 'Ilhom', 'Sokin osmon',
    'Oydin yo‘l', 'Yurak sadosi', 'Yangi kun', 'Umid', 'Manzil',
]
SCALES = [
    [0, 2, 4, 7, 9], [0, 3, 5, 7, 10], [0, 2, 3, 7, 9],
    [0, 2, 5, 7, 9], [0, 3, 5, 8, 10],
]


def frequency(midi: int) -> float:
    return 440 * (2 ** ((midi - 69) / 12))


def voice(t: float, freq: float, tone: int) -> float:
    phase = 2 * math.pi * freq * t
    if tone == 0:
        return .77 * math.sin(phase) + .17 * math.sin(2 * phase) + .06 * math.sin(3 * phase)
    if tone == 1:
        return .65 * math.sin(phase) + .25 * math.sin(2 * phase) + .1 * math.sin(4 * phase)
    if tone == 2:
        return .83 * math.sin(phase) + .17 * math.sin(3 * phase)
    return .68 * math.sin(phase) + .21 * math.sin(1.5 * phase) + .11 * math.sin(3 * phase)


def envelope(age: float, duration: float) -> float:
    if age < 0 or age > duration:
        return 0.
    attack = min(1., age / .035)
    release = min(1., (duration - age) / .28)
    return attack * release * (.70 + .30 * math.exp(-age / max(.2, duration)))


def make_piece(index: int) -> None:
    rng = random.Random(2422 + index * 143)
    duration = 23 + index % 4 * 1  # 23–26 seconds; manifest metadata matches
    beats_per_minute = 90 + (index * 7) % 39
    beat = 60.0 / beats_per_minute
    scale = SCALES[index % len(SCALES)]
    root = 48 + (index % 6) * 2
    melody = []
    t = 0.20
    while t < duration - .5:
        step = rng.choice([.5, 1., 1., 1.5]) * beat
        pitch = root + 12 + rng.choice(scale) + rng.choice([0, 0, 0, 12])
        melody.append((t, min(step * .96, duration - t), frequency(pitch)))
        t += step
    # Chunk notes per time-grid: no need to search all notes for every sample.
    pcm = array('h')
    note_index = 0
    tone = index % 4
    bass_steps = [root, root + 5, root + 7, root + 3]
    for sample in range(int(duration * SAMPLE_RATE)):
        time = sample / SAMPLE_RATE
        phrase = int(time / (4 * beat))
        bass_freq = frequency(bass_steps[phrase % len(bass_steps)] - 12)
        chord_freq = frequency(bass_steps[phrase % len(bass_steps)] + 7)
        pulse = time % beat
        bass_env = math.exp(-pulse * 4.0)
        bass = .17 * math.sin(2 * math.pi * bass_freq * time) * bass_env
        pad = .065 * math.sin(2 * math.pi * chord_freq * time) * \
              (0.7 + .3 * math.sin(2 * math.pi * .18 * time))
        # Gentle rhythmic kick is mathematically synthesized, not sampled.
        kick = .075 * math.sin(2 * math.pi * (55 + 60 * math.exp(-pulse * 18)) * pulse) * \
               math.exp(-pulse * 19)
        while note_index < len(melody) and time > melody[note_index][0] + melody[note_index][1]:
            note_index += 1
        lead = 0.
        if note_index < len(melody):
            start, length, freq = melody[note_index]
            if start <= time <= start + length:
                lead = .45 * envelope(time - start, length) * voice(time - start, freq, tone)
        fade = min(1., time / .5, (duration - time) / .75)
        sample_value = (bass + pad + kick + lead) * max(0, fade)
        pcm.append(int(max(-.92, min(.92, sample_value)) * 32767))

    path = OUTPUT / f'ohang_{index + 1:02d}.wav'
    with wave.open(str(path), 'wb') as sound:
        sound.setnchannels(1)
        sound.setsampwidth(2)
        sound.setframerate(SAMPLE_RATE)
        if sys.byteorder == 'big':
            pcm.byteswap()
        sound.writeframes(pcm.tobytes())
    print(f'{path.name}: {NAMES[index]} ({duration}s, {path.stat().st_size // 1024} KiB)')


if __name__ == '__main__':
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for item_index in range(len(NAMES)):
        make_piece(item_index)
