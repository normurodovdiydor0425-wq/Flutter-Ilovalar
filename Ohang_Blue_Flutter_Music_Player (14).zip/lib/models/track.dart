class MusicTrack {
  const MusicTrack({required this.id, required this.title, required this.artist,
    required this.source, required this.isAsset, required this.color,
    this.album = 'Ohang', this.durationMs = 0, this.addedAt = 0});

  final String id;
  final String title;
  final String artist;
  final String album;
  final String source;
  final bool isAsset;
  final int color;
  final int durationMs;
  final int addedAt;

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'artist': artist, 'album': album,
    'source': source, 'isAsset': isAsset, 'color': color,
    'durationMs': durationMs, 'addedAt': addedAt,
  };

  factory MusicTrack.fromJson(Map<String, dynamic> map) => MusicTrack(
    id: map['id'] as String,
    title: map['title'] as String,
    artist: map['artist'] as String? ?? 'Noma’lum ijrochi',
    album: map['album'] as String? ?? 'Mening musiqalarim',
    source: map['source'] as String,
    isAsset: map['isAsset'] as bool? ?? false,
    color: map['color'] as int? ?? 0xFF2589FF,
    durationMs: map['durationMs'] as int? ?? 0,
    addedAt: map['addedAt'] as int? ?? 0,
  );
}
