class MusicPlaylist {
  const MusicPlaylist({required this.id, required this.name, required this.trackIds});
  final String id;
  final String name;
  final List<String> trackIds;

  MusicPlaylist copyWith({String? name, List<String>? trackIds}) => MusicPlaylist(
    id: id, name: name ?? this.name, trackIds: trackIds ?? this.trackIds);

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'trackIds': trackIds};

  factory MusicPlaylist.fromJson(Map<String, dynamic> map) => MusicPlaylist(
    id: map['id'] as String,
    name: map['name'] as String,
    trackIds: (map['trackIds'] as List).cast<String>(),
  );
}
