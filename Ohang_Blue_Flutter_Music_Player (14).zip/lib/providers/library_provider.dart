import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import '../data/demo_tracks.dart';
import '../models/track.dart';
import '../services/local_storage_service.dart';

class LibraryProvider extends ChangeNotifier {
  LibraryProvider(this._storage);
  final AppStorage _storage;
  final List<MusicTrack> _imports = [];
  List<MusicTrack> get tracks => List.unmodifiable([...DemoTracks.all, ..._imports]);
  int get importedCount => _imports.length;
  MusicTrack? find(String id) {
    for (final track in tracks) {
      if (track.id == id) return track;
    }
    return null;
  }

  Future<void> load() async {
    final raw = await _storage.load('imports', <dynamic>[]);
    if (raw is List) {
      for (final item in raw) {
        try {
          final track = MusicTrack.fromJson(Map<String, dynamic>.from(item as Map));
          if (track.isAsset || await File(track.source).exists()) _imports.add(track);
        } catch (_) {}
      }
      notifyListeners();
    }
  }

  Future<String> importAudio() async {
    try {
      final picked = await FilePicker.platform.pickFiles(type: FileType.custom,
        allowedExtensions: const ['mp3', 'wav', 'm4a', 'aac', 'flac']);
      if (picked == null || picked.files.isEmpty) return 'Fayl tanlash bekor qilindi.';
      final file = picked.files.single;
      if (file.path == null) return 'Tanlangan fayl manzili aniqlanmadi.';
      final input = File(file.path!);
      if (!await input.exists()) return 'Audio fayl topilmadi.';
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final ext = file.extension?.toLowerCase() ?? 'mp3';
      final documents = await getApplicationDocumentsDirectory();
      final folder = Directory('${documents.path}/ohang_audio');
      if (!await folder.exists()) await folder.create(recursive: true);
      final target = File('${folder.path}/track_$id.$ext');
      await input.copy(target.path);
      final baseName = file.name.replaceFirst(RegExp(r'\.[^.]+$'), '');
      _imports.add(MusicTrack(id: 'import_$id', title: baseName,
        artist: 'Mening musiqam', album: 'Import qilingan', source: target.path,
        isAsset: false, color: 0xFF2589FF, addedAt: DateTime.now().millisecondsSinceEpoch));
      notifyListeners();
      await _storage.save('imports', _imports.map((item) => item.toJson()).toList());
      return '${file.name} kutubxonaga qo‘shildi.';
    } catch (error) {
      return 'Musiqani import qilishda xatolik: $error';
    }
  }

  Future<void> deleteImported(String id) async {
    final index = _imports.indexWhere((item) => item.id == id);
    if (index < 0) return;
    final removed = _imports.removeAt(index);
    notifyListeners();
    await _storage.save('imports', _imports.map((item) => item.toJson()).toList());
    try {
      final file = File(removed.source);
      if (await file.exists()) await file.delete();
    } catch (_) {}
  }
}
