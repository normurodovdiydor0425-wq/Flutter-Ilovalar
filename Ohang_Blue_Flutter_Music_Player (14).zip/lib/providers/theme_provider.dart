import 'package:flutter/foundation.dart';
import '../services/local_storage_service.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeProvider(this._storage);
  final AppStorage _storage;
  bool isDark = true;

  Future<void> load() async {
    isDark = await _storage.load('dark_theme', true) == true;
    notifyListeners();
  }

  Future<void> setDark(bool value) async {
    isDark = value;
    notifyListeners();
    await _storage.save('dark_theme', value);
  }
}
