import 'package:flutter/foundation.dart';
import '../services/local_storage_service.dart';

class FavoritesProvider extends ChangeNotifier {
  FavoritesProvider(this._storage);
  final AppStorage _storage;
  final Set<String> _ids = {};

  bool contains(String id) => _ids.contains(id);
  Set<String> get ids => Set.unmodifiable(_ids);

  Future<void> load() async {
    final values = await _storage.load('favorites', <dynamic>[]);
    if (values is List) {
      _ids.addAll(values.whereType<String>());
      notifyListeners();
    }
  }

  Future<void> toggle(String id) async {
    if (!_ids.remove(id)) _ids.add(id);
    notifyListeners();
    await _storage.save('favorites', _ids.toList());
  }
}
