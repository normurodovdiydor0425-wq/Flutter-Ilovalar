import 'dart:async';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import '../models/track.dart';
import '../services/local_storage_service.dart';

class AudioPlayerProvider extends ChangeNotifier {
  AudioPlayerProvider(this._storage, {AudioPlayer? audioPlayer})
      : _player = audioPlayer ?? AudioPlayer();

  final AppStorage _storage;
  final AudioPlayer _player;
  final List<StreamSubscription<dynamic>> _listeners = [];
  List<MusicTrack> _queue = [];
  List<String> _recentIds = [];
  int _index = 0;
  bool _playing = false;
  bool _loading = false;
  bool _shuffle = false;
  LoopMode _loop = LoopMode.off;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  int _lastSavedSecond = -5;
  String? error;
  Future<void> _scheduled = Future<void>.value();
  int _requestVersion = 0;

  List<MusicTrack> get queue => List.unmodifiable(_queue);
  List<String> get recentIds => List.unmodifiable(_recentIds);
  MusicTrack? get currentTrack => _queue.isEmpty || _index < 0 ||
      _index >= _queue.length ? null : _queue[_index];
  int get currentIndex => _index;
  bool get playing => _playing;
  bool get loading => _loading;
  bool get shuffle => _shuffle;
  LoopMode get loopMode => _loop;
  Duration get position => _position;
  Duration get duration => _duration;

  Future<void> initialize(List<MusicTrack> catalog) async {
    final raw = await _storage.load('recent', <dynamic>[]);
    if (raw is List) _recentIds = raw.whereType<String>().take(12).toList();
    final id = await _storage.load('last_track', '');
    final positionMs = await _storage.load('last_position', 0);
    _listeners.add(_player.playingStream.listen((value) {
      _playing = value;
      notifyListeners();
    }));
    _listeners.add(_player.positionStream.listen((value) {
      _position = value;
      if (value.inSeconds - _lastSavedSecond >= 5 ||
          value.inSeconds < _lastSavedSecond) {
        _lastSavedSecond = value.inSeconds;
        unawaited(_storage.save('last_position', value.inMilliseconds));
      }
      notifyListeners();
    }));
    _listeners.add(_player.durationStream.listen((value) {
      _duration = value ?? Duration.zero;
      notifyListeners();
    }));
    _listeners.add(_player.currentIndexStream.listen((value) {
      if (value == null || value < 0 || value >= _queue.length) return;
      if (value != _index) {
        _index = value;
        _notePlayed(_queue[value].id);
        notifyListeners();
      }
    }));
    _listeners.add(_player.errorStream.listen((value) {
      error = 'Audio ijro etilmadi: ${value.message}';
      _loading = false;
      notifyListeners();
    }));
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration.music());
    } catch (e) {
      debugPrint('Audio session configuration: $e');
    }
    final index = catalog.indexWhere((track) => track.id == id);
    if (index >= 0) {
      await playQueue(catalog, index, autoPlay: false,
        initialPosition: Duration(milliseconds: positionMs is int ? positionMs : 0));
    }
  }

  Future<void> playQueue(List<MusicTrack> tracks, int requestedIndex,
      {bool autoPlay = true, Duration initialPosition = Duration.zero}) {
    if (tracks.isEmpty || requestedIndex < 0 || requestedIndex >= tracks.length) {
      return Future<void>.value();
    }
    final version = ++_requestVersion;
    _scheduled = _scheduled.catchError((Object _) {}).then((_) async {
      if (version != _requestVersion) return;
      _loading = true;
      error = null;
      notifyListeners();
      try {
        await _player.pause();
        _queue = List<MusicTrack>.from(tracks);
        _index = requestedIndex;
        _position = Duration.zero;
        _duration = Duration.zero;
        notifyListeners();
        final sources = tracks.map((item) => item.isAsset
          ? AudioSource.asset(item.source) : AudioSource.file(item.source)).toList();
        await _player.setAudioSources(sources, initialIndex: requestedIndex,
          initialPosition: initialPosition);
        if (version != _requestVersion) return;
        await _player.setShuffleModeEnabled(_shuffle);
        await _player.setLoopMode(_loop);
        _notePlayed(tracks[requestedIndex].id,
          initialPosition: initialPosition);
        unawaited(_storage.save('last_track', tracks[requestedIndex].id));
        if (autoPlay) _startPlayback();
      } catch (e) {
        error = 'Musiqa ochilmadi: $e';
        _playing = false;
        debugPrint(error);
      } finally {
        _loading = false;
        notifyListeners();
      }
    });
    return _scheduled;
  }

  void _startPlayback() {
    unawaited(_player.play().catchError((Object e) {
      error = 'Ijro etishdagi xatolik: $e';
      notifyListeners();
    }));
  }

  Future<void> togglePlay() async {
    if (_loading) return;
    try {
      if (_player.playing) {
        await _player.pause();
      } else {
        if (_player.processingState == ProcessingState.completed) {
          await _player.seek(Duration.zero);
        }
        _startPlayback();
      }
    } catch (e) {
      error = 'Play/Pause: $e';
      notifyListeners();
    }
  }

  Future<void> next() async {
    if (_loading || _queue.isEmpty) return;
    try {
      if (_player.hasNext) {
        await _player.seekToNext();
      } else if (_loop == LoopMode.all) {
        await _player.seek(Duration.zero, index: 0);
      }
      if (!_player.playing) _startPlayback();
    } catch (e) {
      error = 'Keyingi musiqa: $e';
      notifyListeners();
    }
  }

  Future<void> previous() async {
    if (_loading || _queue.isEmpty) return;
    try {
      if (_position.inSeconds > 3) {
        await _player.seek(Duration.zero);
      } else if (_player.hasPrevious) {
        await _player.seekToPrevious();
      } else {
        await _player.seek(Duration.zero);
      }
      if (!_player.playing) _startPlayback();
    } catch (e) {
      error = 'Oldingi musiqa: $e';
      notifyListeners();
    }
  }

  Future<void> seek(Duration value) async {
    if (_queue.isEmpty || _loading) return;
    try {
      await _player.seek(value);
      unawaited(_storage.save('last_position', value.inMilliseconds));
    } catch (e) {
      error = 'Vaqtni o‘zgartirish: $e';
      notifyListeners();
    }
  }

  Future<void> toggleShuffle() async {
    try {
      await _player.setShuffleModeEnabled(!_shuffle);
      _shuffle = !_shuffle;
    } catch (e) { error = 'Aralashtirish: $e'; }
    notifyListeners();
  }

  Future<void> cycleRepeat() async {
    final nextMode = switch (_loop) {
      LoopMode.off => LoopMode.all,
      LoopMode.all => LoopMode.one,
      LoopMode.one => LoopMode.off,
    };
    try {
      await _player.setLoopMode(nextMode);
      _loop = nextMode;
    } catch (e) { error = 'Takrorlash: $e'; }
    notifyListeners();
  }

  Future<void> removeTrack(String id) async {
    if (!_queue.any((item) => item.id == id)) return;
    final nextQueue = _queue.where((item) => item.id != id).toList();
    if (nextQueue.isEmpty) {
      _requestVersion++;
      await _player.stop();
      _queue = [];
      _index = 0;
      notifyListeners();
    } else {
      final wasCurrent = currentTrack?.id == id;
      final currentId = currentTrack?.id;
      final newIndex = wasCurrent ? 0 : nextQueue.indexWhere((t) => t.id == currentId);
      await playQueue(nextQueue, newIndex < 0 ? 0 : newIndex,
        autoPlay: _playing);
    }
  }

  void clearError() {
    error = null;
    notifyListeners();
  }

  void _notePlayed(String id, {Duration initialPosition = Duration.zero}) {
    _lastSavedSecond = initialPosition.inSeconds;
    unawaited(_storage.save('last_position', initialPosition.inMilliseconds));
    _recentIds.remove(id);
    _recentIds.insert(0, id);
    if (_recentIds.length > 12) _recentIds.removeRange(12, _recentIds.length);
    unawaited(_storage.save('recent', _recentIds));
    unawaited(_storage.save('last_track', id));
  }

  @override
  void dispose() {
    for (final listener in _listeners) {
      unawaited(listener.cancel());
    }
    unawaited(_player.dispose());
    super.dispose();
  }
}
