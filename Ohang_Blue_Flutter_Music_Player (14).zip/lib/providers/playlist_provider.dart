import 'package:flutter/foundation.dart';
import '../models/playlist.dart';
import '../services/local_storage_service.dart';

class PlaylistProvider extends ChangeNotifier {
  PlaylistProvider(this._storage);
  final AppStorage _storage;
  final List<MusicPlaylist> _items = [];
  List<MusicPlaylist> get items => List.unmodifiable(_items);

  Future<void> load() async {
    final raw = await _storage.load('playlists', <dynamic>[]);
    if (raw is List) {
      for (final item in raw) {
        try {
          _items.add(MusicPlaylist.fromJson(Map<String, dynamic>.from(item as Map)));
        } catch (_) { /* Buzilgan bittagina ro‘yxat butun ilovani to‘xtatmasin. */ }
      }
      notifyListeners();
    }
  }

  Future<void> create(String name) async {
    final clean = name.trim();
    if (clean.isEmpty) return;
    _items.add(MusicPlaylist(id: 'playlist_${DateTime.now().microsecondsSinceEpoch}',
        name: clean, trackIds: const []));
    await _persist();
  }

  Future<void> rename(String id, String name) async {
    final clean = name.trim();
    if (clean.isEmpty) return;
    final index = _items.indexWhere((item) => item.id == id);
    if (index < 0) return;
    _items[index] = _items[index].copyWith(name: clean);
    await _persist();
  }

  Future<void> delete(String id) async {
    _items.removeWhere((item) => item.id == id);
    await _persist();
  }

  Future<void> toggleTrack(String playlistId, String trackId) async {
    final index = _items.indexWhere((item) => item.id == playlistId);
    if (index < 0) return;
    final ids = [..._items[index].trackIds];
    if (!ids.remove(trackId)) ids.add(trackId);
    _items[index] = _items[index].copyWith(trackIds: ids);
    await _persist();
  }

  Future<void> removeTrackFromAll(String trackId) async {
    for (var index = 0; index < _items.length; index++) {
      _items[index] = _items[index].copyWith(
        trackIds: _items[index].trackIds.where((id) => id != trackId).toList());
    }
    await _persist();
  }

  Future<void> _persist() async {
    notifyListeners();
    await _storage.save('playlists', _items.map((item) => item.toJson()).toList());
  }
}
