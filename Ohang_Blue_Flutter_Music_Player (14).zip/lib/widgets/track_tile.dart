import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../models/track.dart';
import '../providers/audio_player_provider.dart';
import '../providers/favorites_provider.dart';
import '../providers/playlist_provider.dart';
import 'album_cover.dart';
import 'navigation_helpers.dart';

class TrackTile extends StatelessWidget {
  const TrackTile({super.key, required this.track, required this.queue, this.onDelete});
  final MusicTrack track;
  final List<MusicTrack> queue;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final isPlayingThis = context.select<AudioPlayerProvider, bool>(
      (player) => player.currentTrack?.id == track.id && player.playing);
    final liked = context.select<FavoritesProvider, bool>((fav) => fav.contains(track.id));
    return Padding(padding: const EdgeInsets.symmetric(vertical: 5),
      child: Material(color: Colors.transparent,
        child: InkWell(borderRadius: BorderRadius.circular(17),
          onTap: () async {
            final index = queue.indexWhere((item) => item.id == track.id);
            if (index < 0) return;
            await context.read<AudioPlayerProvider>().playQueue(queue, index);
            if (context.mounted) openNowPlaying(context);
          },
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
            child: Row(children: [
              AlbumCover(color: track.color, size: 53, radius: 13),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700,
                    color: isPlayingThis ? skyBlue : null)),
                  const SizedBox(height: 4),
                  Text('${track.artist} · ${track.durationMs > 0 ? timeText(Duration(milliseconds: track.durationMs)) : "Audio"}',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor))])),
              IconButton(tooltip: 'Sevimlilar', iconSize: 22,
                onPressed: () => context.read<FavoritesProvider>().toggle(track.id),
                icon: Icon(liked ? Icons.favorite_rounded : Icons.favorite_outline_rounded,
                  color: liked ? const Color(0xFFFC718F) : null)),
              PopupMenuButton<String>(tooltip: 'Qo‘shimcha amallar',
                onSelected: (value) {
                  if (value == 'playlist') showAddToPlaylistSheet(context, track);
                  if (value == 'delete') onDelete?.call();
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'playlist', child: Text('Playlistga qo‘shish')),
                  if (onDelete != null) const PopupMenuItem(value: 'delete',
                    child: Text('Importni o‘chirish')),
                ],
                icon: const Icon(Icons.more_vert_rounded, size: 20)),
            ])),
        )),
    );
  }
}

Future<void> showAddToPlaylistSheet(BuildContext context, MusicTrack track) async {
  final provider = context.read<PlaylistProvider>();
  await showModalBottomSheet<void>(context: context, isScrollControlled: true,
    showDragHandle: true, builder: (sheetContext) => SafeArea(child: Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Playlistni tanlang', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (provider.items.isEmpty) const Padding(
          padding: EdgeInsets.all(18), child: Text('Avval Playlistlar bo‘limida yangi ro‘yxat yarating.')),
        for (final playlist in provider.items)
          ListTile(leading: const Icon(Icons.queue_music_rounded), title: Text(playlist.name),
            trailing: Icon(playlist.trackIds.contains(track.id)
              ? Icons.check_circle_rounded : Icons.add_circle_outline_rounded,
              color: accentBlue),
            onTap: () async {
              await provider.toggleTrack(playlist.id, track.id);
              if (sheetContext.mounted) Navigator.pop(sheetContext);
            }),
      ]))),
  );
}
