import 'package:flutter/material.dart';
import '../screens/now_playing_screen.dart';

void openNowPlaying(BuildContext context) => Navigator.of(context).push(
  MaterialPageRoute<void>(builder: (_) => const NowPlayingScreen()));
