import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/app_theme.dart';

/// Internet talab qilmaydigan, o‘ziga xos original ko‘k albom grafikasi.
class AlbumCover extends StatelessWidget {
  const AlbumCover({super.key, required this.color, this.size = 72, this.radius = 18});
  final int color;
  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(radius),
    child: SizedBox(width: size, height: size, child: CustomPaint(
      painter: _AlbumPainter(Color(color)),
      child: Stack(alignment: Alignment.center, children: [
        Positioned(right: -size * .15, top: -size * .2,
          child: Container(width: size * .75, height: size * .75,
            decoration: BoxDecoration(shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: .09)))),
        Icon(Icons.graphic_eq_rounded, size: size * .38,
          color: Colors.white.withValues(alpha: .87)),
        Positioned(bottom: size * .13, child: Row(mainAxisSize: MainAxisSize.min,
          children: List.generate(4, (index) => Padding(
            padding: EdgeInsets.symmetric(horizontal: size * .012),
            child: Container(width: size * .025, height: size * (.035 + index % 3 * .025),
              decoration: BoxDecoration(color: skyBlue.withValues(alpha: .7),
                borderRadius: BorderRadius.circular(6))),
          )))),
      ]),
    )),
  );
}

class _AlbumPainter extends CustomPainter {
  _AlbumPainter(this.color);
  final Color color;
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..shader = LinearGradient(
      begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [const Color(0xFF071A30), color, const Color(0xFF0A4B83)],
    ).createShader(rect));
    final outline = Paint()..style = PaintingStyle.stroke
      ..color = Colors.white.withValues(alpha: .09)..strokeWidth = math.max(1, size.width * .007);
    for (var index = 1; index < 6; index++) {
      canvas.drawCircle(Offset(size.width * .53, size.height * .45),
        size.width * (.16 + index * .11), outline);
    }
    final glow = Paint()..shader = RadialGradient(colors: [
      skyBlue.withValues(alpha: .55), skyBlue.withValues(alpha: 0),
    ]).createShader(rect);
    canvas.drawCircle(Offset(size.width * .75, size.height * .78), size.width * .68, glow);
  }
  @override
  bool shouldRepaint(covariant _AlbumPainter old) => old.color != color;
}
