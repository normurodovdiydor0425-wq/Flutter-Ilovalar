import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../providers/audio_player_provider.dart';

class PlayerControls extends StatelessWidget {
  const PlayerControls({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<AudioPlayerProvider>();
    final active = player.currentTrack != null && !player.loading;
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      IconButton(onPressed: () => context.read<AudioPlayerProvider>().toggleShuffle(),
        tooltip: 'Aralashtirish', iconSize: 25,
        color: player.shuffle ? skyBlue : Colors.white70,
        icon: const Icon(Icons.shuffle_rounded)),
      IconButton(onPressed: active ? () => context.read<AudioPlayerProvider>().previous() : null,
        tooltip: 'Oldingi', iconSize: 36, color: Colors.white,
        icon: const Icon(Icons.skip_previous_rounded)),
      Container(width: 76, height: 76, decoration: const BoxDecoration(
        shape: BoxShape.circle, gradient: LinearGradient(colors: [skyBlue, accentBlue]),
        boxShadow: [BoxShadow(color: Color(0x77317CFF), blurRadius: 25, offset: Offset(0, 9))]),
        child: IconButton(onPressed: active ? () => context.read<AudioPlayerProvider>().togglePlay() : null,
          tooltip: player.playing ? 'Pauza' : 'Ijro',
          icon: player.loading ? const SizedBox(width: 23, height: 23,
            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            : Icon(player.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
              size: 39, color: Colors.white)),
      ),
      IconButton(onPressed: active ? () => context.read<AudioPlayerProvider>().next() : null,
        tooltip: 'Keyingi', iconSize: 36, color: Colors.white,
        icon: const Icon(Icons.skip_next_rounded)),
      IconButton(onPressed: () => context.read<AudioPlayerProvider>().cycleRepeat(),
        tooltip: 'Takrorlash', iconSize: 25,
        color: player.loopMode == LoopMode.off ? Colors.white70 : skyBlue,
        icon: Icon(player.loopMode == LoopMode.one
          ? Icons.repeat_one_rounded : Icons.repeat_rounded)),
    ]);
  }
}
