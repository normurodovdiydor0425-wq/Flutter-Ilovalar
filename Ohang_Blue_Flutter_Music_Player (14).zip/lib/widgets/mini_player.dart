import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../providers/audio_player_provider.dart';
import 'album_cover.dart';
import 'navigation_helpers.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});
  @override
  Widget build(BuildContext context) {
    final player = context.watch<AudioPlayerProvider>();
    final track = player.currentTrack;
    if (track == null) return const SizedBox.shrink();
    return Container(margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      decoration: BoxDecoration(gradient: const LinearGradient(
        colors: [Color(0xFF124C83), Color(0xFF0A3161)]),
        border: Border.all(color: skyBlue.withValues(alpha: .16)),
        borderRadius: BorderRadius.circular(17)),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        InkWell(onTap: () => openNowPlaying(context), borderRadius: BorderRadius.circular(17),
          child: Padding(padding: const EdgeInsets.fromLTRB(9, 7, 5, 7),
            child: Row(children: [
              AlbumCover(color: track.color, size: 45, radius: 11),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(track.title, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.white)),
                Text(track.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, color: faintBlue)),
              ])),
              IconButton(tooltip: player.playing ? 'Pauza' : 'Ijro',
                onPressed: player.loading ? null : () => context.read<AudioPlayerProvider>().togglePlay(),
                icon: Icon(player.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: Colors.white, size: 30)),
              IconButton(tooltip: 'Keyingi', onPressed: player.loading ? null :
                () => context.read<AudioPlayerProvider>().next(),
                icon: const Icon(Icons.skip_next_rounded, color: Colors.white)),
            ])),
        ),
        LinearProgressIndicator(minHeight: 2,
          value: player.duration.inMilliseconds > 0 ?
            (player.position.inMilliseconds / player.duration.inMilliseconds)
              .clamp(0.0, 1.0).toDouble() : 0.0,
          backgroundColor: const Color(0xFF254365), color: skyBlue),
      ]),
    );
  }
}
