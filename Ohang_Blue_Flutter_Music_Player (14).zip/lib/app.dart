import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/app_theme.dart';
import 'providers/theme_provider.dart';
import 'screens/favorites_screen.dart';
import 'screens/home_screen.dart';
import 'screens/library_screen.dart';
import 'screens/playlists_screen.dart';
import 'widgets/mini_player.dart';

class OhangApp extends StatelessWidget {
  const OhangApp({super.key});

  @override
  Widget build(BuildContext context) {
    final dark = context.watch<ThemeProvider>().isDark;
    return MaterialApp(title: 'Ohang', debugShowCheckedModeBanner: false,
      theme: ohangTheme(dark: false), darkTheme: ohangTheme(dark: true),
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      home: const MusicShell());
  }
}

class MusicShell extends StatefulWidget {
  const MusicShell({super.key});
  @override
  State<MusicShell> createState() => _MusicShellState();
}

class _MusicShellState extends State<MusicShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: _index, children: [
      HomeScreen(onLibraryTap: () => setState(() => _index = 1),
        onFavoritesTap: () => setState(() => _index = 2)),
      const LibraryScreen(),
      const FavoritesScreen(),
      const PlaylistsScreen(),
    ]),
    bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
      const MiniPlayer(),
      NavigationBar(selectedIndex: _index, labelBehavior:
        NavigationDestinationLabelBehavior.alwaysShow,
        onDestinationSelected: (index) => setState(() => _index = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded, color: accentBlue), label: 'Bosh sahifa'),
          NavigationDestination(icon: Icon(Icons.music_note_outlined),
            selectedIcon: Icon(Icons.music_note_rounded, color: accentBlue), label: 'Musiqalar'),
          NavigationDestination(icon: Icon(Icons.favorite_outline_rounded),
            selectedIcon: Icon(Icons.favorite_rounded, color: accentBlue), label: 'Sevimlilar'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined),
            selectedIcon: Icon(Icons.library_music_rounded, color: accentBlue), label: 'Playlistlar'),
        ]),
    ]),
  );
}

