import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../models/track.dart';
import '../providers/audio_player_provider.dart';
import '../providers/favorites_provider.dart';
import '../providers/library_provider.dart';
import 'settings_screen.dart';
import '../widgets/album_cover.dart';
import '../widgets/navigation_helpers.dart';
import '../widgets/track_tile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onLibraryTap, required this.onFavoritesTap});
  final VoidCallback onLibraryTap;
  final VoidCallback onFavoritesTap;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final tracks = context.watch<LibraryProvider>().tracks;
    final recent = context.watch<AudioPlayerProvider>().recentIds;
    final favs = context.watch<FavoritesProvider>().ids;
    final recentlyPlayed = <MusicTrack>[
      for (final id in recent)
        ...tracks.where((track) => track.id == id),
    ];
    final matches = _query.trim().isEmpty ? <MusicTrack>[] : tracks.where((track) =>
      track.title.toLowerCase().contains(_query.trim().toLowerCase()) ||
      track.artist.toLowerCase().contains(_query.trim().toLowerCase())).toList();

    return SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      children: [
        Row(children: [
          Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(
            color: accentBlue.withValues(alpha: .2), borderRadius: BorderRadius.circular(15)),
            child: const Icon(Icons.multitrack_audio_rounded, color: skyBlue, size: 29)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('OHANG', style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.w900,
              color: skyBlue, fontSize: 23)),
            Text('Sening musiqiy olaming', style: TextStyle(fontSize: 12)),
          ])),
          IconButton(tooltip: 'Sozlamalar', onPressed: () => Navigator.push(context,
              MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
            icon: const Icon(Icons.settings_outlined)),
        ]),
        const SizedBox(height: 20),
        TextField(onChanged: (value) => setState(() => _query = value),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search_rounded, color: accentBlue),
            hintText: 'Musiqa yoki ijrochini qidiring')),
        if (_query.trim().isNotEmpty) ...[
          const SizedBox(height: 15),
          Text('Qidiruv natijalari: ${matches.length} ta',
            style: const TextStyle(fontWeight: FontWeight.w800)),
          if (matches.isEmpty) const Padding(padding: EdgeInsets.all(12),
            child: Text('Hech qanday musiqa topilmadi.')),
          for (final track in matches.take(6)) TrackTile(track: track, queue: matches),
        ],
        const SizedBox(height: 22),
        Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [deepBlue, Color(0xFF145F9E), Color(0xFF0B2B54)]),
          boxShadow: const [BoxShadow(color: Color(0x331384FF), blurRadius: 27, offset: Offset(0, 12))]),
          padding: const EdgeInsets.all(22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('BUGUNGI KAYFIYAT', style: TextStyle(letterSpacing: 2,
              color: faintBlue, fontWeight: FontWeight.w700, fontSize: 11)),
            const SizedBox(height: 10),
            const Text('Musiqaga sho‘ng‘i!', style: TextStyle(color: Colors.white,
              fontSize: 29, fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            Text('${tracks.length} ta kuy seni kutmoqda',
              style: const TextStyle(color: Color(0xFFCCEAFF))),
            const SizedBox(height: 18),
            ElevatedButton.icon(onPressed: tracks.isEmpty ? null : () async {
              await context.read<AudioPlayerProvider>().playQueue(tracks, 0);
              if (context.mounted) openNowPlaying(context);
            }, icon: const Icon(Icons.play_arrow_rounded),
              label: const Text('Tinglashni boshlash'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white,
                foregroundColor: deepBlue)),
          ])),
        const SizedBox(height: 26),
        _SectionHeading(title: 'Barcha musiqalar', onTap: widget.onLibraryTap,
          action: 'Barchasi'),
        const SizedBox(height: 14),
        SizedBox(height: 157, child: ListView.separated(scrollDirection: Axis.horizontal,
          itemCount: tracks.length > 6 ? 6 : tracks.length,
          separatorBuilder: (_, __) => const SizedBox(width: 14),
          itemBuilder: (context, index) => _FeaturedTrack(track: tracks[index], queue: tracks))),
        const SizedBox(height: 25),
        _SectionHeading(title: 'Yaqinda tinglangan', onTap: widget.onLibraryTap,
          action: 'Musiqalar'),
        const SizedBox(height: 8),
        if (recentlyPlayed.isEmpty) const Padding(
          padding: EdgeInsets.symmetric(vertical: 12),
          child: Text('Hali musiqa tinglanmagan. Yuqoridan birini tanlang.')),
        for (final track in recentlyPlayed.take(4)) TrackTile(track: track, queue: recentlyPlayed),
        const SizedBox(height: 20),
        _SectionHeading(title: 'Sevimlilar', onTap: widget.onFavoritesTap,
          action: '${favs.length} ta'),
        const SizedBox(height: 6),
        if (favs.isEmpty) const Padding(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Text('Yoqtirgan musiqalaringizni ♡ bilan belgilang.')),
        for (final track in tracks.where((item) => favs.contains(item.id)).take(3))
          TrackTile(track: track, queue: tracks.where((item) => favs.contains(item.id)).toList()),
      ]));
  }
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading({required this.title, required this.onTap, required this.action});
  final String title;
  final VoidCallback onTap;
  final String action;
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
    TextButton(onPressed: onTap, child: Text(action)),
  ]);
}

class _FeaturedTrack extends StatelessWidget {
  const _FeaturedTrack({required this.track, required this.queue});
  final MusicTrack track;
  final List<MusicTrack> queue;
  @override
  Widget build(BuildContext context) => GestureDetector(onTap: () async {
    final index = queue.indexWhere((item) => item.id == track.id);
    await context.read<AudioPlayerProvider>().playQueue(queue, index);
    if (context.mounted) openNowPlaying(context);
  }, child: SizedBox(width: 126, child: Column(crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Expanded(child: SizedBox(width: 126, child: AlbumCover(color: track.color, size: 126))),
      const SizedBox(height: 9),
      Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontWeight: FontWeight.w800)),
      const Text('Ohang Demo', style: TextStyle(fontSize: 11, color: faintBlue)),
    ])));
}
