import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../providers/audio_player_provider.dart';
import '../providers/favorites_provider.dart';
import '../providers/library_provider.dart';
import '../widgets/navigation_helpers.dart';
import '../widgets/track_tile.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final favorites = context.watch<FavoritesProvider>().ids;
    final tracks = context.watch<LibraryProvider>().tracks
      .where((item) => favorites.contains(item.id)).toList();
    return SafeArea(child: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 12), child: Row(children: [
        const Icon(Icons.favorite_rounded, color: Color(0xFFFF7894), size: 31),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Sevimli musiqalar',
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          Text('${tracks.length} ta qo‘shiq', style: const TextStyle(color: faintBlue)),
        ])),
      ])),
      if (tracks.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
        child: SizedBox(width: double.infinity, child: ElevatedButton.icon(
          onPressed: () async {
            await context.read<AudioPlayerProvider>().playQueue(tracks, 0);
            if (context.mounted) openNowPlaying(context);
          }, icon: const Icon(Icons.play_arrow_rounded),
          label: const Text('Sevimlilarni tinglash')))),
      const SizedBox(height: 12),
      Expanded(child: tracks.isEmpty ? const Center(child: Column(
        mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.favorite_border_rounded, size: 72, color: faintBlue),
          SizedBox(height: 15),
          Text('Hali sevimli musiqa yo‘q'),
          SizedBox(height: 5),
          Text('Musiqa yonidagi yurakchani bosing.',
            style: TextStyle(color: faintBlue)),
        ])) : ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 14),
          itemCount: tracks.length,
          itemBuilder: (context, index) => TrackTile(track: tracks[index], queue: tracks))),
    ]));
  }
}
