import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../providers/library_provider.dart';
import '../providers/theme_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final dark = context.watch<ThemeProvider>().isDark;
    final imported = context.watch<LibraryProvider>().importedCount;
    return Scaffold(appBar: AppBar(title: const Text('Sozlamalar')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
        Card(child: SwitchListTile(secondary: const Icon(Icons.dark_mode_rounded, color: accentBlue),
          title: const Text('Tungi rejim'),
          subtitle: const Text('To‘q ko‘k rangdagi interfeys'),
          value: dark, onChanged: (value) => context.read<ThemeProvider>().setDark(value))),
        const SizedBox(height: 12),
        Card(child: Column(children: [
          const ListTile(leading: Icon(Icons.offline_bolt_rounded, color: accentBlue),
            title: Text('Offline demo musiqalar'),
            subtitle: Text('15 ta original instrumental audio, internet talab qilinmaydi.')),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.file_download_done_rounded, color: accentBlue),
            title: const Text('Import qilingan musiqalar'),
            subtitle: Text('$imported ta audio ilova xotirasiga ko‘chirilgan.')),
          const Divider(height: 1),
          const ListTile(leading: Icon(Icons.info_outline_rounded, color: accentBlue),
            title: Text('Ohang — Music Player'),
            subtitle: Text('1.0.0 · Flutter / Provider / just_audio')),
        ])),
        const SizedBox(height: 16),
        const Text('Demo kuylari faqat loyiha funksiyalarini sinash uchun yaratilgan. '
          'Mashhur ijrochilarning yozuvlari ilovaga joylanmagan.',
          textAlign: TextAlign.center, style: TextStyle(color: faintBlue, fontSize: 12)),
      ])));
  }
}
