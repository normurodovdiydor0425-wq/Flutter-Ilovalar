import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../core/formatters.dart';
import '../providers/audio_player_provider.dart';
import '../providers/favorites_provider.dart';
import '../widgets/album_cover.dart';
import '../widgets/player_controls.dart';
import '../widgets/track_tile.dart';

class NowPlayingScreen extends StatefulWidget {
  const NowPlayingScreen({super.key});
  @override
  State<NowPlayingScreen> createState() => _NowPlayingScreenState();
}

class _NowPlayingScreenState extends State<NowPlayingScreen> {
  double? _seeking;

  @override
  Widget build(BuildContext context) {
    final player = context.watch<AudioPlayerProvider>();
    final track = player.currentTrack;
    if (track == null) return Scaffold(appBar: AppBar(title: const Text('Hozir ijro etilmoqda')),
      body: const Center(child: Text('Hozircha musiqa tanlanmagan.')));
    final favorite = context.watch<FavoritesProvider>().contains(track.id);
    final maxMs = math.max(1, player.duration.inMilliseconds);
    final shownMs = (_seeking ?? player.position.inMilliseconds.toDouble())
      .clamp(0.0, maxMs.toDouble()).toDouble();
    final artworkHeight = math.min(MediaQuery.sizeOf(context).width * .60, 265.0);

    return Theme(data: ohangTheme(dark: true), child: Scaffold(body: Container(decoration: const BoxDecoration(
      gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [Color(0xFF104985), Color(0xFF0A2A54), navy],
        stops: [.0, .48, 1.0])),
      child: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(22, 10, 22, 25),
        children: [
          Row(children: [
            CircleAvatar(backgroundColor: Colors.white, radius: 22,
              child: IconButton(tooltip: 'Orqaga', color: navy,
                icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 17),
                onPressed: () => Navigator.pop(context))),
            const SizedBox(width: 12),
            Expanded(child: Column(children: [
              const Text('HOZIR IJRO ETILMOQDA', style: TextStyle(color: faintBlue,
                letterSpacing: 2, fontSize: 10, fontWeight: FontWeight.bold)),
              Text(track.album, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 13)),
            ])),
            IconButton(tooltip: 'Navbatni ko‘rish', onPressed: () => _showQueue(context),
              icon: const Icon(Icons.queue_music_rounded, color: Colors.white)),
          ]),
          const SizedBox(height: 22),
          SizedBox(height: artworkHeight, width: double.infinity,
            child: ClipRRect(borderRadius: BorderRadius.circular(21),
              child: SizedBox.expand(child: AlbumCover(
                key: ValueKey(track.id), color: track.color,
                size: MediaQuery.sizeOf(context).width, radius: 21)))),
          const SizedBox(height: 22),
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 23,
                    fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(track.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: faintBlue, fontSize: 14)),
              ])),
            IconButton(tooltip: 'Sevimlilarga',
              onPressed: () => context.read<FavoritesProvider>().toggle(track.id),
              icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: favorite ? const Color(0xFFFF7999) : Colors.white, size: 27)),
            IconButton(tooltip: 'Playlistga qo‘shish',
              onPressed: () => showAddToPlaylistSheet(context, track),
              icon: const Icon(Icons.playlist_add_rounded, color: Colors.white)),
            IconButton(tooltip: 'Musiqa nomini nusxalash', onPressed: () async {
              await Clipboard.setData(ClipboardData(text: '${track.title} — ${track.artist}'));
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Musiqa nomi nusxalandi.')));
            }, icon: const Icon(Icons.ios_share_rounded, color: Colors.white)),
          ]),
          const SizedBox(height: 16),
          Slider(value: shownMs, min: 0, max: maxMs.toDouble(),
            onChanged: (value) => setState(() => _seeking = value),
            onChangeEnd: (value) {
              context.read<AudioPlayerProvider>().seek(Duration(milliseconds: value.round()));
              setState(() => _seeking = null);
            }),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 5),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(timeText(Duration(milliseconds: shownMs.round())),
                  style: const TextStyle(color: faintBlue, fontSize: 12)),
                Text(timeText(player.duration),
                  style: const TextStyle(color: faintBlue, fontSize: 12)),
              ])),
          const SizedBox(height: 12),
          const PlayerControls(),
          if (player.error != null) Padding(padding: const EdgeInsets.only(top: 18),
            child: Text(player.error!, style: const TextStyle(color: Color(0xFFFFAAAA)))),
          const SizedBox(height: 25),
          Row(children: [
            const Expanded(child: Text('Keyingi musiqalar',
              style: TextStyle(color: Colors.white, fontSize: 19,
                fontWeight: FontWeight.w800))),
            Text('${player.queue.length} ta', style: const TextStyle(color: faintBlue)),
          ]),
          const SizedBox(height: 10),
          for (var index = 0; index < player.queue.length && index < 7; index++)
            TrackTile(track: player.queue[index], queue: player.queue),
          const SizedBox(height: 12),
          const Center(child: Text('OHANG  •  O‘Z MUSIQANGNI TINGLA',
            style: TextStyle(color: faintBlue, letterSpacing: 1.5, fontSize: 10))),
        ])),
    )));
  }

  void _showQueue(BuildContext context) {
    final player = context.read<AudioPlayerProvider>();
    showModalBottomSheet<void>(context: context, showDragHandle: true,
      builder: (ctx) => SafeArea(child: ListView(shrinkWrap: true,
        padding: const EdgeInsets.all(18), children: [
          const Text('Ijro navbati', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          for (final track in player.queue)
            TrackTile(track: track, queue: player.queue),
        ])));
  }
}
