import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../models/track.dart';
import '../providers/audio_player_provider.dart';
import '../providers/library_provider.dart';
import '../providers/playlist_provider.dart';
import '../widgets/track_tile.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final _query = TextEditingController();
  String _sort = 'default';
  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final library = context.watch<LibraryProvider>();
    final tracks = library.tracks.where((track) =>
      track.title.toLowerCase().contains(_query.text.trim().toLowerCase()) ||
      track.artist.toLowerCase().contains(_query.text.trim().toLowerCase())).toList();
    if (_sort == 'name') tracks.sort((a, b) => a.title.compareTo(b.title));
    if (_sort == 'artist') tracks.sort((a, b) => a.artist.compareTo(b.artist));
    if (_sort == 'duration') tracks.sort((a, b) => a.durationMs.compareTo(b.durationMs));
    if (_sort == 'recent') tracks.sort((a, b) => b.addedAt.compareTo(a.addedAt));

    return SafeArea(child: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Musiqalarim', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text('${library.tracks.length} ta qo‘shiq · Internet talab qilinmaydi',
            style: const TextStyle(color: faintBlue)),
          const SizedBox(height: 18),
          TextField(controller: _query, onChanged: (_) => setState(() {}),
            decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded),
              hintText: 'Musiqa yoki ijrochini qidiring',
              suffixIcon: _query.text.isEmpty ? null : IconButton(
                onPressed: () { _query.clear(); setState(() {}); },
                icon: const Icon(Icons.close_rounded)))),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: ElevatedButton.icon(onPressed: _import,
              icon: const Icon(Icons.file_upload_outlined),
              label: const Text('Musiqa qo‘shish'))),
            const SizedBox(width: 10),
            PopupMenuButton<String>(tooltip: 'Saralash',
              onSelected: (value) => setState(() => _sort = value),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'default', child: Text('Asl tartib')),
                PopupMenuItem(value: 'name', child: Text('Nomi bo‘yicha')),
                PopupMenuItem(value: 'artist', child: Text('Ijrochi bo‘yicha')),
                PopupMenuItem(value: 'duration', child: Text('Davomiyligi bo‘yicha')),
                PopupMenuItem(value: 'recent', child: Text('Yaqinda qo‘shilgan')),
              ],
              child: const Padding(padding: EdgeInsets.all(12),
                child: Icon(Icons.tune_rounded, color: skyBlue))),
          ]),
        ])),
      Expanded(child: tracks.isEmpty ? const Center(child: Text('Hech qanday musiqa topilmadi.'))
        : ListView.builder(padding: const EdgeInsets.fromLTRB(13, 0, 13, 20),
          itemCount: tracks.length,
          itemBuilder: (context, index) {
            final track = tracks[index];
            return TrackTile(key: ValueKey(track.id), track: track, queue: tracks,
              onDelete: track.isAsset ? null : () => _confirmDelete(track));
          })),
    ]));
  }

  Future<void> _import() async {
    final error = await context.read<LibraryProvider>().importAudio();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(error)));
  }

  Future<void> _confirmDelete(MusicTrack track) async {
    final accepted = await showDialog<bool>(context: context,
      builder: (context) => AlertDialog(title: const Text('Musiqani o‘chirish'),
        content: Text('${track.title} import qilingan fayllardan ham o‘chiriladi.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
            child: const Text('Bekor qilish')),
          TextButton(onPressed: () => Navigator.pop(context, true),
            child: const Text('O‘chirish')),
        ]));
    if (accepted != true || !mounted) return;
    await context.read<AudioPlayerProvider>().removeTrack(track.id);
    if (!mounted) return;
    await context.read<PlaylistProvider>().removeTrackFromAll(track.id);
    if (!mounted) return;
    await context.read<LibraryProvider>().deleteImported(track.id);
  }
}
