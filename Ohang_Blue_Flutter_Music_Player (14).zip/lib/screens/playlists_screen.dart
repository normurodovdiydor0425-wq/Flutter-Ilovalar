import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_theme.dart';
import '../models/playlist.dart';
import '../providers/audio_player_provider.dart';
import '../providers/library_provider.dart';
import '../providers/playlist_provider.dart';
import '../widgets/navigation_helpers.dart';
import '../widgets/track_tile.dart';

Future<String?> _askName(BuildContext context, String title, {String? initial}) async {
  final controller = TextEditingController(text: initial);
  final result = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
    title: Text(title),
    content: TextField(controller: controller, maxLength: 48, autofocus: true,
      decoration: const InputDecoration(hintText: 'Playlist nomi')),
    actions: [
      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Bekor')),
      TextButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()),
        child: const Text('Saqlash')),
    ]));
  controller.dispose();
  return result;
}

class PlaylistsScreen extends StatelessWidget {
  const PlaylistsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final playlists = context.watch<PlaylistProvider>().items;
    return SafeArea(child: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Playlistlar', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text('${playlists.length} ta shaxsiy to‘plam', style: const TextStyle(color: faintBlue)),
          const SizedBox(height: 18),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(
            onPressed: () async {
              final name = await _askName(context, 'Yangi playlist');
              if (name != null && name.isNotEmpty && context.mounted) {
                await context.read<PlaylistProvider>().create(name);
              }
            }, icon: const Icon(Icons.add_rounded), label: const Text('Playlist yaratish'))),
        ])),
      Expanded(child: playlists.isEmpty
        ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.library_music_outlined, color: faintBlue, size: 72),
            SizedBox(height: 12), Text('Hali playlist yaratilmagan.'),
            SizedBox(height: 4), Text('Yuqoridagi tugma orqali yaratishingiz mumkin.',
              style: TextStyle(color: faintBlue)),
          ]))
        : ListView.separated(padding: const EdgeInsets.fromLTRB(15, 0, 15, 30),
          itemCount: playlists.length, separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final playlist = playlists[index];
            return Card(child: ListTile(contentPadding: const EdgeInsets.all(10),
              leading: Container(width: 58, height: 58, alignment: Alignment.center,
                decoration: BoxDecoration(gradient: const LinearGradient(
                  colors: [deepBlue, accentBlue]), borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.queue_music_rounded, color: Colors.white, size: 32)),
              title: Text(playlist.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${playlist.trackIds.length} ta musiqa'),
              onTap: () => Navigator.push(context,
                MaterialPageRoute<void>(builder: (_) => PlaylistDetailScreen(id: playlist.id))),
              trailing: PopupMenuButton<String>(onSelected: (value) async {
                if (value == 'rename') {
                  final name = await _askName(context, 'Nomini o‘zgartirish', initial: playlist.name);
                  if (name != null && name.isNotEmpty && context.mounted) {
                    await context.read<PlaylistProvider>().rename(playlist.id, name);
                  }
                } else {
                  final delete = await showDialog<bool>(context: context,
                    builder: (ctx) => AlertDialog(title: const Text('Playlist o‘chirilsinmi?'),
                      content: Text(playlist.name), actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('Bekor')),
                        TextButton(onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('O‘chirish')),
                      ]));
                  if (delete == true && context.mounted) {
                    await context.read<PlaylistProvider>().delete(playlist.id);
                  }
                }
              }, itemBuilder: (_) => const [
                PopupMenuItem(value: 'rename', child: Text('Nomini o‘zgartirish')),
                PopupMenuItem(value: 'delete', child: Text('O‘chirish')),
              ])),
            ));
          })),
    ]));
  }
}

class PlaylistDetailScreen extends StatelessWidget {
  const PlaylistDetailScreen({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    MusicPlaylist? playlist;
    for (final item in context.watch<PlaylistProvider>().items) {
      if (item.id == id) { playlist = item; break; }
    }
    if (playlist == null) return const Scaffold(body: Center(child: Text('Playlist topilmadi.')));
    final ids = playlist.trackIds.toSet();
    final all = context.watch<LibraryProvider>().tracks;
    final tracks = [for (final id in playlist.trackIds) ...all.where((track) => track.id == id)];
    return Scaffold(appBar: AppBar(title: Text(playlist.name)),
      body: Column(children: [
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            Expanded(child: ElevatedButton.icon(onPressed: tracks.isEmpty ? null : () async {
              await context.read<AudioPlayerProvider>().playQueue(tracks, 0);
              if (context.mounted) openNowPlaying(context);
            }, icon: const Icon(Icons.play_arrow_rounded), label: const Text('Tinglash'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: () => _chooseTracks(context, ids),
              icon: const Icon(Icons.add), label: const Text('Musiqa qo‘shish'))),
          ])),
        Expanded(child: tracks.isEmpty ? const Center(child: Text('Playlistga musiqa qo‘shing.'))
          : ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: tracks.length, itemBuilder: (context, index) =>
              TrackTile(track: tracks[index], queue: tracks))),
      ]));
  }

  void _chooseTracks(BuildContext context, Set<String> selected) {
    final provider = context.read<PlaylistProvider>();
    final tracks = context.read<LibraryProvider>().tracks;
    showModalBottomSheet<void>(context: context, showDragHandle: true,
      isScrollControlled: true, builder: (ctx) => SafeArea(child: SizedBox(
        height: MediaQuery.sizeOf(ctx).height * .74,
        child: Column(children: [
          const Padding(padding: EdgeInsets.all(16),
            child: Text('Playlistga qo‘shish / olib tashlash',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          Expanded(child: ListView.builder(itemCount: tracks.length,
            itemBuilder: (context, index) => ListTile(
              title: Text(tracks[index].title), subtitle: Text(tracks[index].artist),
              trailing: Icon(selected.contains(tracks[index].id)
                ? Icons.check_circle_rounded : Icons.add_circle_outline_rounded,
                color: accentBlue),
              onTap: () async {
                await provider.toggleTrack(id, tracks[index].id);
                if (ctx.mounted) Navigator.pop(ctx);
              }))),
        ]))));
  }
}
