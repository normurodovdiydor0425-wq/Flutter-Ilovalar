import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

abstract class StringStore {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
}

class DeviceStringStore implements StringStore {
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();
  @override
  Future<String?> read(String key) => _prefs.getString(key);
  @override
  Future<void> write(String key, String value) => _prefs.setString(key, value);
}

class AppStorage {
  AppStorage([StringStore? store]) : _store = store ?? DeviceStringStore();
  final StringStore _store;
  final Map<String, Future<void>> _writes = {};

  Future<dynamic> load(String key, dynamic fallback) async {
    try {
      final raw = await _store.read('ohang_v1_$key');
      return raw == null ? fallback : jsonDecode(raw);
    } catch (_) {
      return fallback;
    }
  }

  Future<void> save(String key, dynamic value) {
    final fullKey = 'ohang_v1_$key';
    final previous = _writes[fullKey] ?? Future<void>.value();
    final next = previous.catchError((Object _) {}).then(
      (_) => _store.write(fullKey, jsonEncode(value))).catchError((Object _) {});
    _writes[fullKey] = next;
    return next;
  }
}
