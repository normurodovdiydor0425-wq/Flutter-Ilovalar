import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'providers/audio_player_provider.dart';
import 'providers/favorites_provider.dart';
import 'providers/library_provider.dart';
import 'providers/playlist_provider.dart';
import 'providers/theme_provider.dart';
import 'services/local_storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final storage = AppStorage();
  final library = LibraryProvider(storage);
  final favorites = FavoritesProvider(storage);
  final playlists = PlaylistProvider(storage);
  final theme = ThemeProvider(storage);
  final player = AudioPlayerProvider(storage);

  // Xotira yoki plagin xatosi bo‘lsa ham ilova butunlay yopilib qolmasin.
  try { await library.load(); } catch (error) { debugPrint('Library: $error'); }
  try { await favorites.load(); } catch (error) { debugPrint('Favorites: $error'); }
  try { await playlists.load(); } catch (error) { debugPrint('Playlists: $error'); }
  try { await theme.load(); } catch (error) { debugPrint('Theme: $error'); }

  runApp(MultiProvider(providers: [
    ChangeNotifierProvider<LibraryProvider>.value(value: library),
    ChangeNotifierProvider<FavoritesProvider>.value(value: favorites),
    ChangeNotifierProvider<PlaylistProvider>.value(value: playlists),
    ChangeNotifierProvider<ThemeProvider>.value(value: theme),
    ChangeNotifierProvider<AudioPlayerProvider>.value(value: player),
  ], child: const OhangApp()));

  // Avval interfeysni ochamiz, keyin audio holatini qayta tiklaymiz.
  unawaited(player.initialize(library.tracks).catchError((Object error) {
    debugPrint('Audio init: $error');
  }));
}
