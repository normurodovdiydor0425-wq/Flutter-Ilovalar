import 'package:flutter/material.dart';

const navy = Color(0xFF071A30);
const deepBlue = Color(0xFF103B73);
const accentBlue = Color(0xFF2589FF);
const skyBlue = Color(0xFF48C6FF);
const faintBlue = Color(0xFFAFD5FF);

ThemeData ohangTheme({required bool dark}) {
  final scheme = ColorScheme.fromSeed(seedColor: accentBlue,
    brightness: dark ? Brightness.dark : Brightness.light);
  return ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme.copyWith(primary: accentBlue, secondary: skyBlue,
      surface: dark ? navy : const Color(0xFFF2F8FF)),
    scaffoldBackgroundColor: dark ? navy : const Color(0xFFF2F8FF),
    cardColor: dark ? const Color(0xFF102B48) : Colors.white,
    appBarTheme: AppBarTheme(backgroundColor: Colors.transparent,
      foregroundColor: dark ? Colors.white : navy, elevation: 0),
    cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
      backgroundColor: accentBlue, foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14))),
    inputDecorationTheme: InputDecorationTheme(filled: true,
      fillColor: dark ? const Color(0xFF123051) : Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      border: OutlineInputBorder(borderSide: BorderSide.none,
        borderRadius: BorderRadius.circular(17))),
    navigationBarTheme: NavigationBarThemeData(height: 72,
      backgroundColor: dark ? const Color(0xFF082341) : Colors.white,
      indicatorColor: accentBlue.withValues(alpha: .18)),
    sliderTheme: const SliderThemeData(activeTrackColor: skyBlue,
      inactiveTrackColor: Color(0xFF57799D), thumbColor: Colors.white),
  );
}
