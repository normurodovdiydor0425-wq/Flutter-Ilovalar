import '../models/track.dart';

class DemoTracks {
  static const _titles = <String>[
    'Tong nafasi', 'Yulduzlar', 'Xotiralar', 'Orzular', 'Sokin tun',
    'Bahor shamoli', 'Sayohat', 'Dengiz', 'Ilhom', 'Sokin osmon',
    'Oydin yo‘l', 'Yurak sadosi', 'Yangi kun', 'Umid', 'Manzil',
  ];

  static const _colors = <int>[
    0xFF2589FF, 0xFF12B5E8, 0xFF1965C7, 0xFF3599E7, 0xFF294D9F,
    0xFF2CA7C9, 0xFF176B99, 0xFF1C80CE, 0xFF4B8DDD, 0xFF2066B6,
    0xFF13A8B8, 0xFF356FCB, 0xFF52A9D3, 0xFF287BD0, 0xFF1565A9,
  ];

  static final List<MusicTrack> all = List.generate(_titles.length, (index) =>
    MusicTrack(
      id: 'demo_${index + 1}', title: _titles[index], artist: 'Ohang Demo',
      album: 'Original instrumental kuylar',
      source: 'assets/audio/ohang_${(index + 1).toString().padLeft(2, '0')}.wav',
      isAsset: true, color: _colors[index], durationMs: 23000 + index % 4 * 1000,
    ), growable: false);
}
