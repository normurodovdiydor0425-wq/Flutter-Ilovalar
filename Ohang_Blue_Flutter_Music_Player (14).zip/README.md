# OHANG — ko‘k dizayndagi Flutter musiqa pleyeri

O‘zbek tilidagi offline musiqa pleyeri. Musiqa ro‘yxati, Play/Pause/Next/Previous,
seek, shuffle, repeat, sevimlilar, playlistlar va Android fayl tanlash oynasi orqali
audio import qilish mumkin.

## Ishlaydigan qismlar

- 15 ta **original, mahalliy WAV demo** (`assets/audio/ohang_01.wav` … `ohang_15.wav`).
- `just_audio` yordamida haqiqiy musiqa ijrosi va bitta umumiy player.
- Bosh sahifa, barcha musiqalar, sevimlilar, playlistlar, katta Now Playing sahifasi.
- Import qilingan MP3/M4A/WAV/AAC/FLAC fayllarni ilova xotirasiga ko‘chirish.
- Lokal xotirada sevimlilar, playlistlar, importlar, tema va oxirgi ijroni saqlash.
- **To‘q ko‘k** (`#071A30`) va **yorqin ko‘k** (`#2589FF`) dizayn; Light rejim ham bor.

Demo kuylari algoritmik tarzda mustaqil yaratilgan; ular mualliflik huquqi
ostidagi mashhur yozuvlar emas. Ularni qayta generatsiya qilish:

```powershell
python tools\generate_demo_audio.py
```

## Windows + Android Studio: birinchi marta o‘rnatish

ZIP arxivni `E:\ohang` papkasiga oching. **Oldingi `E:\savatcha` loyihasiga tegmang.**

Terminalda:

```powershell
cd E:\ohang
flutter create --platforms=android --org uz.diydor .
flutter pub get
flutter analyze
flutter test
```

> Muhim: arxivga Flutter SDK avtomatik yaratadigan `android/` katalogi qo‘shilmagan.
> `flutter create` aynan shu loyiha ichida Android platformasi fayllarini yaratadi.
> Agar `lib/main.dart` yoki `test/widget_test.dart` ustidan yozilgan bo‘lsa,
> ularni ZIP ichidagi asl nusxa bilan tiklang.

`android/app/src/main/AndroidManifest.xml` faylida `<application>` atributini
`android:label="Ohang"` qilib belgilang. Paket identifikatori Flutter generatsiyasi
orqali `uz.diydor.ohang` bo‘lishi kerak.

### Emulyatorda ishga tushirish

Android Studio -> Device Manager -> `Savatcha_Test` yoki boshqa barqaror Android 15
(API 35) qurilmasini yoqing. Android bosh sahifasi chiqishini kuting.

```powershell
flutter devices
flutter run -d emulator-5554
```

`emulator-5554` o‘rniga `flutter devices` chiqargan haqiqiy ID ni yozing.
Windows (desktop) qurilmasini tanlamang; ushbu loyiha Android uchun tayyorlangan.

### APK tayyorlash

Emulyatorni ishga tushirish **shart emas**:

```powershell
flutter build apk --release
```

Tayyor APK:

```text
E:\ohang\build\app\outputs\flutter-apk\app-release.apk
```

Ushbu APK ni telefoningizga yuboring va o‘rnating. Agar ochilmasa, telefonni USB
orqali ulang, USB debugging ni yoqing va Android Studio Logcat -> `is:crash`
orqali haqiqiy xatoni oling; muvaffaqiyatli APK yig‘ilishi ilovaning har doim
ishlashini kafolatlamaydi.

### Gradle cross-drive muammosi

Agar Windows kompyuterida Kotlin incremental cache `different roots` xatosi
chiqsa (masalan Flutter SDK `C:` diskida, loyiha `E:` diskida), **faqat shu
holatda** `android/gradle.properties` oxiriga qo‘shing:

```properties
kotlin.incremental=false
```

Keyin:

```powershell
flutter clean
flutter pub get
flutter build apk --release
```

## Texnik ma'lumot

- Flutter + Dart null safety, Material 3.
- `provider`, `just_audio`, `audio_session`, `shared_preferences`, `file_picker`, `path_provider`.
- Offline assets: 22 050 Hz / 16-bit / mono / PCM WAV.
- `SharedPreferencesAsync` uchun testlarda soxta `StringStore` qo‘llanadi.
- Audio demo uchun internet, Google API kaliti, login yoki to‘lov tizimi talab qilinmaydi.
- Play/Pause/Next/seek/shuffle/repeat tugmalari platforma playeriga ulangan.
- `audio_session` musiqa sessiyasi sozlangan.

**Hozircha qo‘shilmagan:** Android notification/lock-screen fon ijrosini
boshqaradigan `audio_service` integratsiyasi; ekran yopilganda fon ijrosini
Android versiyasiga qarab OS cheklashi mumkin. Nomuvofiq ruxsatlar va
manifest sozlamalari tufayli ilova qulashini oldini olish uchun bu bosqich
alohida rejalashtirilgan.

## Tekshiruv holati

Loyiha fayllari va 15 WAV asset yaratilgan. Hozirgi ishlash muhitida
**Flutter va Android SDK o‘rnatilmagan**, shuning uchun `flutter analyze`,
`flutter test` va real APK build mahalliy bajarilgani haqida da'vo qilinmaydi.
Ushbu buyruqlarni yuqorida ko‘rsatilgan Windows kompyuteringizda bajaring.
