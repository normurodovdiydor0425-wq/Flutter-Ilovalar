package com.example.sayohatgo_global

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
