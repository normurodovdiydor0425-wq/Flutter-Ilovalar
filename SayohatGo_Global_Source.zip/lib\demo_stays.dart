import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class DemoStay {
  final String id;
  final String name;
  final String category;
  final String address;
  final String phone;
  final String website;
  final double latitude;
  final double longitude;
  final Map<String, dynamic> tags;

  DemoStay({
    required this.id,
    required this.name,
    required this.category,
    required this.address,
    required this.phone,
    required this.website,
    required this.latitude,
    required this.longitude,
    required this.tags,
  });

  int get demoPrice {
    final value = id.hashCode & 0x7fffffff;
    return 350000 + (value % 22) * 85000;
  }

  int get demoRooms {
    final value = id.hashCode & 0x7fffffff;
    return 1 + value % 8;
  }

  List<String> get facilities {
    final values = <String>[];

    if (tags['internet_access'] != null) {
      values.add('Internet: ${tags['internet_access']}');
    }
    if (tags['stars'] != null) {
      values.add('Yulduzlar: ${tags['stars']}');
    }
    if (tags['rooms'] != null) {
      values.add('Xonalar: ${tags['rooms']}');
    }
    if (tags['wheelchair'] != null) {
      values.add('Aravachada kirish: ${tags['wheelchair']}');
    }
    if (tags['opening_hours'] != null) {
      values.add('Ish vaqti: ${tags['opening_hours']}');
    }

    return values;
  }

  static DemoStay? fromOsm(Map<String, dynamic> item) {
    final tags = Map<String, dynamic>.from((item['tags'] as Map?) ?? {});

    final name = (tags['name:en'] ?? tags['name'] ?? '').toString().trim();

    if (name.isEmpty) return null;

    final center = Map<String, dynamic>.from((item['center'] as Map?) ?? item);

    final lat = center['lat'];
    final lon = center['lon'];

    if (lat is! num || lon is! num) return null;

    final category = (tags['tourism'] ?? tags['leisure'] ?? 'accommodation')
        .toString();

    final address = [
      if (tags['addr:street'] != null) tags['addr:street'].toString(),
      if (tags['addr:housenumber'] != null) tags['addr:housenumber'].toString(),
      if (tags['addr:city'] != null) tags['addr:city'].toString(),
    ].join(', ');

    return DemoStay(
      id: '${item['type']}-${item['id']}',
      name: name,
      category: category,
      address: address,
      phone: (tags['contact:phone'] ?? tags['phone'] ?? '').toString(),
      website: (tags['contact:website'] ?? tags['website'] ?? '').toString(),
      latitude: lat.toDouble(),
      longitude: lon.toDouble(),
      tags: tags,
    );
  }
}

class DemoStaysPage extends StatefulWidget {
  final String city;
  final String country;
  final double latitude;
  final double longitude;

  const DemoStaysPage({
    super.key,
    required this.city,
    required this.country,
    required this.latitude,
    required this.longitude,
  });

  @override
  State<DemoStaysPage> createState() => _DemoStaysPageState();
}

class _DemoStaysPageState extends State<DemoStaysPage> {
  late Future<List<DemoStay>> future;
  String filter = 'Barchasi';

  @override
  void initState() {
    super.initState();
    future = loadStays();
  }

  Future<List<DemoStay>> loadStays() async {
    final query =
        '''
[out:json][timeout:30];
(
  nwr["tourism"~"hotel|hostel|guest_house|motel|resort|chalet|camp_site|apartment"]
    (around:25000,${widget.latitude},${widget.longitude});
  nwr["leisure"~"beach_resort"]
    (around:25000,${widget.latitude},${widget.longitude});
);
out center 80;
''';

    final uri = Uri.https('overpass-api.de', '/api/interpreter', {
      'data': query,
    });

    final response = await http.get(uri).timeout(const Duration(seconds: 40));

    if (response.statusCode != 200) {
      throw Exception('Ma’lumotlar serveri javob bermadi');
    }

    final json = jsonDecode(response.body) as Map<String, dynamic>;
    final elements = json['elements'] as List<dynamic>? ?? [];

    final stays = <DemoStay>[];
    final ids = <String>{};

    for (final raw in elements) {
      final item = Map<String, dynamic>.from(raw as Map);
      final stay = DemoStay.fromOsm(item);

      if (stay != null && ids.add(stay.id)) {
        stays.add(stay);
      }
    }

    stays.sort((a, b) => a.name.compareTo(b.name));
    return stays;
  }

  String money(int n) =>
      n.toString().replaceAllMapped(
        RegExp(r'\B(?=(\d{3})+(?!\d))'),
        (_) => ' ',
      ) +
      ' so‘m';

  Future<void> openLink(String value) async {
    try {
      var link = value.trim();

      if (!link.startsWith('https://') && !link.startsWith('http://')) {
        link = 'https://$link';
      }

      await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Havolani ochib bo‘lmadi')));
    }
  }

  void showDetails(DemoStay stay) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  stay.name,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 8),
                Text('Turi: ${stay.category}'),
                Text(
                  stay.address.isEmpty
                      ? 'To‘liq manzil ko‘rsatilmagan'
                      : stay.address,
                ),
                const SizedBox(height: 12),
                const Text(
                  'OpenStreetMap yozuvlari obyektning '
                  'hozir ishlayotganini tasdiqlamaydi.',
                ),
                const Divider(height: 24),
                Text(
                  'Demo narx: ${money(stay.demoPrice)} / kecha',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                Text('Demo bo‘sh xonalar: ${stay.demoRooms}'),
                const SizedBox(height: 16),
                Text(
                  'Mavjud qulaylik ma’lumotlari',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                if (stay.facilities.isEmpty)
                  const Text('Qulayliklar haqida ma’lumot yo‘q'),
                ...stay.facilities.map(
                  (text) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Text('• $text'),
                  ),
                ),
                const SizedBox(height: 18),
                if (stay.phone.isNotEmpty)
                  ListTile(
                    leading: const Icon(Icons.phone),
                    title: Text(stay.phone),
                    subtitle: const Text('OSM aloqa ma’lumoti'),
                    onTap: () async {
                      await launchUrl(Uri(scheme: 'tel', path: stay.phone));
                    },
                  ),
                if (stay.website.isNotEmpty)
                  OutlinedButton.icon(
                    onPressed: () => openLink(stay.website),
                    icon: const Icon(Icons.language),
                    label: const Text('Rasmiy sayt sifatida kiritilgan havola'),
                  ),
                OutlinedButton.icon(
                  onPressed: () {
                    openLink(
                      'https://www.openstreetmap.org/'
                      '?mlat=${stay.latitude}'
                      '&mlon=${stay.longitude}'
                      '#map=16/${stay.latitude}/${stay.longitude}',
                    );
                  },
                  icon: const Icon(Icons.map),
                  label: const Text('Xaritada ko‘rish'),
                ),
                const SizedBox(height: 14),
                FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(sheetContext);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DemoStayBookingPage(stay: stay),
                      ),
                    );
                  },
                  icon: const Icon(Icons.calendar_month),
                  label: const Text('Demo bron qilish'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.city} — turar joylar'),
        actions: [
          IconButton(
            tooltip: 'Demo bronlarim',
            icon: const Icon(Icons.receipt_long),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const DemoStayBookingsHistory(),
              ),
            ),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1000),
          child: FutureBuilder<List<DemoStay>>(
            future: future,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Joylar ro‘yxatini yuklab bo‘lmadi.'),
                      TextButton(
                        onPressed: () {
                          setState(() => future = loadStays());
                        },
                        child: const Text('Qayta urinish'),
                      ),
                    ],
                  ),
                );
              }

              final all = snapshot.data ?? [];

              final items = all.where((stay) {
                if (filter == 'Barchasi') return true;
                if (filter == 'Mehmonxonalar') {
                  return stay.category == 'hotel' || stay.category == 'motel';
                }
                if (filter == 'Hostellar') {
                  return stay.category == 'hostel' ||
                      stay.category == 'guest_house';
                }
                return stay.category != 'hotel' &&
                    stay.category != 'motel' &&
                    stay.category != 'hostel' &&
                    stay.category != 'guest_house';
              }).toList();

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    widget.city,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  Text(widget.country),
                  const SizedBox(height: 8),
                  Text('${all.length} ta OSM obyekti topildi'),
                  const SizedBox(height: 12),
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Narxlar va bo‘sh xonalar — DEMO. '
                        'Haqiqiy tariflar yoki bron tasdig‘i emas.',
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children:
                          [
                            'Barchasi',
                            'Mehmonxonalar',
                            'Hostellar',
                            'Dam olish joylari',
                          ].map((name) {
                            return Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(name),
                                selected: filter == name,
                                onSelected: (_) {
                                  setState(() => filter = name);
                                },
                              ),
                            );
                          }).toList(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (items.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(28),
                      child: Text('Bu toifada joy topilmadi.'),
                    ),
                  ...items.map(
                    (stay) => Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(14),
                        leading: CircleAvatar(
                          child: Icon(
                            stay.category == 'hotel'
                                ? Icons.hotel
                                : Icons.holiday_village,
                          ),
                        ),
                        title: Text(
                          stay.name,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          '${stay.category}\n'
                          'Demo: ${money(stay.demoPrice)} / kecha',
                        ),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => showDetails(stay),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Manba: © OpenStreetMap contributors. '
                    'Ma’lumotlar to‘liq yoki yangilangan '
                    'bo‘lishi kafolatlanmaydi.',
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class DemoStayBookingPage extends StatefulWidget {
  final DemoStay stay;

  const DemoStayBookingPage({super.key, required this.stay});

  @override
  State<DemoStayBookingPage> createState() => _DemoStayBookingPageState();
}

class _DemoStayBookingPageState extends State<DemoStayBookingPage> {
  final name = TextEditingController();
  final phone = TextEditingController();

  late DateTimeRange range;

  int guests = 2;
  bool saving = false;

  @override
  void initState() {
    super.initState();

    final start = DateTime.now().add(const Duration(days: 1));
    range = DateTimeRange(
      start: start,
      end: start.add(const Duration(days: 2)),
    );
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    super.dispose();
  }

  int get nights => math.max(1, range.end.difference(range.start).inDays);

  int get total => nights * widget.stay.demoPrice;

  String formatDate(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}.'
      '${date.month.toString().padLeft(2, '0')}.${date.year}';

  Future<void> chooseDates() async {
    final selected = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 730)),
      initialDateRange: range,
    );

    if (selected != null) {
      setState(() => range = selected);
    }
  }

  Future<void> book() async {
    if (name.text.trim().length < 3 || phone.text.trim().length < 7) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ism va telefon raqamini kiriting')),
      );
      return;
    }

    setState(() => saving = true);

    final record = {
      'id': 'DEMO-${DateTime.now().microsecondsSinceEpoch}',
      'name': widget.stay.name,
      'customer': name.text.trim(),
      'phone': phone.text.trim(),
      'start': range.start.toIso8601String(),
      'end': range.end.toIso8601String(),
      'guests': guests,
      'total': total,
      'status': 'Sinov bron',
    };

    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getStringList('sg_demo_stay_bookings') ?? [];

    await prefs.setStringList('sg_demo_stay_bookings', [
      jsonEncode(record),
      ...current,
    ]);

    if (!mounted) return;

    setState(() => saving = false);

    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Demo buyurtma saqlandi')));

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Demo bron')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 650),
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text(
                widget.stay.name,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 12),
              const Text(
                'Bu haqiqiy bron emas. Sinov ma’lumotlari '
                'faqat ushbu qurilmada saqlanadi.',
              ),
              const SizedBox(height: 18),
              Card(
                child: ListTile(
                  title: const Text('Kirish va chiqish sanasi'),
                  subtitle: Text(
                    '${formatDate(range.start)} — '
                    '${formatDate(range.end)}',
                  ),
                  trailing: const Icon(Icons.calendar_month),
                  onTap: chooseDates,
                ),
              ),
              Row(
                children: [
                  const Expanded(child: Text('Mehmonlar')),
                  IconButton(
                    onPressed: guests > 1
                        ? () => setState(() => guests--)
                        : null,
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text('$guests'),
                  IconButton(
                    onPressed: guests < 12
                        ? () => setState(() => guests++)
                        : null,
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: name,
                decoration: const InputDecoration(
                  labelText: 'F.I.Sh.',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Telefon',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 18),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Text('Tunlar: $nights'),
                      Text('Mehmonlar: $guests'),
                      const Divider(),
                      Text(
                        'Demo jami: $total so‘m',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: saving ? null : book,
                icon: const Icon(Icons.check_circle),
                label: const Text('Sinov bronini saqlash'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DemoStayBookingsHistory extends StatefulWidget {
  const DemoStayBookingsHistory({super.key});

  @override
  State<DemoStayBookingsHistory> createState() =>
      _DemoStayBookingsHistoryState();
}

class _DemoStayBookingsHistoryState extends State<DemoStayBookingsHistory> {
  List<Map<String, dynamic>> bookings = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('sg_demo_stay_bookings') ?? [];

    final items = <Map<String, dynamic>>[];

    for (final value in raw) {
      try {
        items.add(Map<String, dynamic>.from(jsonDecode(value) as Map));
      } catch (_) {
        // Buzilgan eski yozuvni o'tkazib yuborish.
      }
    }

    if (mounted) setState(() => bookings = items);
  }

  Future<void> deleteBooking(String id) async {
    final prefs = await SharedPreferences.getInstance();

    bookings.removeWhere((b) => b['id'] == id);

    await prefs.setStringList(
      'sg_demo_stay_bookings',
      bookings.map(jsonEncode).toList(),
    );

    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Demo bronlarim')),
      body: bookings.isEmpty
          ? const Center(child: Text('Demo bronlar mavjud emas'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: bookings.length,
              itemBuilder: (context, index) {
                final b = bookings[index];

                return Card(
                  child: ListTile(
                    title: Text(b['name'].toString()),
                    subtitle: Text(
                      '${b['customer']}\n'
                      '${b['status']}\n'
                      '${b['total']} so‘m (demo)',
                    ),
                    isThreeLine: true,
                    trailing: IconButton(
                      onPressed: () => deleteBooking(b['id'].toString()),
                      icon: const Icon(Icons.delete_outline),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
