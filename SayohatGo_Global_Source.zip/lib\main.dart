import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'demo_stays.dart';

final GlobalKey<NavigatorState> appNavigatorKey =
GlobalKey<NavigatorState>();

// ======================================================
// SAYOHATGO GLOBAL 2.0
// ======================================================

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SayohatGoApp());
}

String formatDate(DateTime d) {
  String two(int v) => v.toString().padLeft(2, '0');
  return '${two(d.day)}.${two(d.month)}.${d.year}';
}

String formatMoney(int amount) {
  final value = amount.toString().replaceAllMapped(
    RegExp(r'\B(?=(\d{3})+(?!\d))'),
    (_) => ' ',
  );
  return '$value so‘m';
}

// ======================================================
// MODELLAR
// ======================================================

class Place {
  final String id;
  final String name;
  final String country;
  final double latitude;
  final double longitude;

  const Place({
    required this.id,
    required this.name,
    required this.country,
    required this.latitude,
    required this.longitude,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'country': country,
    'latitude': latitude,
    'longitude': longitude,
  };

  factory Place.fromJson(Map<String, dynamic> json) {
    return Place(
      id: json['id'].toString(),
      name: json['name'].toString(),
      country: json['country'].toString(),
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
    );
  }
}

class TravelPlan {
  final String id;
  final Place place;
  final String attraction;
  final String customer;
  final DateTime start;
  final DateTime end;
  final int adults;
  final int children;
  final int budget;

  const TravelPlan({
    required this.id,
    required this.place,
    required this.attraction,
    required this.customer,
    required this.start,
    required this.end,
    required this.adults,
    required this.children,
    required this.budget,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'place': place.toJson(),
    'attraction': attraction,
    'customer': customer,
    'start': start.toIso8601String(),
    'end': end.toIso8601String(),
    'adults': adults,
    'children': children,
    'budget': budget,
  };

  factory TravelPlan.fromJson(Map<String, dynamic> json) {
    return TravelPlan(
      id: json['id'].toString(),
      place: Place.fromJson(Map<String, dynamic>.from(json['place'] as Map)),
      attraction: json['attraction'].toString(),
      customer: json['customer'].toString(),
      start: DateTime.parse(json['start'].toString()),
      end: DateTime.parse(json['end'].toString()),
      adults: (json['adults'] as num).toInt(),
      children: (json['children'] as num).toInt(),
      budget: (json['budget'] as num).toInt(),
    );
  }
}

// ======================================================
// MASHHUR SHAHARLAR
// ======================================================

const popularPlaces = <Place>[
  Place(
    id: 'samarkand',
    name: 'Samarqand',
    country: 'O‘zbekiston',
    latitude: 39.6542,
    longitude: 66.9597,
  ),
  Place(
    id: 'paris',
    name: 'Parij',
    country: 'Fransiya',
    latitude: 48.8566,
    longitude: 2.3522,
  ),
  Place(
    id: 'istanbul',
    name: 'Istanbul',
    country: 'Turkiya',
    latitude: 41.0082,
    longitude: 28.9784,
  ),
  Place(
    id: 'dubai',
    name: 'Dubay',
    country: 'BAA',
    latitude: 25.2048,
    longitude: 55.2708,
  ),
  Place(
    id: 'tokyo',
    name: 'Tokio',
    country: 'Yaponiya',
    latitude: 35.6762,
    longitude: 139.6503,
  ),
  Place(
    id: 'newyork',
    name: 'Nyu-York',
    country: 'AQSH',
    latitude: 40.7128,
    longitude: -74.0060,
  ),
];

// ======================================================
// GLOBAL MA'LUMOTLAR XIZMATI
// ======================================================

class GlobalPlacesService {
  static Future<List<Place>> searchCities(String search) async {
    if (search.trim().length < 2) return [];

    final uri = Uri.https('geocoding-api.open-meteo.com', '/v1/search', {
      'name': search.trim(),
      'count': '30',
      'language': 'en',
      'format': 'json',
    });

    final response = await http.get(uri).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception('Qidiruv xizmati javob bermadi');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final results = data['results'] as List<dynamic>? ?? [];

    return results.map((item) {
      final json = Map<String, dynamic>.from(item as Map);

      return Place(
        id: 'geo-${json['id']}',
        name: json['name'].toString(),
        country: [
          if (json['admin1'] != null) json['admin1'].toString(),
          if (json['country'] != null) json['country'].toString(),
        ].join(', '),
        latitude: (json['latitude'] as num).toDouble(),
        longitude: (json['longitude'] as num).toDouble(),
      );
    }).toList();
  }

  static Future<List<String>> attractions(Place place) async {
    final query =
        '''
[out:json][timeout:25];
(
  nwr["tourism"~"attraction|museum|viewpoint|zoo|gallery|theme_park"]
    (around:15000,${place.latitude},${place.longitude});
  nwr["leisure"~"park|nature_reserve|water_park"]
    (around:15000,${place.latitude},${place.longitude});
);
out center 65;
''';

    final uri = Uri.https('overpass-api.de', '/api/interpreter', {
      'data': query,
    });

    final response = await http.get(uri).timeout(const Duration(seconds: 35));

    if (response.statusCode != 200) {
      throw Exception('Turistik obyektlar yuklanmadi');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final elements = data['elements'] as List<dynamic>? ?? [];

    final names = <String>{};

    for (final raw in elements) {
      final element = Map<String, dynamic>.from(raw as Map);
      final tags = Map<String, dynamic>.from((element['tags'] as Map?) ?? {});

      final name = (tags['name:en'] ?? tags['name'] ?? '').toString().trim();

      if (name.isNotEmpty) names.add(name);
    }

    return names.toList()..sort();
  }

  static Future<void> openMap(Place place) async {
    final uri = Uri.parse(
      'https://www.openstreetmap.org/'
      '?mlat=${place.latitude}'
      '&mlon=${place.longitude}'
      '#map=13/${place.latitude}/${place.longitude}',
    );

    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Xarita ochilmadi');
    }
  }
}

// ======================================================
// ASOSIY ILOVA
// ======================================================

class SayohatGoApp extends StatefulWidget {
  const SayohatGoApp({super.key});

  @override
  State<SayohatGoApp> createState() => _SayohatGoAppState();
}

class _SayohatGoAppState extends State<SayohatGoApp> {
  int selectedTab = 0;
  bool darkMode = false;
  bool loaded = false;

  List<Place> favorites = [];
  List<TravelPlan> plans = [];

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    final prefs = await SharedPreferences.getInstance();

    try {
      final savedFavorites = prefs.getString('sg_favorites');
      final savedPlans = prefs.getString('sg_plans');

      if (savedFavorites != null) {
        favorites = (jsonDecode(savedFavorites) as List)
            .map((e) => Place.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      }

      if (savedPlans != null) {
        plans = (jsonDecode(savedPlans) as List)
            .map(
              (e) => TravelPlan.fromJson(Map<String, dynamic>.from(e as Map)),
            )
            .toList();
      }

      darkMode = prefs.getBool('sg_dark') ?? false;
    } catch (_) {
      favorites = [];
      plans = [];
    }

    if (mounted) setState(() => loaded = true);
  }

  Future<void> saveData() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(
      'sg_favorites',
      jsonEncode(favorites.map((p) => p.toJson()).toList()),
    );

    await prefs.setString(
      'sg_plans',
      jsonEncode(plans.map((p) => p.toJson()).toList()),
    );

    await prefs.setBool('sg_dark', darkMode);
  }

  bool isFavorite(Place place) => favorites.any((p) => p.id == place.id);

  Future<void> toggleFavorite(Place place) async {
    setState(() {
      if (isFavorite(place)) {
        favorites.removeWhere((p) => p.id == place.id);
      } else {
        favorites.add(place);
      }
    });

    await saveData();
  }

  Future<void> addPlan(TravelPlan plan) async {
    setState(() => plans.insert(0, plan));
    await saveData();
  }

  Future<void> deletePlan(String id) async {
    setState(() => plans.removeWhere((p) => p.id == id));
    await saveData();
  }

  void openPlace(Place place) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PlanningScreen(place: place, onSave: addPlan),
      ),
    );
  }

  Widget placeTile(Place place) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: const CircleAvatar(child: Icon(Icons.location_city)),
        title: Text(
          place.name,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(place.country),
        trailing: IconButton(
          tooltip: 'Sevimlilar',
          onPressed: () => toggleFavorite(place),
          icon: Icon(
            isFavorite(place) ? Icons.favorite : Icons.favorite_border,
            color: isFavorite(place) ? Colors.red : null,
          ),
        ),
        onTap: () => openPlace(place),
      ),
    );
  }

  Widget homeScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF087F8C), Color(0xFF20BFA9)],
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.public, size: 60, color: Colors.white),
              const SizedBox(height: 15),
              const Text(
                'Dunyoni kashf eting!',
                style: TextStyle(
                  fontSize: 28,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Dunyo shaharlari, turistik obyektlar, '
                'mehmonxonalar va dam olish joylarini toping.',
                style: TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: () => setState(() => selectedTab = 1),
                icon: const Icon(Icons.search),
                label: const Text('Shaharlarni qidirish'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const Text(
          'Mashhur manzillar',
          style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        ...popularPlaces.map(placeTile),
        const SizedBox(height: 16),
        const Text(
          'Ma’lumotlar: Open-Meteo / GeoNames va '
          '© OpenStreetMap contributors',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12),
        ),
      ],
    );
  }

  Widget favoritesScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Saqlangan manzillar',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 14),
        if (favorites.isEmpty)
          const Padding(
            padding: EdgeInsets.all(30),
            child: Center(child: Text('Hali manzil saqlanmagan')),
          ),
        ...favorites.map(placeTile),
      ],
    );
  }

  Widget bookingsScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Mening sayohatlarim',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text('Saqlangan sayohat rejalari'),
        const SizedBox(height: 16),
        if (plans.isEmpty)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(30),
              child: Text('Hozircha sayohat rejasi yo‘q'),
            ),
          ),
        ...plans.map(
          (plan) => Card(
            child: ExpansionTile(
              leading: const Icon(Icons.luggage),
              title: Text(plan.attraction),
              subtitle: Text('${plan.place.name} • ${formatDate(plan.start)}'),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      infoRow('Buyurtma ID', plan.id),
                      infoRow('Buyurtmachi', plan.customer),
                      infoRow('Manzil', plan.place.name),
                      infoRow('Boshlanish', formatDate(plan.start)),
                      infoRow('Tugash', formatDate(plan.end)),
                      infoRow(
                        'Ishtirokchilar',
                        '${plan.adults + plan.children} nafar',
                      ),
                      infoRow('Byudjet', formatMoney(plan.budget)),
                      infoRow('Holat', 'Shaxsiy reja'),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: () => deletePlan(plan.id),
                        icon: const Icon(Icons.delete_outline),
                        label: const Text('Rejani o‘chirish'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'Mehmonxona demo bronlari shahar ichidagi '
          '“Mehmonxonalar” bo‘limida ko‘rinadi.',
        ),
      ],
    );
  }

  Widget profileScreen() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SizedBox(height: 20),
        const Center(
          child: CircleAvatar(radius: 45, child: Icon(Icons.person, size: 48)),
        ),
        const SizedBox(height: 20),
        const Center(
          child: Text(
            'SayohatGo foydalanuvchisi',
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 24),
        ListTile(
          leading: const Icon(Icons.favorite),
          title: const Text('Sevimli manzillar'),
          trailing: Text('${favorites.length} ta'),
        ),
        ListTile(
          leading: const Icon(Icons.event_note),
          title: const Text('Sayohat rejalarim'),
          trailing: Text('${plans.length} ta'),
        ),
        ListTile(
          leading: const Icon(Icons.hotel),
          title: const Text('Mehmonxona demo bronlari'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const DemoStayBookingsHistory(),
              ),
            );
          },
        ),
        SwitchListTile(
          secondary: const Icon(Icons.dark_mode),
          title: const Text('Tungi rejim'),
          value: darkMode,
          onChanged: (value) async {
            setState(() => darkMode = value);
            await saveData();
          },
        ),
        const Divider(),
        const ListTile(
          leading: Icon(Icons.info_outline),
          title: Text('Ilova haqida'),
          subtitle: Text(
            'SayohatGo Global 2.0 — demo versiya.\n'
            'Narxlar va bo‘sh xonalar haqiqiy emas.\n'
            'Rejalar brauzer xotirasida saqlanadi.',
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SayohatGo Global 2.0',
      themeMode: darkMode ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F8C)),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF20BFA9),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.travel_explore),
              SizedBox(width: 8),
              Text('SayohatGo Global 2.0'),
            ],
          ),
          actions: const [
            Padding(
              padding: EdgeInsets.only(right: 12),
              child: Chip(label: Text('DEMO')),
            ),
          ],
        ),
        body: !loaded
            ? const Center(child: CircularProgressIndicator())
            : Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1100),
                  child: IndexedStack(
                    index: selectedTab,
                    children: [
                      homeScreen(),
                      SearchScreen(
                        onSelect: openPlace,
                        isFavorite: isFavorite,
                        onFavorite: toggleFavorite,
                      ),
                      favoritesScreen(),
                      bookingsScreen(),
                      profileScreen(),
                    ],
                  ),
                ),
              ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedTab,
          onDestinationSelected: (index) {
            setState(() => selectedTab = index);
          },
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              label: 'Bosh sahifa',
            ),
            NavigationDestination(icon: Icon(Icons.search), label: 'Manzillar'),
            NavigationDestination(
              icon: Icon(Icons.favorite_border),
              label: 'Saqlanganlar',
            ),
            NavigationDestination(
              icon: Icon(Icons.receipt_long_outlined),
              label: 'Rejalar',
            ),
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              label: 'Profil',
            ),
          ],
        ),
      ),
    );
  }
}

Widget infoRow(String title, String value) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(
      children: [
        Expanded(child: Text(title)),
        Expanded(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ],
    ),
  );
}

// ======================================================
// DUNYO SHAHARLARINI QIDIRISH
// ======================================================

class SearchScreen extends StatefulWidget {
  final ValueChanged<Place> onSelect;
  final bool Function(Place) isFavorite;
  final ValueChanged<Place> onFavorite;

  const SearchScreen({
    super.key,
    required this.onSelect,
    required this.isFavorite,
    required this.onFavorite,
  });

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final controller = TextEditingController();

  List<Place> results = [];
  bool loading = false;
  String? error;

  Future<void> search() async {
    if (controller.text.trim().length < 2) {
      setState(() {
        error = 'Kamida ikkita harf kiriting';
      });
      return;
    }

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final places = await GlobalPlacesService.searchCities(controller.text);

      if (!mounted) return;
      setState(() => results = places);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        error = 'Qidiruv bajarilmadi. Internetni tekshiring.';
      });
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Dunyo bo‘ylab qidiruv',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text('Masalan: London, Berlin, Tokyo, Paris, Tashkent.'),
        const SizedBox(height: 18),
        TextField(
          controller: controller,
          onSubmitted: (_) => search(),
          decoration: const InputDecoration(
            labelText: 'Shahar nomi',
            prefixIcon: Icon(Icons.search),
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: loading ? null : search,
          icon: const Icon(Icons.travel_explore),
          label: const Text('Qidirish'),
        ),
        const SizedBox(height: 18),
        if (loading) const LinearProgressIndicator(),
        if (error != null)
          Text(error!, style: const TextStyle(color: Colors.red)),
        ...results.map(
          (place) => Card(
            child: ListTile(
              leading: const Icon(Icons.location_on_outlined),
              title: Text(place.name),
              subtitle: Text(place.country),
              onTap: () => widget.onSelect(place),
              trailing: IconButton(
                onPressed: () => widget.onFavorite(place),
                icon: Icon(
                  widget.isFavorite(place)
                      ? Icons.favorite
                      : Icons.favorite_border,
                ),
              ),
            ),
          ),
        ),
        if (!loading && results.isEmpty && error == null)
          const Padding(
            padding: EdgeInsets.all(28),
            child: Center(child: Text('Qidiruv natijalari shu yerda chiqadi')),
          ),
      ],
    );
  }
}

// ======================================================
// SAYOHAT REJALASHTIRISH
// ======================================================

class PlanningScreen extends StatefulWidget {
  final Place place;
  final Future<void> Function(TravelPlan) onSave;

  const PlanningScreen({super.key, required this.place, required this.onSave});

  @override
  State<PlanningScreen> createState() => _PlanningScreenState();
}

class _PlanningScreenState extends State<PlanningScreen> {
  final customerController = TextEditingController();
  final budgetController = TextEditingController(text: '0');

  late DateTimeRange dates;
  late Future<List<String>> attractionsFuture;

  String? selectedAttraction;
  int adults = 1;
  int children = 0;
  bool saving = false;

  @override
  void initState() {
    super.initState();

    final start = DateTime.now().add(const Duration(days: 1));

    dates = DateTimeRange(
      start: start,
      end: start.add(const Duration(days: 2)),
    );

    attractionsFuture = GlobalPlacesService.attractions(widget.place);
  }

  @override
  void dispose() {
    customerController.dispose();
    budgetController.dispose();
    super.dispose();
  }

  Future<void> chooseDates() async {
    final result = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 730)),
      initialDateRange: dates,
    );

    if (result != null) {
      setState(() => dates = result);
    }
  }

  Future<void> savePlan() async {
    final customer = customerController.text.trim();

    final budget = int.tryParse(budgetController.text.replaceAll(' ', ''));

    if (customer.length < 3) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Ismingizni kiriting')));
      return;
    }

    if (budget == null || budget < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Byudjetni to‘g‘ri kiriting')),
      );
      return;
    }

    setState(() => saving = true);

    final plan = TravelPlan(
      id: 'SG-${DateTime.now().microsecondsSinceEpoch}',
      place: widget.place,
      attraction: selectedAttraction ?? widget.place.name,
      customer: customer,
      start: dates.start,
      end: dates.end,
      adults: adults,
      children: children,
      budget: budget,
    );

    await widget.onSave(plan);

    if (!mounted) return;

    setState(() => saving = false);
    Navigator.pop(context);
  }

  Widget countRow(
    String label,
    int value,
    VoidCallback? minus,
    VoidCallback? plus,
  ) {
    return Row(
      children: [
        Expanded(child: Text(label)),
        IconButton(
          onPressed: minus,
          icon: const Icon(Icons.remove_circle_outline),
        ),
        Text('$value', style: const TextStyle(fontSize: 18)),
        IconButton(onPressed: plus, icon: const Icon(Icons.add_circle_outline)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final place = widget.place;

    return Scaffold(
      appBar: AppBar(title: Text(place.name)),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Card(
                color: Theme.of(context).colorScheme.primaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    children: [
                      const Icon(Icons.public, size: 55),
                      const SizedBox(height: 10),
                      Text(
                        place.name,
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                      Text(place.country),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: () async {
                          try {
                            await GlobalPlacesService.openMap(place);
                          } catch (_) {
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Xaritani ochib bo‘lmadi'),
                              ),
                            );
                          }
                        },
                        icon: const Icon(Icons.map),
                        label: const Text('Xaritada ko‘rish'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // YANGI: MEHMONXONALAR VA DAM OLISH JOYLARI
              FilledButton.tonalIcon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DemoStaysPage(
                        city: place.name,
                        country: place.country,
                        latitude: place.latitude,
                        longitude: place.longitude,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.hotel),
                label: const Text('Mehmonxonalar va dam olish joylari'),
              ),

              const SizedBox(height: 24),
              const Text(
                'Turistik joylar',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              FutureBuilder<List<String>>(
                future: attractionsFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState != ConnectionState.done) {
                    return const Padding(
                      padding: EdgeInsets.all(15),
                      child: LinearProgressIndicator(),
                    );
                  }

                  if (snapshot.hasError) {
                    return const Text(
                      'Turistik joylar xizmati hozir javob '
                      'bermadi. Shaharni tanlab davom eting.',
                    );
                  }

                  final items = snapshot.data ?? [];

                  if (items.isEmpty) {
                    return const Text('Ushbu hududda obyekt topilmadi.');
                  }

                  return DropdownButtonFormField<String>(
                    initialValue: selectedAttraction,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Turistik obyekt',
                      border: OutlineInputBorder(),
                    ),
                    items: items.map((name) {
                      return DropdownMenuItem(
                        value: name,
                        child: Text(name, overflow: TextOverflow.ellipsis),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() => selectedAttraction = value);
                    },
                  );
                },
              ),
              const SizedBox(height: 20),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.calendar_month),
                  title: const Text('Sayohat sanalari'),
                  subtitle: Text(
                    '${formatDate(dates.start)} — '
                    '${formatDate(dates.end)}',
                  ),
                  trailing: const Icon(Icons.edit_calendar),
                  onTap: chooseDates,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Ishtirokchilar',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              countRow(
                'Kattalar',
                adults,
                adults > 1 ? () => setState(() => adults--) : null,
                adults + children < 20 ? () => setState(() => adults++) : null,
              ),
              countRow(
                'Bolalar',
                children,
                children > 0 ? () => setState(() => children--) : null,
                adults + children < 20
                    ? () => setState(() => children++)
                    : null,
              ),
              const SizedBox(height: 18),
              TextField(
                controller: customerController,
                decoration: const InputDecoration(
                  labelText: 'Sayohatchi F.I.Sh.',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: budgetController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Shaxsiy byudjet (so‘m)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.wallet),
                ),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 20),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      infoRow('Manzil', place.name),
                      infoRow('Jo‘nash', formatDate(dates.start)),
                      infoRow('Qaytish', formatDate(dates.end)),
                      infoRow('Ishtirokchilar', '${adults + children} nafar'),
                      const Divider(),
                      infoRow(
                        'Shaxsiy byudjet',
                        formatMoney(
                          int.tryParse(
                                budgetController.text.replaceAll(' ', ''),
                              ) ??
                              0,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Bu haqiqiy bron yoki to‘lov emas.',
                        style: TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: saving ? null : savePlan,
                icon: const Icon(Icons.check_circle),
                label: Text(
                  saving ? 'Saqlanmoqda...' : 'Sayohat rejasini saqlash',
                ),
              ),
              const SizedBox(height: 28),
            ],
          ),
        ),
      ),
    );
  }
}
